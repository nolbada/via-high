import re,json,sys,html
sys.path.insert(0,'/tmp/claude-0/-home-claude/669b4c4b-f62a-5708-a784-9b7cc42934b2/scratchpad/b')
import content
content.KEY['3'].update({17:('Next(다음은)','Maud Lewis: 마음 따뜻한 그림의 유명 예술가'),18:('','1903년 캐나다 소도시 출생, 신체적 약점으로 고통'),19:('','이동이 제한돼 학교를 중퇴'),20:('To make a living(생계를 위해)','크리스마스카드를 그려 팔기 시작'),21:('When(~한 뒤)','부모 사망 후 딕비의 이모 집으로, 남편 Everett를 만남'),22:('After marrying(결혼 후)','부부는 딕비에서 여생, Lewis는 계속 그림'),23:('','〈딕비 항구의 가장자리〉 등 딕비 풍경을 자주 그림'),24:('','밝은 유화물감 + 단순한 형태 = 독창적 스타일'),29:('','세상에 대한 사랑을 그림으로 표현, 캐나다 민속 예술의 상징'),30:('Now(이제)','마지막 예술가 Anna Ancher'),31:('','공통 주제: 그림마다 여성 인물이 등장')})
content.KEY['4'].update({16:('Also(또한)','기억력 향상 뇌 임플란트도 큰 잠재력'),17:('','기억을 저장·향상, 클라우드로 업로드·다운로드'),31:('','신경 윤리에 대한 고찰로 난제를 극복하길 바람'),32:('','신경 기술의 사회적 측면 강조 + 합법·윤리 기준 제시'),37:('','Eric: AI 신경 임플란트는 정말 놀랍다'),38:('','장애인이 다시 걷고 생각으로 의수를 쓴다니 믿기지 않음')})
S=json.load(open('/tmp/claude-0/w/sentences.json',encoding='utf8'))
def unesc(t): return html.unescape(re.sub(r'<[^>]+>','',t)).strip()
def esc(t): return html.escape(t)
CSS='''
.slots{margin:8px 0 4px}
.slot{display:flex;gap:8px;align-items:flex-start;border:1.5px dashed var(--line);border-radius:11px;padding:8px 11px;margin:6px 0;font-size:16px;line-height:1.55;color:var(--sub);background:var(--bg)}
.slot .no{flex:none;min-width:22px;text-align:center;background:var(--navy);color:var(--card);border-radius:999px;font-size:12.5px;font-weight:800;padding:0 6px;margin-top:2px}
.slot.f{border-style:solid;border-color:var(--pri);background:var(--okBg);color:var(--ink);cursor:pointer}
.slot .x{flex:none;margin-left:auto;color:var(--sub);font-size:13px;padding-left:6px}
.slot .ox{flex:none;margin-left:auto;font-weight:800;font-size:18px;line-height:1.3;padding-left:6px}
.slot .ox.o{color:var(--pri)}.slot .ox.n{color:var(--ans)}
.q.seq2.done .slot{cursor:default}
.sb{display:block;width:100%;margin:10px 0 2px;border:0;background:var(--pri);color:#fff;font:inherit;font-size:16px;font-weight:700;border-radius:12px;padding:10px}
.sb[disabled]{background:var(--line);color:var(--sub)}
.sb.sub2{background:var(--card);color:var(--ink);border:1px solid var(--line)}
.q.seq2.done .pool{display:none}.q.seq2.done .sb.go{display:none}
.q.seq2 .fin{display:none}.q.seq2.done .fin{display:block}
.flow{margin:8px 0 2px}
.flow .fn{display:flex;align-items:center;gap:8px;background:var(--priL);border:1.5px solid var(--pri);border-radius:11px;padding:8px 11px;font-size:16.5px;line-height:1.5;font-weight:700}
.flow .fn.g{background:var(--pi);border-color:var(--piB);color:var(--piInk)}
.flow .ch{flex:none;font-size:12.5px;font-weight:800;color:var(--card);background:var(--pri);border-radius:999px;padding:1px 9px;line-height:1.6}
.flow .ar{text-align:center;color:var(--pri);font-size:15px;line-height:1.1;margin:1px 0}
@media(prefers-color-scheme:dark){.sb{color:#06201d}}
</style>'''
JS='''<script>
(function(){
var qs=[].slice.call(document.querySelectorAll('.q.seq2')),bar=document.getElementById('cnt');
var secs=[].slice.call(document.querySelectorAll('.q.pick'));
var TOT=qs.length+secs.length,done=0,perfect=0,pdone=0,pc=0;
function up(){bar.innerHTML=(done+pdone)+' / '+TOT+' 풀었어요 · 한 번에 맞힌 문제 <b>'+(perfect+pc)+'</b>개'}
qs.forEach(function(q){
 var tot=+q.dataset.t,slots=[].slice.call(q.querySelectorAll('.slot')),pb=[].slice.call(q.querySelectorAll('.pb')),go=q.querySelector('.go'),lbl=q.querySelector('.lbl');
 var texts={};pb.forEach(function(b){texts[b.dataset.n]=b.textContent});
 q._p=[];q._tries=0;
 function draw(){
  slots.forEach(function(s,i){var n=q._p[i],st=s.querySelector('.st');
   if(n){s.classList.add('f');st.textContent=texts[n];s.querySelector('.x').textContent='빼기'}
   else{s.classList.remove('f');st.textContent='비어 있어요';s.querySelector('.x').textContent=''}});
  pb.forEach(function(b){b.classList.toggle('gone',q._p.indexOf(b.dataset.n)>-1)});
  go.disabled=q._p.length!==tot;
  lbl.textContent=q._p.length<tot?'이어질 순서대로 문장을 누르세요 ('+(q._p.length+1)+'번째)':'모두 쌓았어요. 제출해 보세요.';
 }
 q.addEventListener('click',function(e){
  if(q.classList.contains('done'))return;
  var b=e.target.closest('.pb');
  if(b){if(q._p.length<tot){q._p.push(b.dataset.n);draw()}return}
  var s=e.target.closest('.slot.f');
  if(s){var i=slots.indexOf(s);q._p.splice(i,1);draw()}
 });
 go.addEventListener('click',function(){
  if(q._p.length!==tot)return;q._tries++;
  var ok=0;slots.forEach(function(s,i){var r=q._p[i]===String(i+1);if(r)ok++;
   var m=s.querySelector('.x');m.className='ox '+(r?'o':'n');m.textContent=r?'○':'×'});
  q.classList.add('done');done++;if(ok===tot&&q._tries===1)perfect++;
  var r=q.querySelector('.res');r.className='res '+(ok===tot?'o':'x');
  r.textContent=ok===tot?'순서가 모두 맞아요 ('+tot+' / '+tot+')':tot+'자리 중 '+ok+'자리가 맞아요. 아래 순서도로 흐름을 기억해 두세요.';
  up();
 });
 q.querySelector('.again').addEventListener('click',function(){
  q.classList.remove('done');done--;q._p=[];
  slots.forEach(function(s){var m=s.querySelector('.ox');if(m){m.className='x';m.textContent=''}});
  var r=q.querySelector('.res');r.className='res';r.textContent='';draw();up();
 });
 draw();
});
secs.forEach(function(q){
 q.addEventListener('click',function(e){var b=e.target.closest('.ob,.mk');if(!b||q.classList.contains('done'))return;
  var a=+q.dataset.a,i=+b.dataset.i,os=q.querySelectorAll('.ob,.mk');q.classList.add('done');pdone++;
  os[a].classList.add('ok');var r=q.querySelector('.res');
  if(i===a){pc++;r.className='res o';r.textContent='정답이에요'}else{b.classList.add('ng');r.className='res x';r.textContent='아쉬워요. 정답은 '+'①②③④⑤'[a]+'번'}
  up()});
});
document.getElementById('rs').onclick=function(){
 qs.forEach(function(q){if(q.classList.contains('done')){q.querySelector('.again').click()}else{q._p=[];var ev=document.createEvent('Event');}
  q._tries=0;q._p=[];q.querySelectorAll('.slot').forEach(function(s){var m=s.querySelector('.ox');if(m){m.className='x';m.textContent=''}s.classList.remove('f');s.querySelector('.st').textContent='비어 있어요';s.querySelector('.x').textContent=''});
  q.querySelectorAll('.pb').forEach(function(b){b.classList.remove('gone')});q.querySelector('.go').disabled=true;q.querySelector('.lbl').textContent='이어질 순서대로 문장을 누르세요 (1번째)';
  var r=q.querySelector('.res');r.className='res';r.textContent=''});
 secs.forEach(function(q){q.classList.remove('done');q.querySelectorAll('.ob,.mk').forEach(function(o){o.classList.remove('ok','ng')});var r=q.querySelector('.res');r.className='res';r.textContent=''});
 done=0;perfect=0;pdone=0;pc=0;up();window.scrollTo(0,0)};
up();
})();
</script></body></html>'''
def flow(idxs,KEY,hl=None):
    h='<div class="flow">'
    for k,i in enumerate(idxs):
        ch,tx=KEY[i+1]
        h+='<div class="fn%s">'%(' g' if i==hl else '')+('<span class="ch">%s</span>'%esc(ch) if ch else '')+'<span>%s</span></div>'%esc(tx)
        if k<len(idxs)-1:h+='<div class="ar">▼</div>'
    return h+'</div>'
def nm(t): return re.sub(r'[\s\.\?!]+$','',re.sub(r'\s+',' ',t.strip()))
def run(g):
    src='/home/claude/via-high/h/geumcheon-gimal/%s/sunseo-mun.html'%g
    s=open(src,encoding='utf8').read()
    KEY=content.KEY[g]; EN=[x.strip() for x in S[g]['en']]
    def idx(t):
        t=nm(t); r=[i for i,x in enumerate(EN) if nm(x)==t]; assert len(r)==1,(g,t[:40],r); return r[0]
    # seq blocks
    pat=re.compile(r'<div class="q seq" data-t="(\d+)">(.*?)</div></div>\n(?=<div class="q |<h2|<script|<div class="foot|$)',re.S)
    out=[];pos=0;cnt=0
    for m in re.finditer(r'<div class="q seq" data-t="(\d+)">.*?<div class="fin">.*?</ol></div></div>\n',s,re.S):
        blk=m.group(0);t=int(m.group(1))
        qn=re.search(r'<span class="qn">(\d+)</span><span class="tg">(.*?)</span>',blk)
        gv=re.search(r'<div class="gv"><span class="tg2">[^<]*</span>(.*?)<small>',blk,re.S).group(1)
        gi=idx(unesc(gv))
        sd={int(a):b for a,b in re.findall(r'<div class="sd"><span class="no">(\d+)</span>(.*?)<small>',blk,re.S)}
        order=[idx(unesc(sd[k])) for k in range(1,t+1)]
        assert order==list(range(gi+1,gi+1+t)),(g,qn.group(1),order,gi)
        pool=re.findall(r'<button class="pb" data-n="(\d+)">(.*?)</button>',blk,re.S)
        assert len(pool)==t
        h='<div class="q seq2" data-t="%d"><div class="qh"><span class="qn">%s</span><span class="tg">%s</span></div>\n'%(t,qn.group(1),qn.group(2))
        h+='<div class="ask">맨 위 문장 다음에 이어질 순서대로 <b>영어 문장</b>을 눌러 쌓은 뒤 제출해요.</div>\n'
        h+='<div class="gv"><span class="tg2">주어진 문장</span>%s</div>\n'%gv
        h+='<div class="slots">'+''.join('<div class="slot"><span class="no">%d</span><span class="st">비어 있어요</span><span class="x"></span></div>'%(i+1) for i in range(t))+'</div>\n'
        h+='<div class="pool"><div class="lbl">이어질 순서대로 문장을 누르세요 (1번째)</div>\n'
        for n,tx in pool: h+='<button class="pb" data-n="%s">%s</button>\n'%(n,tx)
        h+='</div><button class="sb go" disabled>제출하기</button>\n<div class="res"></div>\n'
        h+='<div class="fin"><div class="wd">한눈에 정리 · 이 순서로 기억해요</div>'+flow([gi]+order,KEY)+'<button class="sb sub2 again" type="button">다시 풀기</button></div></div>\n'
        out.append((m.start(),m.end(),h));cnt+=1
    for a,b,h in reversed(out): s=s[:a]+h+s[b:]
    # pick blocks: replace 완성된 글 list with flow
    def rp(m):
        blk=m.group(0)
        lis=re.findall(r'<li( class="insli")?><span class="en">(.*?)</span>',m.group(2),re.S)
        ids=[];hl=None
        # find full list li's
        for cls,tx in lis:
            pass
        return blk
    n2=0
    pat2=re.compile(r'<div class="wd">완성된 글[^<]*</div><ol class="full">(.*?)</ol>',re.S)
    def rep(m):
        nonlocal n2
        items=re.findall(r'<li( class="insli")?><span class="en">(.*?)</span>',m.group(1),re.S)
        ids=[idx(unesc(t)) for c,t in items]
        hl=[idx(unesc(t)) for c,t in items if c]
        n2+=1
        return '<div class="wd">한눈에 정리 · 노란 칸이 주어진 문장</div>'+flow(ids,KEY,hl[0] if hl else None)
    s=pat2.sub(rep,s)
    # css + js
    s=s.replace('</style>',CSS,1)
    i=s.index('<script>\n'); 
    s=s[:i]+JS
    open('/tmp/claude-0/w/agentF/%s-sunseo-mun.html'%g,'w',encoding='utf8').write(s)
    print(g,'seq',cnt,'pick flows',n2)
for g in '34': run(g)
