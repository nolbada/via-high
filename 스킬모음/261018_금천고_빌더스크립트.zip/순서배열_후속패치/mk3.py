import re,json,html
S=json.load(open('/tmp/claude-0/w/sentences.json',encoding='utf8'))
def nm(t): return re.sub(r'[\s\.\?!]+$','',re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]+>','',t)).strip()))
CSS='small.kr{display:none;color:var(--sub);font-size:14.5px;font-weight:400;line-height:1.55;margin-top:2px}body.kon small.kr{display:block}body.kon .pbox .s2{display:block;margin:0 0 6px}#kt{margin-left:auto}.bar #rs{margin-left:0}\n</style>'
KJS='''var KP='gk-blank-kr',kt=document.getElementById('kt');
function setK(v){document.body.classList.toggle('kon',v);kt.textContent=v?'한글 해석 닫기':'한글 해석 보기';try{localStorage.setItem(KP,v?'1':'0')}catch(e){}}
var _k=false;try{_k=localStorage.getItem(KP)==='1'}catch(e){}
setK(_k);kt.addEventListener('click',function(){setK(!document.body.classList.contains('kon'))});
'''
BTN='<button id="rs">처음부터 다시</button>'
for g in '34':
    EN=S[g]['en'];KO=[k.replace('불 평등','불평등') for k in S[g]['ko']]
    look={nm(e):i for i,e in enumerate(EN)}
    # ---- mun
    p=f'/tmp/claude-0/w/agentF/{g}-sunseo-mun.html'
    s=open(p,encoding='utf8').read()
    def ko_of(t): return KO[look[nm(t)]]
    s=re.sub(r'(<div class="gv"><span class="tg2">주어진 문장</span>)(.*?)(</div>)',lambda m:m.group(1)+m.group(2)+'<small class="kr">'+html.escape(ko_of(m.group(2)))+'</small>'+m.group(3),s,flags=re.S)
    # only inside seq2 blocks' pool buttons
    def pbfix(m): return m.group(1)+m.group(2)+'<small class="kr">'+html.escape(ko_of(m.group(2)))+'</small></button>'
    a=s.index('<div class="q seq2"'); 
    head,body=s[:a],s[a:]
    body=re.sub(r'(<button class="pb" data-n="\d+">)(.*?)</button>',pbfix,body,flags=re.S)
    s=head+body
    s=s.replace("texts[b.dataset.n]=b.textContent","texts[b.dataset.n]=b.innerHTML").replace("st.textContent=texts[n]","st.innerHTML=texts[n]")
    assert 'innerHTML=texts' in s
    assert BTN in s; s=s.replace(BTN,'<button id="kt" type="button">한글 해석 보기</button>'+BTN)
    s=s.replace('</style>',CSS,1)
    s=s.replace("var qs=[].slice.call(document.querySelectorAll('.q.seq2'))",KJS+"var qs=[].slice.call(document.querySelectorAll('.q.seq2'))",1)
    assert 'setK(_k)' in s
    open(p.replace('.html','.k.html'),'w',encoding='utf8').write(s)
    # ---- abc
    p=f'/tmp/claude-0/w/agentF/{g}-sunseo-abc.html'
    s=open(p,encoding='utf8').read()
    kod={str(i+1):KO[i] for i in range(len(KO))}
    i=s.index('var D=')
    # insert D.KO before next statement after D literal: find "\nvar CHO" or "\nvar CIRC"
    m=re.search(r'\n(var CHO|var CIRC)',s[i:]); pos=i+m.start()
    s=s[:pos]+'\nD.KO='+json.dumps(kod,ensure_ascii=False)+';'+s[pos:]
    if g=='3':
        old="function txt(ns){return ns.map(function(n){return D.EN[n]}).join(' ')}"
        assert old in s
        s=s.replace(old,"function txt(ns){return ns.map(function(n){return '<span class=\"s2\">'+D.EN[n]+'<small class=\"kr\">'+D.KO[n]+'</small></span>'}).join(' ')}")
    else:
        old="""return '<span data-n="'+n+'">'+esc(D.en[n])+'</span>'"""
        assert old in s
        s=s.replace(old,"""return '<span class="s2" data-n="'+n+'">'+esc(D.en[n])+'<small class="kr">'+esc(D.KO[n])+'</small></span>'""")
    assert BTN in s or '<button id="rs" type="button">' in s
    s=s.replace(BTN,'<button id="kt" type="button">한글 해석 보기</button>'+BTN) if BTN in s else s.replace('<button id="rs" type="button">','<button id="kt" type="button">한글 해석 보기</button><button id="rs" type="button">')
    s=s.replace('</style>',CSS,1)
    s=s.replace("var host=document.getElementById('qs')",KJS+"var host=document.getElementById('qs')",1)
    assert 'setK(_k)' in s
    open(p.replace('.html','.k.html'),'w',encoding='utf8').write(s)
    print(g,'ok')
