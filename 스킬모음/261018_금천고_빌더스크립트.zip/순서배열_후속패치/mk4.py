import re
TAIL='''function render(){
 %(GEN)s
 newRun(html);
}
var RK='gk%(g)s-abc-run',run=null;
function saveRun(){try{localStorage.setItem(RK,JSON.stringify(run))}catch(e){}}
function loadRun(){try{var r=JSON.parse(localStorage.getItem(RK)||'null');if(r&&typeof r.html==='string'&&r.sel&&r.res&&r.cur>=0&&r.cur<=TOT)return r}catch(e){}return null}
function newRun(html){var a=[],b=[];for(var i=0;i<TOT;i++){a.push(-1);b.push(-1)}run={html:html,cur:0,sel:a,res:b};saveRun();mount()}
function score(){return run.res.filter(function(x){return x===1}).length}
function gradeUI(q,i,s){
 var a=+q.dataset.a,os=q.querySelectorAll('.ob');
 q.classList.add('done');os.forEach(function(o){o.classList.remove('sel')});os[a].classList.add('ok');if(s>=0&&s!==a)os[s].classList.add('ng');
 var r=q.querySelector('.res');
 if(s===a){r.className='res o';r.textContent='○ 정답이에요'}else{r.className='res x';r.textContent='× 정답은 '+CIRC[a]+'번'}
 var go=q.querySelector('.go'),nx=q.querySelector('.nextq');if(go)go.style.display='none';if(nx)nx.style.display='block';
}
function mount(){
 host.innerHTML=run.html;
 var qs=[].slice.call(host.querySelectorAll('.q'));
 qs.forEach(function(q,i){
  var ctl=document.createElement('div');ctl.className='qctl';
  ctl.innerHTML='<button class="nx go" type="button" disabled>제출하기</button><button class="nx nextq" type="button" style="display:none">'+(i===qs.length-1?'결과 보기':'다음 문제')+'</button>';
  q.appendChild(ctl);
  if(run.res[i]>=0)gradeUI(q,i,run.sel[i]);
  else if(run.sel[i]>=0){q.querySelectorAll('.ob')[run.sel[i]].classList.add('sel');ctl.querySelector('.go').disabled=false}
  q.style.display=(i===run.cur)?'block':'none';
 });
 view();
}
function view(){
 var qs=[].slice.call(host.querySelectorAll('.q'));
 qs.forEach(function(q,i){q.style.display=(i===run.cur)?'block':'none'});
 if(run.cur>=TOT){
  var li='';qs.forEach(function(q,i){li+='<li>'+(i+1)+'번 '+(run.res[i]===1?'○':'×')+' <small>'+(q.querySelector('.tg')?q.querySelector('.tg').textContent:'')+'</small></li>'});
  sum.style.display='block';
  sum.innerHTML='<b>'+TOT+'문제 중 '+score()+'개</b>를 맞혔어요.<ul style="list-style:none;padding:0;margin:8px 0">'+li+'</ul>다시 풀면 <b>문제가 매번 바뀌어요</b> (끊는 위치와 (A)(B)(C) 배치가 달라져요).<button class="nx" id="again" type="button">새 문제로 다시 풀기</button>';
  document.getElementById('again').onclick=function(){render();window.scrollTo(0,0)};
  bar.innerHTML='끝 · 정답 <b>'+score()+'</b> / '+TOT;
 }else{
  sum.style.display='none';
  bar.innerHTML='문제 <b>'+(run.cur+1)+'</b> / '+TOT+' · 맞힌 개수 <b>'+score()+'</b>';
 }
}
host.addEventListener('click',function(e){
 var q=e.target.closest('.q');if(!q)return;var i=[].indexOf.call(host.querySelectorAll('.q'),q);
 var b=e.target.closest('.ob');
 if(b){if(q.classList.contains('done'))return;
  var os=q.querySelectorAll('.ob');os.forEach(function(o){o.classList.remove('sel')});b.classList.add('sel');run.sel[i]=+b.dataset.i;q.querySelector('.go').disabled=false;saveRun();return}
 if(e.target.closest('.go')){if(run.sel[i]<0||run.res[i]>=0)return;run.res[i]=(run.sel[i]===+q.dataset.a)?1:0;saveRun();gradeUI(q,i,run.sel[i]);view();return}
 if(e.target.closest('.nextq')){run.cur=i+1;saveRun();view();window.scrollTo(0,0)}
});
document.getElementById('rs').onclick=function(){
 if(run&&run.cur<TOT&&(run.sel.some(function(x){return x>=0}))&&!confirm('지금 풀던 문제를 버리고 새 문제로 시작할까요?'))return;
 render();window.scrollTo(0,0)};
window.__abc={D:D,CHO:CHO,render:render,get run(){return run}};
var _sv=loadRun();if(_sv){run=_sv;mount()}else render();
})();

</script></body></html>'''
GEN3="var qs=genSet();\n var html=qs.map(function(q,i){return qHtml(q,i,D.TAG[q.g])}).join('');"
GEN4="""var set=pickSet(),ans=answers(),h='',best=set,bs=nfresh(set),tries=0;
 while(bs<set.length&&tries++<1500){var c=pickSet(),n=c?nfresh(c):-1;if(n>bs){best=c;bs=n}}
 set=best;
 if(bs===0){used={}}
 set.forEach(function(s){used[sigOf(s)]=1});saveUsed();
 set.forEach(function(s,i){h+=buildQ(s.c,ans[i],i+1,D.zones[s.z].n)});
 var html=h;"""
for g,GEN in (('3',GEN3),('4',GEN4)):
    s=open(f'{g}-sunseo-abc.k.html',encoding='utf8').read()
    i=s.rindex('function render(){')
    s=s[:i]+TAIL%{'GEN':GEN,'g':g}
    s=s.replace('<button class="nx" id="sub" type="button" disabled>제출하기</button>','')
    o="보기를 골라 두었다가 맨 아래 <b>제출하기</b>를 누르면 정답과 한눈에 정리 순서도가 나와요."
    assert o in s,g
    s=s.replace(o,"한 문제씩 보기를 골라 <b>제출하기</b>를 누르면 바로 정답과 한눈에 정리 순서도가 나와요. 풀다가 나가도 <b>풀던 곳에서 이어서</b> 풀 수 있어요.")
    s=s.replace('</style>','.q .qctl{margin-top:4px}\\n</style>'.replace('\\\\n','\\n'),1)
    open(f'{g}-sunseo-abc.k2.html','w',encoding='utf8').write(s)
print('ok')
