import re,glob,os,shutil
R='/home/claude/via-high/h/geumcheon-gimal/'
log=[]
def rd(p): return open(p,encoding='utf8').read()
def wr(p,s): open(p,'w',encoding='utf8').write(s)
# ---------- 1. vocab replay
for g in '34':
    for n in '1234':
        p=f'{R}{g}/vocab{n}.html'; s=rd(p)
        a="function up(){bar.innerHTML=d+' / '+T+' 풀었어요 · 정답 <b>'+c+'</b>개'}"
        assert s.count(a)==1,p
        pre=a+"""
var SK='gk-res:'+location.pathname.replace(/[^a-z0-9]/gi,''),store={};try{store=JSON.parse(localStorage.getItem(SK)||'{}')||{}}catch(e){}
function sv(){try{localStorage.setItem(SK,JSON.stringify(store))}catch(e){}}
qs.forEach(function(q,qi){q.addEventListener('click',function(e){var b=e.target.closest('.ob');if(!b||q.classList.contains('done'))return;store[qi]=+b.dataset.i;sv()})});"""
        s=s.replace(a,pre)
        b="document.getElementById('rs').onclick=function(){"
        assert s.count(b)==1,p
        s=s.replace(b,b+"store={};sv();")
        c="\nup()})();\n</script>"
        assert s.count(c)==1,p
        s=s.replace(c,"""
var _st=JSON.parse(JSON.stringify(store));Object.keys(_st).forEach(function(k){var q=qs[+k];if(q&&!q.classList.contains('done')){var o=q.querySelectorAll('.ob')[_st[k]];if(o)o.click()}});
up();var _f=[].filter.call(qs,function(q){return !q.classList.contains('done')})[0];if(_f&&Object.keys(_st).length)setTimeout(function(){_f.scrollIntoView({block:'start'})},150)})();
</script>""")
        wr(p,s); log.append(p)
# ---------- 2. eobeop-test
for g in '34':
    p=f'{R}{g}/eobeop-test.html'; s=rd(p)
    a="document.getElementById('rs').onclick=function(){"
    assert s.count(a)==1,p
    helper="""var SK='gk-res:'+location.pathname.replace(/[^a-z0-9]/gi,''),rep=false;
function pidx(bk){var bs=[].slice.call(bk.querySelectorAll('button')),k=-1;bs.forEach(function(b,i){if(b.classList.contains('sel')&&k<0)k=i});if(k<0)bs.forEach(function(b,i){if(b.classList.contains('ng')&&k<0)k=i});if(k<0)bs.forEach(function(b,i){if(b.classList.contains('ok')&&k<0)k=i});return k}
function persist(){if(rep)return;var o={};T.forEach(function(q,i){o[i]={s:[].map.call(q.querySelectorAll('.bk'),pidx),d:q.classList.contains('done')?1:0}});try{localStorage.setItem(SK,JSON.stringify(o))}catch(e){}}
T.forEach(function(q){q.addEventListener('click',function(){persist()})});
"""
    s=s.replace(a,helper+a+"try{localStorage.removeItem(SK)}catch(e){}")
    tail="window.scrollTo(0,0)};up()})();"
    assert s.count(tail)==1,p
    s=s.replace(tail,"""window.scrollTo(0,0)};
var _sv=null;try{_sv=JSON.parse(localStorage.getItem(SK)||'null')}catch(e){}
if(_sv){rep=true;T.forEach(function(q,i){var st=_sv[i];if(!st)return;var bks=q.querySelectorAll('.bk');st.s.forEach(function(k,j){if(k>=0)bks[j].querySelectorAll('button')[k].click()});if(st.d)q.querySelector('.go').click()});rep=false;persist();
 var f=[].filter.call(T,function(q){return !q.classList.contains('done')})[0];if(f)setTimeout(function(){f.scrollIntoView({block:'start'})},150)}
up()})();""")
    wr(p,s); log.append(p)
# ---------- 3. seq pages (ko, mun)
for g in '34':
    for k in ('ko','mun'):
        p=f'{R}{g}/sunseo-{k}.html'; s=rd(p)
        a="document.getElementById('rs').onclick=function(){"
        assert s.count(a)==1,p
        blk="""var SK='gk-res:'+location.pathname.replace(/[^a-z0-9]/gi,''),rep=true,saved=null;try{saved=JSON.parse(localStorage.getItem(SK)||'null')}catch(e){}
function pickIdx(q){var os=[].slice.call(q.querySelectorAll('.ob,.mk')),k=-1;os.forEach(function(o,i){if(o.classList.contains('ng')&&k<0)k=i});if(k<0)os.forEach(function(o,i){if(o.classList.contains('ok')&&k<0)k=i});return k}
function persist(){if(rep)return;var o={q:{},p:{}};qs.forEach(function(q,i){o.q[i]={p:q._p||[],d:q.classList.contains('done')?1:0,t:q._tries||0}});secs.forEach(function(q,j){o.p[j]=q.classList.contains('done')?pickIdx(q):-1});try{localStorage.setItem(SK,JSON.stringify(o))}catch(e){}}
qs.concat(secs).forEach(function(q){q.addEventListener('click',function(){setTimeout(persist,0)})});
"""
        s=s.replace(a,blk+a+"try{localStorage.removeItem(SK)}catch(e){}")
        tail="up();\n})();"
        assert s.count(tail)==1,(p,s[-300:])
        s=s.replace(tail,"""if(saved){qs.forEach(function(q,i){var st=saved.q&&saved.q[i];if(!st)return;(st.p||[]).forEach(function(n){var b=q.querySelector('.pb[data-n="'+n+'"]');if(b)b.click()});if(st.d){q._tries=Math.max(0,(st.t||1)-1);var go=q.querySelector('.go');if(go&&!go.disabled)go.click()}});
 secs.forEach(function(q,j){var k=saved.p&&saved.p[j];if(k>=0){var o=q.querySelectorAll('.ob,.mk')[k];if(o)o.click()}});
 var all=qs.concat(secs),f=all.filter(function(q){return !q.classList.contains('done')})[0];var any=all.some(function(q){return q.classList.contains('done')||(q._p&&q._p.length)});if(f&&any)setTimeout(function(){f.scrollIntoView({block:'start'})},150)}
rep=false;up();
})();""")
        wr(p,s); log.append(p)
# ---------- 4. ABC per-question + resume
for g in '34':
    shutil.copy(f'/tmp/claude-0/w/agentF/{g}-sunseo-abc.k2.html',f'{R}{g}/sunseo-abc.html'); log.append(f'abc{g}')
# ---------- 5. index labels
p=R+'index.html'; s=rd(p)
n=s.count('순서배열 · ABC 묶음</div>'); assert n==2
s=s.replace('순서배열 · ABC 묶음</div>','순서배열 · ABC 묶음 (매번 다른 문제)</div>')
wr(p,s)
print(len(log),'patched')
