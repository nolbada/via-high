import re,html
mk=open('/tmp/claude-0/w/agentF/mk.py',encoding='utf8').read()
CSS=re.search(r"CSS='''(.*?)'''",mk,re.S).group(1)
JS=re.search(r"JS='''(.*?)'''\ndef flow",mk,re.S).group(1)
JS=JS.replace("var texts={};pb.forEach(function(b){texts[b.dataset.n]=b.textContent});","var texts={};pb.forEach(function(b){texts[b.dataset.n]=b.innerHTML});").replace("st.textContent=texts[n]","st.innerHTML=texts[n]")
BASE='/home/claude/via-high/h/geumcheon-gimal/'
# ---------- 한글 순서배열
for g in '34':
    s=open(BASE+f'{g}/sunseo-ko.html',encoding='utf8').read()
    starts=[m.start() for m in re.finditer(r'<div class="q seq"',s)]
    foot=s.index('<div class="foot"')
    ends=starts[1:]+[foot]
    parts=[]
    for a,b in zip(starts,ends):
        blk=s[a:b]
        t=int(re.search(r'data-t="(\d+)"',blk).group(1))
        qn=re.search(r'<span class="qn">(\d+)</span><span class="tg">(.*?)</span>',blk)
        gvs=re.findall(r'<div class="gv">.*?</div>',blk,re.S)
        pool=re.findall(r'<button class="pb" data-n="(\d+)">(.*?)</button>',blk,re.S)
        assert len(pool)==t,(g,qn.group(1))
        fin=re.search(r'<div class="fin">.*</div></div>',blk,re.S).group(0)
        fin=fin[:-len('</div></div>')]  # strip fin close + q close
        fin=fin+'<button class="sb sub2 again" type="button">다시 풀기</button></div></div>\n'
        h='<div class="q seq2" data-t="%d"><div class="qh"><span class="qn">%s</span><span class="tg">%s</span></div>\n'%(t,qn.group(1),qn.group(2))
        h+='<div class="ask">맨 위 문장 다음에 이어질 순서대로 <b>한글 문장</b>을 눌러 쌓은 뒤 제출해요.</div>\n'+'\n'.join(gvs)+'\n'
        h+='<div class="slots">'+''.join('<div class="slot"><span class="no">%d</span><span class="st">비어 있어요</span><span class="x"></span></div>'%(i+1) for i in range(t))+'</div>\n'
        h+='<div class="pool"><div class="lbl">이어질 순서대로 문장을 누르세요 (1번째)</div>\n'
        for n,tx in pool: h+='<button class="pb" data-n="%s">%s</button>\n'%(n,tx)
        h+='</div><button class="sb go" disabled>제출하기</button>\n<div class="res"></div>\n'+fin
        parts.append(h)
    s=s[:starts[0]]+''.join(parts)+s[foot:]
    s=s.replace('</style>',CSS,1)
    s=s[:s.index('<script>\n')]+JS
    s=s.replace("맞으면 쌓이고 해설이 나와요.","다 쌓고 <b>제출</b>하면 자리마다 ○×가 표시되고 흐름을 한눈에 정리한 순서도가 나와요.")
    assert '제출' in s
    open(f'/tmp/claude-0/w/agentF/{g}-sunseo-ko.html','w',encoding='utf8').write(s); print(g,'ko',len(parts))
# ---------- ABC
NEWJS_T="""var sub=document.getElementById('sub'),sum=document.getElementById('sum'),graded=false;
function upSel(){var n=host.querySelectorAll('.q .ob.sel').length;sub.disabled=graded||n<TOT;
 bar.innerHTML=graded?('채점 완료 · 정답 <b>'+@P@+'</b> / '+TOT):(n+' / '+TOT+' 골랐어요');}
host.addEventListener('click',function(e){
 var b=e.target.closest('.ob');if(!b||graded)return;var q=b.closest('.q');if(!q)return;
 q.querySelectorAll('.ob').forEach(function(o){o.classList.remove('sel')});b.classList.add('sel');upSel();
});
sub.addEventListener('click',function(){
 if(graded)return;graded=true;@P@=0;
 host.querySelectorAll('.q').forEach(function(q){
  var a=+q.dataset.a,os=q.querySelectorAll('.ob'),sel=q.querySelector('.ob.sel'),i=sel?+sel.dataset.i:-1;
  q.classList.add('done');os[a].classList.add('ok');os.forEach(function(o){o.classList.remove('sel')});
  var r=q.querySelector('.res');
  if(i===a){@P@++;r.className='res o';r.textContent='○ 정답이에요'}else{if(sel)sel.classList.add('ng');r.className='res x';r.textContent='× 정답은 '+CIRC[a]+'번'}
 });
 sum.style.display='block';sum.innerHTML=TOT+'문제 중 <b>'+@P@+'개</b>를 맞혔어요. 각 문제 아래 순서도로 흐름을 기억해 두세요.<br>다시 풀면 <b>문제가 매번 바뀌어요</b> (끊는 위치와 (A)(B)(C) 배치가 달라져요).<button class="nx sub" id="again" type="button">새 문제로 다시 풀기</button>';
 sub.style.display='none';upSel();
 document.getElementById('again').onclick=function(){render();window.scrollTo(0,0)};
 sum.scrollIntoView({block:'nearest'});
});
"""
CSS2='.ob.sel{border-color:var(--pri);background:var(--priL);font-weight:700}#sum{background:var(--priL);border:1px solid var(--pri);border-radius:12px;padding:10px 14px;margin:14px 0;font-size:16px;line-height:1.7;color:var(--ink);font-weight:400}.nx{display:block;width:100%;margin:12px 0 4px;border:0;background:var(--pri);color:#fff;font:inherit;font-size:16px;font-weight:700;border-radius:12px;padding:10px}.nx[disabled]{background:var(--line);color:var(--sub)}.nx.sub{background:var(--card);color:var(--ink);border:1px solid var(--line)}\n</style>'
for g in '34':
    s=open(BASE+f'{g}/sunseo-abc.html',encoding='utf8').read()
    P='perfect' if g=='3' else 'pc'
    if g=='3':
        old="""<div class="ex"><div class="res"></div><div class="kk">정답은 <b>'+CIRC[q.ans]+' '+q.labels.map(function(x){return '('+x+')'}).join('-')+'</b> 이에요. 본문 순서 그대로입니다.</div><ol class="steps">'+explHtml(q)+'</ol><div class="wd">한눈에 정리 · 이 순서로 기억해요</div>'+flowHtml(q)+'</div></div>';"""
        new=old.replace("본문 순서 그대로입니다.","").replace("<ol class=\"steps\">'+explHtml(q)+'</ol>","")
        old2="done=0;perfect=0;up();\n window.__abc.cur=qs;"; new2="done=0;perfect=0;graded=false;sub.style.display='';sum.style.display='none';upSel();\n window.__abc.cur=qs;"
    else:
        old="""<div class="ex"><div class="res"></div><div class="kk">정답은 <b>'+CIRC[a]+' '+labels.map(function(x){return '('+x+')'}).join('-')+'</b> 이에요. 본문 순서 그대로입니다.</div><ol class="steps">'+st+'</ol><div class="wd">"""
        new="""<div class="ex"><div class="res"></div><div class="kk">정답은 <b>'+CIRC[a]+' '+labels.map(function(x){return '('+x+')'}).join('-')+'</b> 이에요.</div><div class="wd">"""
        old2="pdone=0;pc=0;\n set.forEach"; new2="pdone=0;pc=0;graded=false;if(sub){sub.style.display='';sum.style.display='none'}\n set.forEach"
    assert old in s,(g,'old'); s=s.replace(old,new)
    assert old2 in s,(g,'old2'); s=s.replace(old2,new2)
    a=s.index("host.addEventListener('click',function(e){"); b=s.index("document.getElementById('rs').onclick")
    js=NEWJS_T.replace('@P@',P)
    if g=='4':
        js=js.replace("var sub=document.getElementById('sub'),sum=document.getElementById('sum'),graded=false;","")
    s=s[:a]+js+s[b:]
    if g=='4':
        # declare sub/sum/graded before render is called: put near host decl
        s=s.replace("var host=document.getElementById('qs'),bar=document.getElementById('cnt');","var host=document.getElementById('qs'),bar=document.getElementById('cnt'),sub=document.getElementById('sub'),sum=document.getElementById('sum'),graded=false;",1)
        s=s.replace("host.innerHTML=h;up();","host.innerHTML=h;upSel();",1)
    else:
        s=s.replace("host.innerHTML=qs.map","host.innerHTML=qs.map",1)
    s=s.replace('<div id="qs"></div>','<div id="qs"></div><div id="sum" style="display:none"></div><button class="nx" id="sub" type="button" disabled>제출하기</button>',1)
    o="보기를 누르면 바로 정답과 해설이 나와요. <b>처음부터 다시</b>를 누르면 "+("문제가 새로 바뀌어요." if g=='3' else "글 부분과 끊는 곳, (A)(B)(C) 순서가 모두 새로 바뀐 문제가 나와요.")
    assert o in s,(g,'how')
    s=s.replace(o,"보기를 골라 두었다가 맨 아래 <b>제출하기</b>를 누르면 정답과 한눈에 정리 순서도가 나와요. 이 문제는 <b>풀 때마다 바뀌어요</b>. <b>처음부터 다시</b>를 누르면 새 문제가 나와요.")
    s=s.replace('</style>',CSS2,1)
    open(f'/tmp/claude-0/w/agentF/{g}-sunseo-abc.html','w',encoding='utf8').write(s); print(g,'abc ok')
