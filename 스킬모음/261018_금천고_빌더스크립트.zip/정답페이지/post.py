import glob,os,shutil
S='/tmp/claude-0/site/geumcheon-gimal'
for f in ['icon-180.png','icon-192.png','icon-512.png','icon.svg']:
    shutil.copy('/mnt/user-data/outputs/via_h/h/geumcheon-gimal/'+f,S+'/'+f)
for f in glob.glob(S+'/**/*.html',recursive=True):
    pre='' if os.path.dirname(f)==S else '../'
    L=f'<link rel="icon" type="image/svg+xml" href="{pre}icon.svg"><link rel="apple-touch-icon" href="{pre}icon-180.png"><meta name="apple-mobile-web-app-title" content="금천고정답">'
    t=open(f,encoding='utf8').read()
    if 'apple-touch-icon' not in t: t=t.replace('</head>',L+'</head>',1)
    open(f,'w',encoding='utf8').write(t)
