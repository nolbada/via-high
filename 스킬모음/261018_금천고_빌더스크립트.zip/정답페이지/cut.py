import re,sys
def bal(s): return s.count('<div')-s.count('</div>')
def fixbal(old,new,foot_i):
    d=bal(old[:old.index('<div class="foot">')])-bal(new[:new.index('<div class="foot">')])
    return d
for f in ['3/jwa.html','3/hangeul.html','3/yeongeo.html','4/jwa.html','4/hangeul.html','4/yeongeo.html']:
    s=open(f,encoding='utf8').read()
    i=s.index('<h2>본문 외 지문</h2>'); j=s.index('<div class="foot">',i)
    removed=s[i:j]
    new=s[:i]+s[j:]
    # balance: region removed should be balanced; if not, restore needed closers
    d=bal(removed)
    print(f,'removed',len(removed),'balance of removed region',d)
    if d<0: new=s[:i]+'</div>'*(-d)+s[j:]
    elif d>0: print('  WARNING removed region opens more')
    new=new.replace(' → 본문 외 지문과 연결.','')
    open(f,'w',encoding='utf8').write(new)
for L,first in (('3',33),('4',47)):
    f=f'{L}/eobeop.html'; s=open(f,encoding='utf8').read()
    i=s.index(f'<div class="q" id="q{first}">'); j=s.index('<div class="foot">',i)
    removed=s[i:j]; d=bal(removed)
    print(f,'removed',len(removed),'bal',d)
    new=s[:i]+('</div>'*(-d) if d<0 else '')+s[j:]
    new,n=re.subn(r'<a href="#q(\d+)"><span class="qn">\d+\)</span><span class="qa">.*?</span></a>',lambda m:'' if int(m.group(1))>=first else m.group(0),new)
    print(' chips kept/total handled')
    open(f,'w',encoding='utf8').write(new)
