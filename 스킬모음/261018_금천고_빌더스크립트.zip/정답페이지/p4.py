import re,json,sys
sys.path.insert(0,'/tmp/claude-0/work')
from lib import *
def walk(s):
    ms=list(re.finditer(r'(?:^|[\s\x01\x02])(\d+)\.',s))
    secs=[];exp=1;cur=None
    for i,m in enumerate(ms):
        v=int(m.group(1))
        if v==exp or v==1:
            if v==1: cur=[];secs.append(cur);exp=1
            exp+=1
            end=ms[i+1].start() if i+1<len(ms) else len(s)
            cur.append((m.end(),end))
        # else: stray number, ignore (belongs to text)
    # recompute ends to next accepted start
    res=[]
    for sec in secs:
        res.append(sec)
    return res
def txt(s,sec):
    # end of each item = start of next accepted item minus its marker; rebuild
    out=[]
    for j,(a,b) in enumerate(sec):
        out.append(s[a:b])
    return out
out={}
for n in (3,4):
    L=stream(n,False);R=stream(n,True)
    # headers in L
    hs=[(m.start(),m.group(1)) for m in re.finditer(r'([①-⑩])',L)]
    Lsecs=walk(L);Rsecs=walk(R)
    assert len(Lsecs)==len(Rsecs)==len(hs),(len(Lsecs),len(Rsecs),len(hs))
    cards=[]
    for h,(hp,hc),ls,rs in zip(range(len(hs)),hs,Lsecs,Rsecs):
        title=L[hp:L.find('1.',hp)] if True else ''
        title=re.sub(r'\s+',' ',title.replace(W,' ').replace('\x02','')).strip()
        # remove trailing page marker/number artefacts
        assert len(ls)==len(rs),(n,title,len(ls),len(rs))
        for (a,b),(c,d) in zip(ls,rs):
            cards.append((title,fix_en(L[a:b]),fix_ko(R[c:d])))
    out[n]=cards;print(n,len(cards))
json.dump(out,open('/tmp/claude-0/work/cards4.json','w'),ensure_ascii=False,indent=0)
for n in out:
    for c in out[n][:2]+out[n][5:8]+out[n][-2:]:print(c)
