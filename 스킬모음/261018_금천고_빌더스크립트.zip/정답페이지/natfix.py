import pdfplumber,re,json,sys
sys.path.insert(0,'/tmp/claude-0/work')
import lib
W='\x01'
base="/mnt/user-data/uploads/7. 시험준비 시즌창고/26-2기말_금천고1/2_만든자료/261017_교과서_좌본문우해석/"
out={}
for k in ('3','4'):
    pages=[]
    with pdfplumber.open(base+f"261017_{k}과_좌본문우해석.pdf") as pdf:
        for pg in pdf.pages:
            ws=pg.extract_words()
            lim=[w['top'] for w in ws if w['text'].startswith('1회독')][0]
            hy=min(w['top'] for w in ws if w['text']=='자연스러운' and w['top']>lim)
            my=min(w['top'] for w in ws if w['text']=='memo')
            txt=pg.crop((0,hy+10,pg.width,my-0.5)).extract_text()
            lines=txt.split('\n')
            t=W.join(lines)
            # fix_ko expects module-level W
            lib.W=W
            pages.append(lib.fix_ko(t))
    out[k]=pages
json.dump(out,open('nat.json','w'),ensure_ascii=False,indent=1)
for k in out:
    for i,t in enumerate(out[k]): print(k,i,len(t),t[:70])
