import json,re,html,os,shutil
H=html.escape
D=json.load(open('site_data.json',encoding='utf8'))
HOOK4={
0:"기억고리: 글은 '신경과학의 오랜 치료 연구'에서 출발 — 뇌·척수 같은 신경계 질환.",
1:"기억고리: 지금까지는 신경 임플란트(컴퓨터 칩 같은 의료 기기)의 기능을 연구해 왔다.",
2:"기억고리: But → 전환! 여기에 AI의 급속한 발전이 더해져 AI를 임플란트에 통합하기 시작.",
3:"기억고리: 이 글의 목차 = 장점 → 미래 잠재력 → 윤리적 우려. 이 순서로 읽으면 된다.",
4:"기억고리: First → 먼저 '이 기술이 어떻게 적용됐는지'(의료 분야) 살펴본다.",
5:"기억고리: 의료 분야에서 큰 가능성 + 다양한 문제의 해결책.",
6:"기억고리: 의료 예시 ①: 파킨슨병 같은 뇌 질환 치료.",
7:"기억고리: 방법 = AI의 도움으로 뇌의 표적 부위를 '적시에' 전기 자극 → 정상 뇌 활동 회복.",
8:"기억고리: 의료 예시 ②: 뇌와 척추에 삽입된 두 임플란트 사이의 '디지털 브릿지' → 마비 환자가 다시 걷는다.",
9:"기억고리: 작동 순서 = 다리를 움직이려고 생각 → AI가 뇌 신호 분석 → 임플란트를 통해 다리로 전달.",
10:"기억고리: Similarly → 팔을 잃은 사람도 같은 원리로 작동하는 의수를 사용.",
14:"기억고리: 2단락 → 3단락 전환. 의료의 성공이 다른 산업으로 확산될 것으로 예상(미래 전망 시작).",
15:"기억고리: 미래학자 예측 = 20~30년 안에 상용화 + 우리 일상을 크게 변화.",
16:"기억고리: 미래 예시 ①: 마음을 읽는 소프트웨어를 뇌에 설치하는 것이 가능해진다.",
17:"기억고리: 그 결과(This) 생각만으로 게임·메시지 입력·음악 스트리밍.",
18:"기억고리: 미래 예시 ②: 컴퓨터 메모리 칩 같은 기억력 향상 임플란트.",
19:"기억고리: 기억을 캡처·향상시키고, 클라우드로 업로드·다운로드까지.",
20:"기억고리: 기억 = 소셜 미디어 피드. 훑어보고, 회상하고, 공유하고, 백업.",
21:"기억고리: 미래 예시 ③: 뇌가 일하는 방식 자체에 혁명.",
22:"기억고리: 뇌의 역할 변화 = 학습·저장(예전) → 데이터 처리(앞으로).",
23:"기억고리: 암기 대신 → 지식 다운로드 + 창의력으로 해석 + 새 아이디어 창출.",
24:"기억고리: 4단락 시작. 기술 시대를 받아들이기 전에 까다로운 윤리 문제 해결이 먼저.",
25:"기억고리: 윤리 문제 ① 인간 정체성 — AI와 뇌의 결합은 '인간이란 무엇인가'를 묻게 한다.",
26:"기억고리: 이유 = 뇌는 인간의 정체성·존재·가치의 중심이라고 여겨지기 때문.",
27:"기억고리: However → 기술에 과하게 의존하면 자연스러운 발달이 늦어지고 '나는 인간인가 AI인가' 혼란.",
28:"기억고리: 윤리 문제 ② 프라이버시 (짧은 소개 문장).",
29:"기억고리: 위험 = 조직·해커가 AI와 연결된 임플란트로 허가 없이 개인 정보에 접근.",
30:"기억고리: 더 나아가 생각·감정·행동까지 해커가 통제할 수 있다.",
31:"기억고리: 윤리 문제 ③ 사회적 불평등 — 비용 때문에 모든 사람이 쓰지 못한다.",
32:"기억고리: 임플란트를 감당할 수 있는 사람 vs 없는 사람 → 분열 심화.",
33:"기억고리: 필자의 바람: 신경 윤리(neuroethics)를 신중히 고찰해 이 난제를 극복하자.",
34:"기억고리: 신경 윤리 = 신경 기술의 사회적 측면을 강조하고 합법·윤리의 기준을 제시하는 분야.",
35:"기억고리: 필자 제안 = 뇌 연구를 하기 전에 ① 사전 검토 절차 확립 ② 윤리적 측면 철저 평가.",
36:"기억고리: 목적 = 과학과 기술이 윤리 원칙에 따라 발전하도록 보장.",
37:"기억고리: 독자에게 질문 — 이 기술에 대해 어떻게 생각하나요?",
38:"기억고리: 댓글로 의견을 남겨 달라는 요청. 이어서 댓글 3개(Eric, Yumi, Andy).",
39:"기억고리: Eric = 놀랍다(긍정).",
40:"기억고리: Eric = 장애인이 다시 걷고, 생각대로 움직이는 의수를 쓴다니 믿기지 않는다.",
41:"기억고리: Yumi = 대단하지만 프라이버시 문제가 걱정(양보 → 걱정).",
42:"기억고리: Yumi = 개인 정보 보호법을 엄격히 시행해야 한다.",
43:"기억고리: Andy = 의견을 공유해 준 모두에게 감사.",
44:"기억고리: Andy = 다음 글에서 이 우려를 해결하는 방법을 이야기하겠다(24번 address와 짝).",
45:"기억고리: 본문 외 지문 시작: 인공 수족은 고대로 거슬러 올라가는 역사.",
46:"기억고리: 가장 오래된 예: 기원전 950년경 이집트 미라의 나무 발가락.",
47:"기억고리: 16세기 독일 기사(철의 손 괴츠)가 스프링으로 움직이는 철제 팔을 만들었다.",
48:"기억고리: 세계 대전 → 부상 군인이 늘어 대체품 수요 증가 → 인공 수족 기술이 눈부시게 발전.",
49:"기억고리: Bert Shepard: 다리를 잃고도 의족으로 메이저리그에 복귀한 대표 사례.",
50:"기억고리: 오늘날 = 로봇 공학·AI 같은 첨단 기술의 통합 덕분에 더 발전 중.",
51:"기억고리: 사용자가 복잡한 동작을 하고 생각으로 인공 수족을 제어(본문 AI 임플란트와 연결).",
52:"기억고리: 결론: 이 발전은 사지를 잃은 사람에게 더 나은 삶을 살 자유와 기회를 준다.",
}
SEC4={'①':"한 줄 정리: 신경과학의 치료 연구에 AI가 더해졌다. 이 글은 장점 → 잠재력 → 윤리적 우려 순서로 읽는다.",
'②':"한 줄 정리: 의료 분야 활용 = 파킨슨병 치료 → 디지털 브릿지로 마비 환자가 다시 걷는다 → 의수.",
'③':"한 줄 정리: 미래 전망 = 마음 읽는 소프트웨어 → 기억 임플란트 → 뇌의 역할 변화(암기 → 처리·창의).",
'④':"한 줄 정리: 윤리 문제 세 가지 = 정체성 · 프라이버시 · 불평등. 해결 열쇠는 신경 윤리.",
'⑤':"한 줄 정리: 사전 검토로 윤리적 발전을 보장하자 + 댓글 세 개(Eric 감탄, Yumi 걱정, Andy 마무리).",
'본':"한 줄 정리: 인공 수족의 역사 = 고대 이집트 → 16세기 철의 손 → 세계 대전 → 오늘날 로봇·AI."}
CSS='''
:root{--bg:#f6f8f7;--card:#fff;--ink:#16211f;--sub:#5a6b67;--line:#dbe4e1;--pri:#0f766e;--priL:#e3f3f0;--hi:#fff3bf;--hiInk:#7a4b00;--warn:#b45309;--red:#c0262d;--blue:#1d4ed8;--navy:#1e2a44}
@media(prefers-color-scheme:dark){:root{--bg:#0e1514;--card:#162120;--ink:#e8f0ee;--sub:#9db0ab;--line:#26363a;--pri:#2dd4bf;--priL:#12302d;--hi:#4a3a00;--hiInk:#ffe28a;--warn:#fbbf24;--red:#ff8a80;--blue:#8ab4ff;--navy:#e8f0ee}}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR","Malgun Gothic",sans-serif;line-height:1.6;font-size:17px}
.wrap{max-width:760px;margin:0 auto;padding:16px 16px 80px}
a{color:inherit;text-decoration:none}
.top{display:flex;align-items:center;gap:10px;margin:4px 0 14px}
.back{padding:6px 12px;border:1px solid var(--line);border-radius:999px;font-size:14px;color:var(--sub);background:var(--card)}
h1{font-size:22px;margin:0;line-height:1.3}
.sub{color:var(--sub);font-size:15px;margin:2px 0 14px}
h2{font-size:17px;color:var(--pri);margin:26px 0 8px;padding-bottom:4px;border-bottom:2px solid var(--pri)}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 14px 12px;margin:10px 0}
.num{display:inline-block;min-width:26px;height:26px;line-height:26px;text-align:center;border-radius:8px;background:var(--pri);color:#fff;font-weight:700;font-size:14px;margin-bottom:6px}
.pair{margin:6px 0}
.e{font-size:18px;font-weight:600}
.k{font-size:15.5px;color:var(--sub);padding-left:2px}
mark{background:var(--hi);color:var(--hiInk);border-radius:4px;padding:0 3px}
.blank{display:inline-block;text-align:center;vertical-align:top;margin:0 1px;line-height:1.25}
.blank b{display:block;background:var(--hi);color:var(--hiInk);border-radius:5px;padding:1px 5px;font-size:inherit}
.blank i{display:block;font-style:normal;font-size:12.5px;color:var(--pri);font-weight:600;padding-top:2px}
.kline{font-size:17.5px;margin:10px 0 4px;line-height:2.3}
.sep{color:var(--pri);font-weight:700;margin:0 4px}
ol.t{list-style:none;padding:0;margin:8px 0 0;border-top:1px dashed var(--line)}
ol.t li{padding:7px 0;border-bottom:1px dashed var(--line);font-size:15.5px}
.t .ko{background:var(--hi);color:var(--hiInk);border-radius:5px;padding:0 5px}
.t .en{font-weight:700;color:var(--pri)}
.t .nt{display:block;color:var(--sub);font-size:14.5px;margin-top:2px}
.hook{margin-top:10px;background:var(--priL);border-left:4px solid var(--pri);border-radius:8px;padding:8px 12px;font-size:15px}
.pre{margin:14px 0 4px;background:var(--priL);border-radius:10px;padding:9px 13px;font-size:15px}
.tog{position:sticky;top:0;z-index:5;background:var(--bg);padding:8px 0;display:flex;gap:8px}
.tog button{border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;padding:7px 14px;font-size:14px}
.tog button.on{background:var(--pri);color:#fff;border-color:var(--pri)}
.hide .k{visibility:hidden}.hide .k:active,.hide .k.show{visibility:visible}
.steps a{display:flex;gap:12px;align-items:flex-start;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 14px;margin:9px 0}
.steps .n{flex:none;width:30px;height:30px;line-height:30px;text-align:center;border-radius:50%;background:var(--pri);color:#fff;font-weight:700}
.steps .tt{font-weight:700}.steps .ds{font-size:14.5px;color:var(--sub)}
.steps .st{margin-left:auto;font-size:12.5px;color:var(--pri);border:1px solid var(--pri);border-radius:999px;padding:1px 9px;white-space:nowrap;flex:none}
.steps a.off{opacity:.55;pointer-events:none}.steps a.off .n{background:var(--sub)}.steps a.off .st{color:var(--sub);border-color:var(--sub)}
.tabs{display:flex;gap:8px;margin:6px 0 4px}
.tabs button{flex:1;padding:11px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--ink);font-size:17px;font-weight:700}
.tabs button.on{background:var(--pri);color:#fff;border-color:var(--pri)}
.pane{display:none}.pane.on{display:block}
.e{color:var(--navy)}
.k{font-size:17px;color:var(--ink);border-left:4px solid var(--pri);padding:2px 0 2px 10px;margin-top:3px;background:var(--priL);border-radius:0 8px 8px 0}
.k b{color:var(--red);font-weight:800}
.hide .k{background:var(--card)}
.legend{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;font-size:15px;margin:8px 0 6px}
.legend .r{color:var(--red);font-weight:800}.legend .bl{color:var(--blue);font-weight:800}
.blank b{display:block;color:var(--red);background:none;font-weight:800;border-bottom:2.5px solid var(--red);padding:0 3px 1px;font-size:inherit;border-radius:0}
.blank sup{display:block;font-size:10.5px;color:var(--sub);line-height:1}
.blank i{color:var(--blue);font-size:13px;font-weight:700}
ol.t li{font-size:16.5px;padding:9px 0}
.t .n2{display:inline-block;width:20px;color:var(--sub);font-size:13px}
.t .ko{background:none;color:var(--red);font-weight:800;padding:0}
.t .en{color:var(--blue);font-weight:800}
.t .nt{color:var(--ink);opacity:.82;font-size:15px;margin-left:22px;margin-top:3px}
.hook{font-size:15.5px;font-weight:500}
.e mark sup{font-size:10.5px;color:var(--red);font-weight:800;margin-left:1px}
.foot{margin-top:30px;color:var(--sub);font-size:13px;text-align:center}
'''
def page(title,body,sub='',back='../index.html',extra_js=''):
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f766e"><title>{H(title)}</title><style>{CSS}</style></head><body><div class="wrap"><div class="top"><a class="back" href="{back}">← 목록</a></div><h1>{H(title)}</h1><div class="sub">{H(sub)}</div>{body}<div class="foot">비타민 영어클리닉 · 금천고 공통영어2</div></div><script>{extra_js}</script></body></html>'''
def split(s):  return [x.strip() for x in (s if isinstance(s,list) else s.split(' / '))]
def sections(L):
    out=[];cur=None
    for d in D[L]:
        if cur is None or cur[0]!=d['sec']: cur=[d['sec'],[]];out.append(cur)
        cur[1].append(d)
    return out
def english_hl(en,terms):
    s=H(en)
    for t in sorted(set(terms),key=len,reverse=True):
        tt=t.replace('-','[-‑]').replace(' ','\\s')
        s=re.sub(r'(?i)(?<![A-Za-z])('+tt+')(?![A-Za-z])',r'<mark>\1</mark>',s,count=1) if re.search(r'(?i)'+tt,s) else s
    return s
# ---- 좌본문우해석 ----
def jwa(L):
    body='<div class="tog"><button id="b1" class="on">해석 보이기</button><button id="b2">해석 가리기 (누르고 있으면 보임)</button></div><div id="list">'
    for sec,items in sections(L):
        body+=f'<h2>{H(sec)}</h2>'
        for n,d in enumerate(items,1):
            body+=f'<div class="card"><span class="num">{n}</span>'
            for e,k in zip(split(d['en']),split(d['ko'])):
                body+=f'<div class="pair"><div class="e">{H(e)}</div><div class="k">{H(k)}</div></div>'
            body+='</div>'
    body+='</div>'
    js="var l=document.getElementById('list'),a=document.getElementById('b1'),b=document.getElementById('b2');a.onclick=function(){l.className='';a.className='on';b.className=''};b.onclick=function(){l.className='hide';b.className='on';a.className=''};document.addEventListener('touchstart',function(e){var k=e.target.closest&&e.target.closest('.k');if(k)k.classList.add('show')});document.addEventListener('touchend',function(){document.querySelectorAll('.k.show').forEach(function(x){x.classList.remove('show')})});"
    return page(f'{L}과 좌본문우해석',body,'영어 조각과 해석 조각이 순서대로 짝이에요. 읽으면서 영어 → 한글 순서로 이어 보세요.',extra_js=js)
# ---- 한글채우기 정답 ----
def kfill(d):
    ko=d['ko'];sp=d['spans'];s='';p=0;nn=0
    for st,e,a,t in sp:
        nn+=1
        s+=H(ko[p:st]).replace(' / ',' <span class="sep">/</span> ')+f'<span class="blank"><b>{H(a)}</b><sup>{nn}</sup><i>{H(t)}</i></span>'
        p=e
    s+=H(ko[p:]).replace(' / ',' <span class="sep">/</span> ')
    return s

UNMATCHED=[]
def english_num(en_list,spans,key=''):
    text=' / '.join(en_list).replace('heart- warming','heart-warming')
    taken=[];found={}
    for j,(st,e,a,t) in enumerate(spans,1):
        base=re.escape(t).replace('\\-','[-‑\\s]')
        pats=[base.replace('\\ ','\\s'),base.replace('\\ ','\\s+(?:[A-Za-z]+\\s+)?')]
        m=None
        for tt in pats:
            for pat in (r'(?i)(?<![A-Za-z])('+tt+r')(?![A-Za-z])', r'(?i)(?<![A-Za-z])('+tt+r')'):
                for mm in re.finditer(pat,text):
                    if all(mm.end()<=x or mm.start()>=y for x,y in taken): m=mm;break
                if m: break
            if m: break
        if m: taken.append((m.start(),m.end()));found[(m.start(),m.end())]=[j]
        else:
            prev=[k for k in found if re.fullmatch(pats[0],text[k[0]:k[1]],re.I)]
            if prev: found[prev[0]].append(j)
            else: UNMATCHED.append((key,j,t))
    out='';p=0
    for (x,y),js in sorted(found.items()):
        out+=H(text[p:x]).replace(' / ',' <span class="sep">/</span> ')+f'<mark>{H(text[x:y])}<sup>{",".join(map(str,js))}</sup></mark>';p=y
    out+=H(text[p:]).replace(' / ',' <span class="sep">/</span> ')
    return out
def hangeul(L):
    return _hangeul(L)
def _hangeul(L):
    body='<div class="legend">활동지의 <b>한글 문장 그대로</b> 빈칸에 <span class="r">빨간 정답</span>을 채웠고, 정답 밑에 <span class="bl">파란 영어 단어</span>를 붙였어요. 영어 문장에도 <mark>노란 표시</mark>와 같은 번호가 붙어 있어 어느 단어인지 바로 찾을 수 있어요. 번호 목록에는 단어별 주의점이, 초록 상자에는 본문이 떠오르는 기억고리가 있어요.</div>'
    for sec,items in sections(L):
        body+=f'<h2>{H(sec)}</h2>'
        if L=='4': body+=f'<div class="pre">{H(SEC4[sec[0]])}</div>'
        for n,d in enumerate(items,1):
            if d.get('pre'): body+=f'<div class="pre">{H(d["pre"][1] or "")}</div>' if d['pre'][1] else ''
            body+=f'<div class="card"><span class="num">{n}</span><div class="e" style="font-size:16px;font-weight:600">{english_num(split(d["en"]),d["spans"],L+":"+str(d["i"]))}</div><div class="kline">{kfill(d)}</div><ol class="t">'
            for j,(st,e,a,t) in enumerate(d['spans'],1):
                nt=(d.get('notes') or {}).get(t,'')
                body+=f'<li><span class="n2">{j}</span><span class="ko">{H(a)}</span> = <span class="en">{H(t)}</span>'+(f'<span class="nt">{H(nt)}</span>' if nt else '')+'</li>'
            body+='</ol>'
            hk=d.get('hook') or HOOK4.get(d['i']) if L=='4' else d.get('hook')
            if L=='4': hk=HOOK4.get(d['i'])
            if hk: body+=f'<div class="hook">{H(hk)}</div>'
            body+='</div>'
    return page(f'{L}과 한글채우기 정답',body,'빈칸 활동지와 같은 모양이에요. 채울 말은 빨간색, 그 아래에 영어가 파란색으로 함께 있어요.')
def kohl(k,answers):
    s=H(k)
    for a in sorted(set(answers),key=len,reverse=True):
        aa=H(a.strip())
        if aa and aa in s and ('<b>'+aa) not in s: s=s.replace(aa,'<b>'+aa+'</b>',1)
    return s
# ---- 영어채우기 정답 ----
def yeongeo(L):
    body=''
    for sec,items in sections(L):
        body+=f'<h2>{H(sec)}</h2>'
        for n,d in enumerate(items,1):
            terms=[t for _,_,_,t in d['spans']]
            answers=[a for _,_,a,_ in d['spans']]
            body+=f'<div class="card"><span class="num">{n}</span>'
            for e,k in zip(split(d['en']),split(d['ko'])):
                body+=f'<div class="pair"><div class="e">{english_hl(e,terms)}</div><div class="k">{kohl(k,answers)}</div></div>'
            body+='<ol class="t">'
            for j,(st,e,a,t) in enumerate(d['spans'],1):
                nt=(d.get('notes') or {}).get(t,'')
                body+=f'<li><span class="n2">{j}</span><span class="en">{H(t)}</span> = <span class="ko">{H(a)}</span>'+(f'<span class="nt">{H(nt)}</span>' if nt else '')+'</li>'
            body+='</ol></div>'
    return page(f'{L}과 영어채우기 정답',body,'영어 조각 아래에 그 뜻이 바로 있어요. 노란 표시가 빈칸에 들어갈 영어예요.')
STEPS=[
 ('클래스카드 단어 돌리기','수업 시작 전에 단어부터. 클래스카드 앱에서 해요.',None),
 ('좌본문우해석','영어와 해석을 조각 단위로 짝지어 읽어요.','jwa'),
 ('한글채우기 정답','한국어 어순 빈칸 활동지의 정답이에요.','hangeul'),
 ('어법선택','준비 중이에요.',None),
 ('동사형','준비 중이에요.',None),
 ('기출예상 1~4회','준비 중이에요.',None),
 ('영어채우기 정답','영어 빈칸 활동지의 정답이에요.','yeongeo'),
 ('틀린 곳 고치기 · Check','준비 중이에요.',None)]
def hub():
    TT={'3':'3과 The True Art Lovers','4':'4과 AI Neural Implants'}
    body=''
    for L in '34':
        body+=f'<h2>{H(TT[L])}</h2><div class="steps">'
        for t,key in [('좌본문우해석','jwa'),('한글채우기 정답','hangeul'),('영어채우기 정답','yeongeo')]:
            body+=f'<a href="{L}/{key}.html"><div><div class="tt">{H(t)}</div></div><span class="st">열기</span></a>'
        body+='</div>'
    body+='<div class="foot" style="margin-top:22px">어법선택 · 동사형 · 기출예상 정답은 준비되는 대로 이곳에 더해져요.</div>'
    return page('금천고 기말고사 정답',body,'공통영어2 미래엔(김) · 내가 한 활동지를 골라 정답을 확인하세요.',back='../').replace('<div class="top"><a class="back" href="../">← 목록</a></div>','<div class="top"></div>')
out='/tmp/claude-0/site/geumcheon-gimal'
if os.path.exists(out): shutil.rmtree(out)
os.makedirs(out+'/3');os.makedirs(out+'/4')
open(out+'/index.html','w',encoding='utf8').write(hub())
for L in '34':
    for k,f in (('jwa',jwa),('hangeul',hangeul),('yeongeo',yeongeo)):
        open(f'{out}/{L}/{k}.html','w',encoding='utf8').write(f(L))
print(os.listdir(out),[os.path.getsize(f'{out}/{L}/{k}.html') for L in '34' for k in('jwa','hangeul','yeongeo')])

print('UNMATCHED',UNMATCHED)
