import pdfplumber,re,json
from kiwipiepy import Kiwi
kw=Kiwi()
base="/mnt/user-data/uploads/7. 시험준비 시즌창고/26-2기말_금천고1/2_만든자료/261017_교과서_좌본문우해석/261017_%s과_좌본문우해석.pdf"
W='\x01'
def stream(n,right):
    s=''
    with pdfplumber.open(base%n) as p:
        for pg in p.pages:
            lim=min([w['top'] for w in pg.extract_words() if w['text']=='1회독'] or [9999])-1
            last=None
            for c in pg.chars:
                if not(90<c['top']<lim): continue
                if (c['x0']>=405)!=right: continue
                t=' ' if c['text'] in '\t\n' else c['text']
                if last is not None and abs(c['top']-last)>3 and t!=' ': s+=W
                last=c['top'];s+=t
            s+=W+'\x02'+W
    return s
def split_items(s,counts=None):
    # returns list of (sec, [items]) ; s uses markers
    parts=re.split(r'([①-⑩])',s)
    out=[]
    for i in range(1,len(parts),2):
        body=parts[i+1]
        idx=[];pos=0
        for k in range(1,80):
            m=re.search(r'(?:^|[\s\x01\x02])%d\.(?=\D)'%k,body[pos:])
            if not m: break
            idx.append(pos+m.start());pos+=m.end()
        title=body[:idx[0]] if idx else body
        its=[]
        for a,b in zip(idx,idx[1:]+[len(body)]):
            its.append(re.sub(r'^[\s\x01\x02]*\d+\.','',body[a:b]))
        out.append((parts[i]+' '+title,its))
    return out
def fix_en(t):
    t=t.replace('\x02','').replace(W,' ');return re.sub(r'\s+',' ',t).strip()
def score(t): 
    return kw.analyze(t)[0][1]
def fix_ko(t):
    t=t.replace('\x02','')
    segs=t.split(W)
    cur=segs[0]
    for nx in segs[1:]:
        a=cur.rstrip();b=nx.lstrip()
        if cur.endswith(' ') or nx.startswith(' ') or not a or not b: cur=a+' '+b if a and b else a+b;continue
        ctx_a=a[-12:];ctx_b=b[:12]
        s1=score(ctx_a+ctx_b);s2=score(ctx_a+' '+ctx_b)
        cur=a+('' if s1>=s2 else ' ')+b
    return re.sub(r'\s+',' ',cur).strip()
out={}
for n in (3,4):
    Ls=split_items(stream(n,False));Rs=split_items(stream(n,True)) if False else None
    Rraw=stream(n,True)
    # right: no headers; split by consuming per left section counts
    cards=[];pos=0
    for t,items in Ls:
        k=0;idx=[];p2=pos
        for k in range(1,len(items)+1):
            m=re.search(r'(?:^|[\s\x01\x02])%d\.(?=\D)'%k,Rraw[p2:])
            idx.append(p2+m.start());p2+=m.end()
        # section end: next occurrence of '1.' after last
        ends=idx[1:]
        m=re.search(r'(?:^|[\s\x01\x02])1\.(?=\D)',Rraw[p2:])
        endlast=p2+m.start() if m else len(Rraw)
        ends=ends+[endlast]
        for e,a,b in zip(items,idx,ends):
            h=re.sub(r'^[\s\x01\x02]*\d+\.','',Rraw[a:b])
            cards.append((t.replace(W,' ').replace('\x02',''),fix_en(e),fix_ko(h)))
        pos=endlast
    out[n]=cards;print(n,len(cards))
json.dump(out,open('cards3.json','w'),ensure_ascii=False,indent=0)
for n in out:
    for c in out[n][:3]+out[n][5:7]+out[n][-2:]:print(c)
