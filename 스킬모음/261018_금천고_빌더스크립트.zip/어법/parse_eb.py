import re,json,html
R='/home/claude/via-high/h/geumcheon-gimal/'
out={}
for L in '34':
    t=open(f'{L}.txt',encoding='utf8').read()
    lines=[l.strip() for l in t.split('\n')]
    eng=[l for l in lines if re.search(r'\[[^\]]+/[^\]]+\]',l) and re.search(r'[A-Za-z]{3}',l)]
    s=open(R+f'{L}/eobeop.html',encoding='utf8').read()
    qs=re.findall(r'<div class="q" id="q(\d+)"><div class="qh"><span class="no">\d+</span><span class="ans"><small>정답</small>(.*?)</span></div><div class="en">(.*?)</div><div class="ko">(.*?)</div>',s)
    print(L,'worksheet items',len(eng),'repo q',len(qs))
    items=[]
    for k,(n,ans,en,ko) in enumerate(qs):
        w=eng[k] if k<len(eng) else ''
        brs=re.findall(r'\[([^\]]+)\]',w)
        a=[x.strip() for x in html.unescape(ans).split('/')]
        # 정답 = 각 괄호의 두 보기 중 정답
        ok=len(brs)==len(a)
        for b,x in zip(brs,a):
            opts=[o.strip() for o in b.split('/')]
            if x not in opts and x.replace('’',"'") not in [o.replace('’',"'") for o in opts]: ok=False
        # 정답 앱 영어(굵은 곳)와 워크시트 영어 대조
        plain=re.sub(r'<.*?>','',html.unescape(en)).replace(' / ',' ')
        wplain=re.sub(r'\[([^\]]+)\]',lambda m:'<<'+m.group(1)+'>>',w)
        items.append(dict(n=int(n),ans=a,brs=[[o.strip() for o in b.split('/')] for b in brs],ws=w,ok=ok))
        if not ok: print('  MISMATCH',n,ans,'|',brs)
    out[L]=items
json.dump(out,open('items.json','w'),ensure_ascii=False)
