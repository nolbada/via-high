# -*- coding: utf-8 -*-
import json,re,html,os
R='/home/claude/via-high/h/geumcheon-gimal/'
src=open(R+'3/eobeop.html',encoding='utf8').read()
CSS0=src[src.index('<style>')+7:src.index('</style>')]
EXTRA='''
.bar{position:sticky;top:0;z-index:5;background:var(--bg);padding:8px 0;border-bottom:1px solid var(--line);display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:15px}
.bar b{color:var(--pri)}.bar button{margin-left:auto;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;padding:5px 13px;font-size:14px}
.tq{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin:14px 0;scroll-margin-top:60px}
.tq .th{display:flex;gap:8px;align-items:center;margin-bottom:6px}
.tq .tn{background:var(--navy);color:var(--card);border-radius:8px;font-size:13px;font-weight:800;padding:1px 9px}
.sl{font-size:19px;line-height:2.1;font-weight:600;color:var(--navy);margin:2px 0}
.bk{display:inline-flex;align-items:center;gap:2px;margin:0 2px;white-space:nowrap}
.bk button{font:inherit;font-weight:700;color:var(--ink);background:var(--bg);border:1.5px solid var(--line);border-radius:9px;padding:0 9px;line-height:1.7}
.bk i{font-style:normal;color:var(--sub);font-size:14px}
.bk button.sel{border-color:var(--blue);background:#e6eeff;color:var(--blue)}
@media(prefers-color-scheme:dark){.bk button.sel{background:#1c2a4d}}
.bk button.ok{border-color:var(--pri);background:var(--okBg,#eefaf3);color:var(--pri)}
.bk button.ng{border-color:#c0262d;background:#fdeeee;color:#c0262d;text-decoration:line-through}
@media(prefers-color-scheme:dark){.bk button.ng{background:#3a1d1d;color:#ff8a80}.bk button.ok{background:#12302d}}
.go{display:block;margin:10px 0 2px;width:100%;font:inherit;font-weight:700;font-size:16px;border:0;border-radius:12px;padding:10px;background:var(--pri);color:#fff}
.go[disabled]{opacity:.45}
.fb{display:none;margin-top:10px;border-top:1px dashed var(--line);padding-top:8px}
.tq.done .fb{display:block}.tq.done .go{display:none}
.tq.done .bk button{pointer-events:none}
.res{font-weight:800;margin-bottom:4px}.res.o{color:var(--pri)}.res.x{color:#c0262d}
.secd{margin:24px 0 2px;font-size:15px;font-weight:800;color:var(--pri);border-bottom:2px solid var(--pri);padding-bottom:3px}
.sum{display:none;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin:20px 0}
.sum.on{display:block}.sum h2{margin:0 0 6px;border:0}
.sum a{display:inline-block;margin:3px 6px 3px 0;padding:2px 11px;border:1px solid #c0262d;border-radius:999px;color:#c0262d;font-weight:700}
.kk{border-left:4px solid var(--pri);background:var(--priL);border-radius:0 8px 8px 0;padding:6px 11px;margin:6px 0;font-size:16px}
'''
JS='''<script>
(function(){var T=document.querySelectorAll('.tq'),tot=0,got=0,dn=0,bar=document.getElementById('cnt'),sum=document.getElementById('sum');
T.forEach(function(q){tot+=q.querySelectorAll('.bk').length});
function up(){bar.innerHTML=dn+' / '+T.length+' 문제 · 정답 <b>'+got+'</b> / '+tot+'칸'}
function chk(q){var ok=true;q.querySelectorAll('.bk').forEach(function(b){if(!b.querySelector('.sel'))ok=false});q.querySelector('.go').disabled=!ok}
T.forEach(function(q){q.addEventListener('click',function(e){var b=e.target.closest('.bk button');if(b&&!q.classList.contains('done')){b.parentNode.querySelectorAll('button').forEach(function(x){x.classList.remove('sel')});b.classList.add('sel');chk(q);return}
var g=e.target.closest('.go');if(!g||g.disabled)return;var all=true,n=0,m=0;
q.querySelectorAll('.bk').forEach(function(bk){var a=+bk.dataset.a,bs=bk.querySelectorAll('button'),s=bk.querySelector('.sel');n++;bs[a].classList.remove('sel');bs[a].classList.add('ok');if(s!==bs[a]){s.classList.remove('sel');s.classList.add('ng');all=false}else m++});
q.classList.add('done');q.dataset.ok=all?'1':'0';dn++;got+=m;var r=q.querySelector('.res');r.className='res '+(all?'o':'x');r.textContent=all?'모두 정답이에요':'틀린 칸이 있어요 ('+m+' / '+n+')';up();
if(dn===T.length){var w=[];T.forEach(function(x){if(x.dataset.ok!=='1')w.push('<a href="#'+x.id+'">'+x.dataset.no+'</a>')});
sum.innerHTML='<h2>결과</h2><div>'+got+' / '+tot+'칸 정답</div>'+(w.length?'<div style="margin-top:6px">틀린 문제(본문 순서): '+w.join('')+'</div>':'<div style="margin-top:6px">전부 맞혔어요.</div>');sum.classList.add('on');sum.scrollIntoView({behavior:'smooth'})}})});
document.getElementById('rs').onclick=function(){T.forEach(function(q){q.classList.remove('done');q.dataset.ok='';q.querySelectorAll('.bk button').forEach(function(x){x.classList.remove('sel','ok','ng')});q.querySelector('.go').disabled=true});dn=0;got=0;sum.classList.remove('on');up();window.scrollTo(0,0)};up()})();
</script>'''
for L,ti in (('3','The True Art Lovers'),('4','AI Neural Implants')):
    cards=json.load(open(f'cards{L}.json',encoding='utf8')); body='';cur=None
    for c in cards:
        if c['sec']!=cur:
            cur=c['sec']; body+='<div class="secd">%s</div>'%html.escape(cur or '')
        no=c['id'].replace('-','~')
        body+=('<div class="tq" id="t%s" data-no="%s"><div class="th"><span class="tn">%s</span></div>%s<button type="button" class="go" disabled>정답 확인</button>'
          '<div class="fb"><div class="res"></div><div class="kk">%s</div><span class="tag">해설</span>%s</div></div>')%(c['id'],no,no,c['sh'],c['ko'],''.join(c['pts']))
    page=('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f766e"><title>%s과 어법선택 시험</title><style>%s%s</style>'
      '<link rel="icon" type="image/svg+xml" href="../icon.svg"><link rel="apple-touch-icon" href="../icon-180.png"><meta name="apple-mobile-web-app-title" content="금천고정답"></head><body><div class="wrap">'
      '<div class="top"><a class="back" href="../index.html">← 금천고 정답 목록</a></div><h1>%s과 %s · 어법선택 시험</h1>'
      '<p class="lede">본문 순서대로 풀어요. 괄호마다 알맞은 쪽을 고르고 <b>정답 확인</b>을 누르면 해설이 나와요.</p><div class="bar"><span id="cnt"></span><button id="rs">처음부터 다시</button></div>%s'
      '<div class="sum" id="sum"></div><div class="foot">비타민 영어클리닉 · 금천고 공통영어2</div></div>%s</body></html>')%(L,CSS0,EXTRA,L,ti,body,JS)
    os.makedirs('/tmp/claude-0/w/eb/out',exist_ok=True)
    open(f'/tmp/claude-0/w/eb/out/eobeop-test{L}.html','w',encoding='utf8').write(page); print(L,len(page))
