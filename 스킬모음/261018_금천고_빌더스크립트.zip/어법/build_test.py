# -*- coding: utf-8 -*-
import re,json,html
R='/home/claude/via-high/h/geumcheon-gimal/'
C=json.load(open('/tmp/claude-0/w/work/cards_final.json'))
def clean(t):
    t=re.sub(r'[①-⑩]','',t).replace(' / ',' ').replace('/ ',' ').replace('heart- warming','heart-warming'); return re.sub(r'\s+',' ',t).strip()
E_=html.escape
def unesc(x): return html.unescape(x)
def norm(x): return re.sub(r'[^a-z0-9]','',unesc(x).lower())
for L,title in (('3','The True Art Lovers'),('4','AI Neural Implants')):
    t=open(f'{L}.txt',encoding='utf8').read()
    lines=[l.strip() for l in t.split('\n')]
    eng=[l for l in lines if re.search(r'\[[^\]]+/[^\]]+\]',l) and re.search(r'[A-Za-z]{3}',l)]
    s=open(R+f'{L}/eobeop.html',encoding='utf8').read()
    qblocks=re.findall(r'(<div class="q" id="q([\d-]+)">.*?)(?=<div class="q" id="q|<div class="foot">)',s,re.S)
    # section map
    secs=[(norm(clean(c[1]))[:30],re.sub(r'^[①-⑩]\s*','',c[0])) for c in C[L]]
    cards=[];k=0;prev=None
    for blk,qid in qblocks:
        n_lines=4 if qid=='12-15' else 1
        ws=eng[k:k+n_lines];k+=n_lines
        pts=re.findall(r'<div class="pt">(.*?)</div></div>(?=<div class="pt">|</div>$|$)',blk.split('<span class="tag">해설</span>')[1],re.S)
        tail=blk.split('<span class="tag">해설</span>')[1]
        pieces=['<div class="pt">'+x for x in tail.split('<div class="pt">')[1:]]
        pt_html=[]
        for p in pieces:
            while p.count('<div')<p.count('</div>'):
                p=p[:p.rindex('</div>')]
            assert p.count('<div')==p.count('</div>')
            pt_html.append(p)
        ko=re.search(r'<div class="ko">(.*?)</div>',blk,re.S).group(1)
        ans=[x.strip() for x in unesc(re.search(r'</small>(.*?)</span>',blk).group(1)).split('/')]
        # blanks
        blanks=[]
        for w in ws:
            for b in re.findall(r'\[([^\]]+)\]',w): blanks.append([o.strip() for o in b.split('/')])
        assert len(blanks)==len(ans)==len(pt_html),(L,qid,len(blanks),len(ans),len(pt_html))
        for b,a in zip(blanks,ans):
            assert any(norm(a)==norm(o) for o in b),(L,qid,a,b)
        # 정답 index
        aidx=[[norm(o) for o in b].index(norm(a)) for b,a in zip(blanks,ans)]
        # sentence html
        bi=0;sh=''
        for w in ws:
            parts=re.split(r'(\[[^\]]+\])',w); line=''
            for p in parts:
                if p.startswith('['):
                    opts=[o.strip() for o in p[1:-1].split('/')]
                    line+='<span class="bk" data-a="%d"><button type="button" data-i="0">%s</button><i>/</i><button type="button" data-i="1">%s</button></span>'%(aidx[bi],E_(opts[0]),E_(opts[1])); bi+=1
                else: line+=E_(p)
            sh+='<div class="sl">%s</div>'%line.strip()
        # section
        first=norm(re.sub(r'<.*?>','',unesc(ws[0])).replace('[','').replace(']',''))
        sec=None
        enp=norm(re.sub(r'<.*?>',' ',blk.split('<div class="en">')[1].split('</div>')[0]).replace('/',''))[:30]
        for key,lab in secs:
            if key==enp: sec=lab;break
        cards.append(dict(id=qid,sec=sec,sh=sh,ko=ko,pts=pt_html,n=len(blanks)))
    # fill missing secs by forward-fill
    last=None
    for c in cards:
        if c['sec']: last=c['sec']
        else: c['sec']=last
    print(L,len(cards),sum(c['n'] for c in cards),'blanks; secs',sorted({c['sec'] for c in cards if c['sec']}),'nosec',sum(1 for c in cards if not c['sec']))
    json.dump(cards,open(f'cards{L}.json','w',encoding='utf8'),ensure_ascii=False)
