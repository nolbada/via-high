from playwright.sync_api import sync_playwright
import re
with sync_playwright() as p:
    b=p.chromium.launch()
    for L in '34':
        pg=b.new_page(viewport={'width':420,'height':900}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'file:///tmp/claude-0/w/eb/out/eobeop-test{L}.html')
        n=pg.locator('.tq').count(); blanks=pg.locator('.bk').count()
        # 정답만 선택
        pg.evaluate("document.querySelectorAll('.bk').forEach(function(b){b.querySelectorAll('button')[+b.dataset.a].click()})")
        pg.evaluate("document.querySelectorAll('.go').forEach(function(g){g.click()})")
        print(L,n,blanks,pg.inner_text('#cnt'),'|',pg.inner_text('#sum').replace('\n',' '),errs)
        s=open(f'out/eobeop-test{L}.html',encoding='utf8').read()
        print(' div balance',s.count('<div')-s.count('</div>'), 'secd',re.findall(r'class="secd">(.*?)<',s))
