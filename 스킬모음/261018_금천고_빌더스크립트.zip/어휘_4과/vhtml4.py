# -*- coding: utf-8 -*-
import json,html
Q=json.load(open('/tmp/claude-0/w/agentC/4/q.json'))
CSS=open('/mnt/user-data/uploads/Github 어플모음/1_작업중/261017_via_h_업로드/h/geumcheon-gimal/3/awkward.html',encoding='utf8').read()
CSS=CSS[CSS.index('<style>')+7:CSS.index('</style>')]
CSS=CSS[:CSS.index('/* quick answers */')]+'''
.bar{position:sticky;top:0;z-index:5;background:var(--bg);padding:8px 0;border-bottom:1px solid var(--line);display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:15px}
.bar b{color:var(--pri)}.bar button{margin-left:auto;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;padding:5px 13px;font-size:14px}
.q{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px 14px 12px;margin:14px 0}
.qh{display:flex;gap:8px;align-items:center;margin-bottom:6px}
.qn{background:var(--navy);color:var(--card);border-radius:8px;font-size:13px;font-weight:800;padding:1px 9px}
.tg{font-size:12px;font-weight:800;color:var(--pri);border:1px solid var(--pri);border-radius:999px;padding:0 8px}
.stem{font-size:18.5px;font-weight:600;color:var(--navy);line-height:1.8;margin:2px 0 4px}
.stem u{text-decoration:none;color:var(--ans);font-weight:800;border-bottom:2.5px solid var(--ans)}
.ask{font-size:16px;color:var(--sub);margin:2px 0 8px}.ask b{color:var(--ink)}
.ob{display:block;width:100%;text-align:left;font:inherit;font-size:16.5px;line-height:1.55;color:var(--ink);background:var(--bg);border:1.5px solid var(--line);border-radius:11px;padding:8px 12px;margin:6px 0}
.ob small{color:var(--sub);font-size:14px}
.ob .k{display:block;color:var(--sub);font-size:14px;margin-top:2px}
.done .ob{pointer-events:none}
.ob.ok{border-color:var(--pri);background:var(--okBg);font-weight:700}
.ob.ng{border-color:var(--ans);background:var(--ngBg)}
.ex{display:none;margin-top:8px;border-top:1px dashed var(--line);padding-top:8px;font-size:16px}
.done .ex{display:block}
.res{font-weight:800;margin-bottom:3px}.res.o{color:var(--pri)}.res.x{color:var(--ans)}
.ex .wd{color:var(--sub);font-size:15px;margin:2px 0}
.ex .kk{border-left:4px solid var(--pri);background:var(--priL);border-radius:0 8px 8px 0;padding:6px 11px;margin:6px 0;font-size:15.5px}
.ex ol{margin:4px 0 2px;padding-left:20px;color:var(--sub);font-size:15px}.ex ol li.m{color:var(--pri);font-weight:800}
mark{background:#ffe3e0;color:#8a1c1c;border-radius:4px;padding:0 3px}
@media(prefers-color-scheme:dark){mark{background:#4a2224;color:#ffb4ae}}
.sechd{margin:26px 0 4px}
.foot{margin-top:28px;text-align:center;font-size:13px;color:var(--sub)}
'''
SEC={'trap':'① 단어 함정','syn':'② 유의어 · 반의어','poly':'③ 다의어'}
NAMES=['도입과 의료 분야 활용','미래 전망','윤리적 문제','신경 윤리와 댓글']
HOW={'syn':'밑줄 친 단어와 뜻이 가까운(또는 반대인) 단어를 골라요. 보기마다 우리말 뜻이 같이 있어요.',
 'trap':'본문 문장 네 개 중 <b>단어 하나가 바뀐</b> 문장을 찾아요. 문맥으로 판단해요.',
 'poly':'문장 속 밑줄 친 단어의 뜻을 보기에서 골라요. 보기는 그 단어가 가진 뜻 전부예요.'}
def card(n,q):
    ans=q['ans']; h='<div class="q" data-a="%d"><div class="qh"><span class="qn">%d</span><span class="tg">%s</span></div>'%(ans,n,q['tag'])
    if q['stem']: h+='<div class="stem">%s</div>'%q['stem']
    h+='<div class="ask">%s</div>'%q['ask']
    for i,o in enumerate(q['opts']):
        if q['sec']=='trap':
            h+='<button class="ob" data-i="%d">%s<span class="k"></span></button>'%(i,o['s'])
        else: h+='<button class="ob" data-i="%d">%s</button>'%(i,o)
    h+='<div class="ex"><div class="res"></div>'
    if q['sec']=='trap':
        h+='<div class="wd">바뀐 부분: <mark>%s</mark> ← 본문은 <b>%s</b></div>'%(q['new'],q['orig'])
        h+='<div class="why">%s</div><div class="kk">본문 해석 · %s</div>'%(q['why'],q['ko'])
        h+='<div class="wd">네 문장의 해석</div><ol>'+''.join('<li%s>%s</li>'%(' class="m"' if o['f'] else '',o['ko']) for o in q['opts'])+'</ol>'
    elif q['sec']=='poly':
        h+='<div class="kk">%s</div><div class="wd"><b>%s</b>의 뜻</div><ol>'%(q['ko'],q['word'])
        h+=''.join('<li%s>%s</li>'%(' class="m"' if i==ans else '',m) for i,m in enumerate(q['all']))+'</ol>'
    else:
        h+='<div class="wd">%s</div><div class="why">%s</div><div class="kk">본문 해석 · %s</div>'%(q['word'],q['why'],q['ko'])
    return h+'</div></div>'
JS='''<script>
(function(){var qs=document.querySelectorAll('.q'),T=qs.length,d=0,c=0,bar=document.getElementById('cnt');
function up(){bar.innerHTML=d+' / '+T+' 풀었어요 · 정답 <b>'+c+'</b>개'}
qs.forEach(function(q){q.addEventListener('click',function(e){var b=e.target.closest('.ob');if(!b||q.classList.contains('done'))return;
var a=+q.dataset.a,i=+b.dataset.i,os=q.querySelectorAll('.ob');q.classList.add('done');d++;
os[a].classList.add('ok');var r=q.querySelector('.res');
if(i===a){c++;r.className='res o';r.textContent='정답이에요'}else{b.classList.add('ng');r.className='res x';r.textContent='아쉬워요. 정답은 '+'①②③④⑤'[a]+'번'}
up()})});
document.getElementById('rs').onclick=function(){qs.forEach(function(q){q.classList.remove('done');q.querySelectorAll('.ob').forEach(function(o){o.classList.remove('ok','ng')})});d=0;c=0;up();window.scrollTo(0,0)};
up()})();
</script>'''
for bi,qs in enumerate(Q):
    body='';n=0;cur=None
    for q in qs:
        if q['sec']!=cur:
            cur=q['sec'];body+='<h2 class="sechd">%s</h2><div class="how">%s</div>'%(SEC[cur],HOW[cur])
        n+=1;body+=card(n,q)
    # 번호 접두어 ①②③④ 보기 앞에 붙임
    import re
    def addnum(m):
        return m.group(0)
    page=('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f766e"><title>4과 어휘 %s · %s</title><style>%s</style>'
     '<link rel="icon" type="image/svg+xml" href="../icon.svg"><link rel="apple-touch-icon" href="../icon-180.png"><meta name="apple-mobile-web-app-title" content="금천고정답"></head><body><div class="wrap">'
     '<div class="top"><a class="back" href="../index.html">← 금천고 정답 목록</a></div><h1>4과 AI Neural Implants · 어휘 %s · %s</h1>'
     '<p class="lede">본문 단어 %d문제 · 소제목 구간별로 나눈 묶음이에요. 보기를 누르면 바로 정답과 해설이 나와요.</p><div class="bar"><span id="cnt"></span><button id="rs">처음부터 다시</button></div>%s'
     '<div class="foot">비타민 영어클리닉 · 금천고 공통영어2</div></div>%s</body></html>')%('①②③④'[bi],NAMES[bi],CSS,'①②③④'[bi],NAMES[bi],len(qs),body,JS)
    # 보기 앞에 번호 추가
    page=re.sub(r'(<button class="ob" data-i="(\d)">)',lambda m:m.group(1)+'<b>'+'①②③④⑤'[int(m.group(2))]+'</b> ',page)
    open('/tmp/claude-0/w/agentC/4/vocab%d.html'%(bi+1),'w',encoding='utf8').write(page)
print('ok')
