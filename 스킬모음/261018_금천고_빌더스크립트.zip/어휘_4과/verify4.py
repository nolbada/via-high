import json,re,sys,html
sys.path.insert(0,'/tmp/claude-0/w/agentC')
from vdata4 import *
S=json.load(open('/tmp/claude-0/w/sentences.json'))['4']
Q=json.load(open('4/q.json'))
ws=lambda t:re.sub(r'\s+',' ',t).strip()
EN=[ws(x) for x in S['en']];KO=[ws(x) for x in S['ko']]
un=lambda t:html.unescape(re.sub(r'</?(u|b|mark)>','',t))
# dictionary relation table from WORD TEST
rel={}
cur=None
raw=open('h4/syn_raw.txt',encoding='utf8').read().replace('\n]§',' ] ').split('\n')
for l in raw:
    m=re.match(r'^(.*?)\s*\t+\s*(.*?)\s*§\[(유의어|반의어)',l) or re.match(r'^(.*?)\s+(.*?)§\[(유의어|반의어)',l)
    pass
txt=open('h4/syn_raw.txt',encoding='utf8').read()
txt=re.sub(r'§\[(유의어|반의어)\s*\]§','§\\1§',txt)
for blk in re.split(r'\n(?=[^\n]*\t)',txt):
    head=blk.split('\t')[0].strip().split('\n')[-1]
    words=set()
    for w in re.findall(r'[A-Za-z][A-Za-z\- ]+',re.sub(r'^.*?\t[^\n§]*','',blk,count=1)):
        for x in re.split(r',',w):
            x=x.strip()
            if x and x not in('~','…'): words.add(x.lower())
    rel.setdefault(head.lower(),set()).update(words)
errs=[]
def E(m): errs.append(m)
tot=0
for bi,qs in enumerate(Q):
    a,b=SECTIONS[bi]; tot+=len(qs)
    secs=[q['sec'] for q in qs]
    # trap before syn before poly
    order={'trap':0,'syn':1,'poly':2}
    if secs!=sorted(secs,key=lambda s:order[s]): E(('order',bi))
    seen_w=set()
    for n,q in enumerate(qs,1):
        if not (0<=q['ans']<len(q['opts'])): E(('ans range',bi,n))
        if q['sec']=='trap':
            ss=[un(o['s']) for o in q['opts']]
            if len(set(ss))!=len(ss): E(('dup',bi,n))
            nf=0
            for o in q['opts']:
                s=un(o['s'])
                if o['f']:
                    nf+=1
                    # find original sentence
                    cands=[i for i in range(len(EN)) if len(EN[i])==len(s)-len(un(q['new']))+len(un(q['orig'])) and EN[i].replace(un(q['orig']),un(q['new']),1)==s]
                    if len(cands)!=1 or not(a<=cands[0]<=b): E(('flip src',bi,n,s)); 
                    else:
                        i=cands[0]
                        if un(o['ko'])!=KO[i]: E(('ko flip',bi,n))
                        if un(q['ko'])!=KO[i]: E(('ko main',bi,n))
                else:
                    c=[i for i in range(len(EN)) if EN[i]==s]
                    if len(c)!=1 or not(a<=c[0]<=b): E(('orig sent',bi,n,s))
                    elif un(o['ko'])!=KO[c[0]]: E(('ko',bi,n))
            if nf!=1: E(('nflip',bi,n))
            if not q['opts'][q['ans']]['f']: E(('ans not flip',bi,n))
        elif q['sec']=='syn':
            op=[un(o) for o in q['opts']]
            if len(set(op))!=4: E(('dup opt',bi,n))
            stem=un(q['stem'])
            c=[i for i in range(len(EN)) if EN[i]==stem]
            if len(c)!=1 or not(a<=c[0]<=b): E(('syn sent',bi,n,stem))
            else:
                if un(q['ko'])!=KO[c[0]]: E(('syn ko',bi,n))
            w=re.search(r'<b>(.*?)</b>',q['word']).group(1).lower().replace(' ~','').strip()
            key=w
            if w in seen_w: E(('word twice in bin',bi,w))
            seen_w.add(w)
            ans=re.match(r'[^ ]+(?: [^ ]+)?',op[q['ans']])
            heads=[re.split(r' (?=[가-힣~(])',o)[0].strip().lower() for o in op]
            rl=rel.get(w,set())|rel.get(w+' ~',set())|rel.get(w+' ~ into …',set())
            for k,h in enumerate(heads):
                if k!=q['ans'] and (h in rl or h.replace('ing','').strip() in rl):
                    E(('distractor in rel',bi,n,w,h))
            for k,h in enumerate(heads):
                if k!=q['ans']:
                    for r2,v in rel.items():
                        if h==r2 and w in v: E(('rev rel',bi,n,w,h))
        else:
            if len(set(q['opts']))!=len(q['opts']): E(('dup poly',bi,n))
            stem=un(q['stem'])
            if '<u>' not in q['stem']: E(('no underline',bi,n))
print('total',tot,[len(q) for q in Q])
for e in errs: print('ERR',e)
# pair across bins check
pairs={}
for bi,qs in enumerate(Q):
    for q in qs:
        if q['sec']=='syn':
            w=re.search(r'<b>(.*?)</b>',q['word']).group(1)
            ans=un(q['opts'][q['ans']]).split(' ')[0]
            pairs.setdefault((w,ans),[]).append(bi)
print([k for k,v in pairs.items() if len(v)>1])
print(len(rel), sorted(rel)[:5])
