import re,json,sys
sys.path.insert(0,'.')
from vdata4 import *
txt=open('h4/syn_raw.txt',encoding='utf8').read()
txt=re.sub(r'§\[(유의어|반의어)\s*\]§','|',txt)
lines=txt.split('\n');ents={};cur=None
for l in lines:
    if '\t' in l:
        cur=l.split('\t')[0].strip().lower();ents.setdefault(cur,[]).append(l.split('\t',1)[1])
    elif cur: ents[cur].append(l)
tok={}
for h,ls in ents.items():
    t=' '.join(ls); t=re.sub(r'[가-힣][^,|]*','',t)
    tok[h]=set(re.findall(r"[a-z][a-z\-]+",t.lower()))-{'to','in','of','for','on','from','with','by','at','be'}
def toks(w): return set(re.findall(r"[a-z][a-z\-]+",w.lower()))-{'to','in','of','for','on','from','with','by','at','be'}
bad=0
for T in (SYN,ANT):
    for w,pos,mn,si,form,opts,why in T:
        key=[k for k in tok if k==w.lower() or k.startswith(w.lower().replace(' ~','')+' ') or k==w.lower().replace(' ~','')]
        rl=set().union(*[tok[k] for k in key]) if key else set()
        if not key: print('NOKEY',w)
        for o in opts[1:]:
            h=o.split('|')[0]
            ht=toks(h)
            if ht&rl: print('DISTRACTOR~REL',w,h,ht&rl); bad+=1
            # reverse
            for k,v in tok.items():
                if toks(k)&ht and toks(k)>=ht and (toks(w)&v) : print('REV',w,h,k); bad+=1
print('bad',bad)
