import re,json
L=[l.rstrip() for l in open('h4/w4.txt',encoding='utf8').read().split('\n')[1104:1316]]
txt='\n'.join(L)
WORDS=['post','examine','benefit','concern','apply','application','target','region','operate','capture','feed','shift','issue','address','raise','afford','review','conduct','sound','demand']
# split into blocks at lines starting with word + tab
blocks={}
cur=None
for l in L:
    m=re.match(r'^(\w+)\s*\t+\s*(1\..*)?$',l)
    m2=re.match(r'^(\w+)\s+\t+',l)
    if m2 and m2.group(1) in WORDS and '1.' in l:
        cur=m2.group(1);blocks[cur]=[l[len(m2.group(0)):]];continue
    if cur and l.strip(): blocks[cur].append(l)
res={}
for w,ls in blocks.items():
    # meanings = lines until first line containing hangul-free english sentence start capital + hangul? split: sentence lines contain both latin letters ending sentence and hangul
    mean=[];ex=[]
    for l in ls:
        if re.search(r'[A-Za-z]{3,}.*[가-힣]',l) and re.match(r'^\s*[A-Z]',l) and not re.match(r'^\s*\d\.',l):
            m=re.search(r'[가-힣]',l); i=m.start()
            # korean starts at first hangul preceded by space
            # find boundary: last latin-or-punct char before first hangul
            e=l[:i].strip(); k=l[i:].strip()
            ex.append([e,k])
        else: mean.append(l)
    mm=' '.join(mean)
    ms=[re.sub(r'\s+',' ',x).strip() for x in re.split(r'\s*\d\.\s+',' '+mm) if x.strip()]
    res[w]=dict(w=w,mean=ms,ex=ex)
json.dump(res,open('poly4_raw.json','w'),ensure_ascii=False,indent=1)
for w,d in res.items(): print(w,len(d['mean']),len(d['ex']),d['mean'])
