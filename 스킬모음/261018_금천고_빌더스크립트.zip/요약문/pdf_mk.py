# -*- coding: utf-8 -*-
import json,sys,os,html
sys.path.insert(0,'/tmp/claude-0/-home-claude/669b4c4b-f62a-5708-a784-9b7cc42934b2/scratchpad/y')
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from data import Q
from playwright.sync_api import sync_playwright
S=json.load(open('/tmp/claude-0/w/sentences.json'))
NAME={'3':'The True Art Lovers','4':'AI Neural Implants'}
CIR='①②③④⑤'
e=html.escape
def endp(s): return s if s[-1] in '.?!' else s+'.'
CSS="""
@page{size:A4;margin:9mm 10mm 7mm}
body{font-family:'Noto Sans CJK KR','Noto Sans CJK JP',sans-serif;font-size:10pt;color:#111;line-height:1.5}
.hd{border-bottom:2px solid #111;padding-bottom:4px;margin-bottom:6px}
.hd .t{font-size:13.5pt;font-weight:800}.hd .s{font-size:9pt;color:#444}
.nm{display:flex;gap:18px;font-size:10pt;margin:6px 0 8px}
.pg{page-break-after:always}.pg:last-child{page-break-after:auto}
.cols{display:grid;grid-template-columns:1fr 1fr;column-gap:7mm;position:relative}
.cols:before{content:"";position:absolute;left:50%;top:0;bottom:0;border-left:1px dashed #999}
.q .ask{font-weight:800;margin:0 0 5px}
.q .ps{border:1px solid #888;padding:6px 8px;text-align:justify;font-size:10pt;line-height:1.42}
.q .sm{margin:6px 0 10px;padding:4px 8px 14px;background:#eee;border-left:4px solid #111;line-height:2.5}
.q .sm b{display:block;font-size:9.2pt;line-height:1.5;margin-bottom:0}
.op{margin:4px 0 4px 4px;line-height:1.5}
"""
def q_html(k,i,q,en):
    a,b=q['rng']; psg=' '.join(endp(en[j]) for j in range(a,b+1))
    h=[f'<div class="q"><div class="ask">{i+1}. 다음 글을 읽고, 요약문의 빈칸 (A), (B)에 들어갈 말로 가장 적절한 것을 고르시오.</div>']
    h.append(f'<div class="ps">{e(psg)}</div><div class="sm"><b>▶ 요약문</b>{e(q["summary"])}</div>')
    for n,(x,y) in enumerate(q['opts']): h.append(f'<div class="op">{CIR[n]}&nbsp;(A) {e(x)} –&nbsp;(B) {e(y)}</div>')
    h.append('</div>'); return ''.join(h)
def build(k):
    en=S[k]['en']; Qs=Q[k]
    h=[f'<!doctype html><html lang="ko"><meta charset="utf-8"><style>{CSS}</style><body>']
    hd=f'<div class="hd"><div class="t">{k}과 {NAME[k]} · 요약문 완성</div><div class="s">비타민 영어클리닉 · 고1 공통영어2 (미래엔 김성연)</div></div>'
    nm='<div class="nm"><span>이름 : ____________________</span><span>날짜 : ____월 ____일</span><span>점수 : ____ / 4</span></div>'
    h.append('<div class="pg">'+hd+nm+'<div class="cols">'+q_html(k,0,Qs[0],en)+q_html(k,1,Qs[1],en)+'</div></div>')
    h.append('<div class="pg">'+hd+nm+'<div class="cols">'+q_html(k,2,Qs[2],en)+q_html(k,3,Qs[3],en)+'</div></div>')
    h.append('</body></html>'); return ''.join(h)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page()
    for k in '34':
        fn=f'/tmp/claude-0/w/agentA/pdf/261018_고1 미래엔(김) {k}과 요약문 완성.pdf'
        pg.set_content(build(k)); pg.pdf(path=fn,format='A4',print_background=True,prefer_css_page_size=True)
        print(fn)
    b.close()
