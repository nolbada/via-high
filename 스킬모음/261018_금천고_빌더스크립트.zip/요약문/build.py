# -*- coding: utf-8 -*-
import json, re, html, os, zipfile, shutil
from data import Q
W='/tmp/claude-0/w'
OUT=W+'/agentA'
S=json.load(open(W+'/sentences.json'))
CSS=''.join(open(W+'/out/vocab1.html').read().split('\n')[1:42])  # <style> 내용(2~42행)
CSS=CSS.replace('<style>','')
esc=lambda s: html.escape(s,quote=True)
CIR='①②③④⑤'
NAME={'3':'The True Art Lovers','4':'AI Neural Implants'}
def endp(s): return s if s[-1] in '.?!' else s+'.'

EXTRA="""
.wrap{padding-bottom:60px}
body{font-size:19px}
.qa{display:flex;flex-wrap:wrap;gap:10px 18px;margin:10px 0 4px}
.qa div{display:flex;align-items:center;gap:8px;font-size:18px}
.qa .n{background:var(--navy);color:var(--card);border-radius:8px;font-weight:800;padding:1px 10px;font-size:15px}
.chip{background:var(--ans);color:#fff;border-radius:999px;font-weight:800;padding:1px 14px;font-size:18px}
.qc{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px 16px 14px;margin:16px 0}
.qc h2{margin-top:2px}
.big{font-size:20px;font-weight:800;margin:6px 0 10px}
.sm{font-size:15px;color:var(--sub);font-weight:700;margin:16px 0 4px}
.eng{font-size:19px;line-height:1.7;margin:4px 0}
.ko2{font-size:17px;color:var(--sub);margin:0 0 10px}
.fill{color:var(--ans);font-weight:800;border-bottom:2.5px solid var(--ans)}
.op{margin:7px 0;font-size:18px}
.op.c{font-weight:800}
.op small{display:block;color:var(--sub);font-size:16px;font-weight:400}
.ev{border-left:4px solid var(--pri);background:var(--priL);border-radius:0 10px 10px 0;padding:8px 12px;margin:8px 0}
.why{margin:6px 0 12px;font-size:18px}
.note{border-left:4px solid var(--warn);padding:2px 0 2px 12px;margin:12px 0 2px;font-size:17.5px}
.wr{margin:7px 0;font-size:17.5px}
"""
def gl(w,g): return f'{esc(w)}({esc(g[w])})'
KF={'3':[('끝까지 지켰고','인정'),('차별','포착했다'),('한계','선명한'),('맞섰고','적극적인')],
    '4':[('가능성','걸을'),('완전히 바꿀','처리하는'),('늦출','넓힐'),('평가','걱정한다')]}
def build_html(k):
    qs=Q[k]; en=S[k]['en']; ko=S[k]['ko']
    ttl=f'{k}과 {NAME[k]} · 요약문 완성 정답·해설'
    h=['<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f766e">',
       f'<title>{esc(ttl)}</title><style>',CSS,EXTRA,'</style><link rel="icon" type="image/svg+xml" href="../icon.svg"><link rel="apple-touch-icon" href="../icon-180.png"><meta name="apple-mobile-web-app-title" content="금천고정답"></head><body><div class="wrap">',
       '<div class="top"><a class="back" href="../index.html">← 금천고 정답 목록</a></div>',
       f'<h1>{k}과 {NAME[k]} · 요약문 완성 정답·해설</h1>',
       '<p class="lede">문제지는 종이로 풀고, 이 페이지에서 정답과 해설을 확인해요. 영어 옆 괄호에는 한글 뜻이 있어요.</p>',
       '<h2>빠른 정답</h2><div class="qa">']
    for i,q in enumerate(qs): h.append(f'<div><span class="n">{i+1}</span><span class="chip">{CIR[q["ans"]]}</span></div>')
    h.append('</div>')
    for i,q in enumerate(qs):
        a,b=q['opts'][q['ans']]; g=q['gloss']
        s=q['summary']
        s=s.replace('(A) ______',f'(A) <span class="fill">{esc(a)}</span>').replace('(B) ______',f'(B) <span class="fill">{esc(b)}</span>')
        s=esc(s).replace('&lt;span class=&quot;fill&quot;&gt;','<span class="fill">').replace('&lt;/span&gt;','</span>')
        k2=esc(q['ko'])
        fa,fb=KF[k][i]; k2=k2.replace('(A) ______',f'(A) <span class="fill">{esc(fa)}</span>').replace('(B) ______',f'(B) <span class="fill">{esc(fb)}</span>')
        h.append(f'<div class="qc"><h2>{i+1}번 · {esc(q["title"])}</h2>')
        h.append(f'<div class="big">정답 <span class="chip">{CIR[q["ans"]]}</span> &nbsp;{gl(a,g)} – {gl(b,g)}</div>')
        h.append('<div class="sm">정답을 넣은 요약문</div>')
        h.append(f'<p class="eng">{s}</p><p class="ko2">{k2}</p>')
        h.append('<div class="sm">보기 뜻</div>')
        for j,(x,y) in enumerate(q['opts']):
            c=' c' if j==q['ans'] else ''
            h.append(f'<div class="op{c}">{CIR[j]} {esc(x)} – {esc(y)}<small>{esc(g[x])} – {esc(g[y])}{"  ← 정답" if j==q["ans"] else ""}</small></div>')
        h.append('<div class="sm">정답의 근거</div>')
        for (bl,idx,marks,txt) in q['ev']:
            e=esc(en[idx])
            for m in marks:
                assert esc(m) in e,(k,i,m)
                e=e.replace(esc(m),f'<mark>{esc(m)}</mark>')
            h.append(f'<div class="ev"><b>({bl}) 근거 · 본문 문장</b><p class="eng">{e}</p><p class="ko2" style="margin-bottom:0">{esc(ko[idx])}</p></div><p class="why">{esc(txt)}</p>')
        h.append('<div class="sm">다른 보기가 안 되는 이유</div>')
        for w in q['wrong']: h.append(f'<p class="wr">{esc(w)}</p>')
        h.append(f'<div class="note"><b>기억할 흐름</b><br>{esc(q["note"])}</div></div>')
    h.append('<div class="foot">비타민 영어클리닉 · 금천고1 공통영어2 (미래엔 김성연)</div></div></body></html>')
    open(f'{OUT}/yoyak{k}.html','w').write(''.join(h))

# ---------- hwpx ----------
T='/tmp/claude-0/-home-claude/669b4c4b-f62a-5708-a784-9b7cc42934b2/scratchpad/y/ref/x'
import math
def qlines(q,en):
    r0,r1=q['rng']; L=1
    cur=0
    txt=' '.join(endp(en[j]) for j in range(r0,r1+1))
    L+=math.ceil(len(txt)/90)+sum(1 for j in range(r0,r1+1) if re.match(r'^[A-Z][a-z]+ [A-Z][a-z]+: ',en[j]) and j>r0)
    L+=1+math.ceil(len(q['summary'])/85)+5+1
    return L*0.5
def calc_brk(k):
    en=S[k]['en']; used=2.6; res=[]
    for q in Q[k]:
        h=qlines(q,en)
        if used+h>25.0 and used>3: res.append(1); used=h
        else: res.append(0); used+=h
    return res
BRK={k:calc_brk(k) for k in '34'}
def paras(k):
    qs=Q[k]; en=S[k]['en']; out=[]  # (paraPr, charPr, text, pagebreak)
    out.append((5,32,f'{k}과 {NAME[k]} · 요약문 완성',0))
    out.append((5,33,'비타민 영어클리닉 · 고1 공통영어2 (미래엔 김성연)',0))
    out.append((14,7,'이름 : ______________________      날짜 : ____월 ____일      점수 : ____ / 4',0))
    out.append((14,7,'',0))
    for i,q in enumerate(qs):
        r0,r1=q['rng']
        out.append((14,31,f'{i+1}. 다음 글을 읽고, 요약문의 빈칸 (A), (B)에 들어갈 말로 가장 적절한 것을 고르시오.',BRK[k][i]))
        cur=[]
        for j in range(r0,r1+1):
            if re.match(r'^[A-Z][a-z]+ [A-Z][a-z]+: ',en[j]) and cur:
                out.append((14,7,' '.join(cur),0)); cur=[]
            cur.append(endp(en[j]))
        out.append((14,7,' '.join(cur),0))
        out.append((14,31,'▶ 요약문',0))
        out.append((14,7,q['summary'],0))
        for j,(x,y) in enumerate(q['opts']):
            out.append((15,7,f'{CIR[j]}  (A) {x}  –  (B) {y}',0))
        out.append((14,7,'',0))
    return out
def xml_p(pid,pp,cp,text,pb,first=None):
    t=html.escape(text,quote=False)
    run=f'<hp:run charPrIDRef="{cp}">{first or ""}<hp:t>{t}</hp:t></hp:run>' if text else f'<hp:run charPrIDRef="{cp}">{first or ""}<hp:t></hp:t></hp:run>'
    return f'<hp:p id="{pid}" paraPrIDRef="{pp}" styleIDRef="0" pageBreak="{pb}" columnBreak="0" merged="0">{run}</hp:p>'
def build_hwpx(k):
    sec=open(T+'/Contents/section0.xml').read()
    head=sec[:sec.index('<hp:p ')]
    secpr=re.search(r'<hp:secPr .*?</hp:secPr>',sec,re.S).group(0)
    secpr=secpr.replace('masterPageCnt="1"','masterPageCnt="0"').replace('<hp:masterPage idRef="masterpage0"/>','')
    secpr=re.sub(r'left="4818" right="4818" top="3685" bottom="3118"','left="5100" right="5100" top="4200" bottom="3600"',secpr)
    secpr=secpr.replace('header="3685" footer="3685"','header="2800" footer="2800"')
    first=secpr+'<hp:ctrl><hp:colPr id="" type="NEWSPAPER" layout="LEFT" colCount="1" sameSz="0" sameGap="2268"><hp:colSz width="32768" gap="0"/></hp:colPr></hp:ctrl>'
    body=[]
    for n,(pp,cp,t,pb) in enumerate(paras(k)):
        body.append(xml_p(1000+n,pp,cp,t,pb,first if n==0 else None))
    s=head+''.join(body)+'</hs:sec>'
    hd=open(T+'/Contents/header.xml').read()
    def cp(i,h,bold):
        m=re.search(r'<hh:charPr id="7" .*?</hh:charPr>',hd,re.S).group(0)
        m=m.replace('id="7"',f'id="{i}"').replace('height="1000"',f'height="{h}"')
        if bold: m=m.replace('<hh:underline','<hh:bold/><hh:underline',1)
        return m
    add=cp(31,1050,True)+cp(32,1700,True)+cp(33,1100,False)
    def clone(src,nid):
        pm=re.search(rf'<hh:paraPr id="{src}" .*?</hh:paraPr>',hd,re.S).group(0)
        pm=pm.replace(f'id="{src}"',f'id="{nid}"',1)
        return re.sub(r'(lineSpacing type="PERCENT" value=")\d+"',r'\g<1>140"',pm)
    assert int(re.search(r'<hh:paraProperties itemCnt="(\d+)"',hd).group(1))==14
    hd=hd.replace('<hh:paraProperties itemCnt="14">','<hh:paraProperties itemCnt="16">').replace('</hh:paraProperties>',clone(4,14)+clone(4,15).replace('<hc:left value="0"','<hc:left value="800"')+'</hh:paraProperties>')
    hd=hd.replace('<hh:charProperties itemCnt="31">','<hh:charProperties itemCnt="34">').replace('</hh:charProperties>',add+'</hh:charProperties>')
    hpf=open(T+'/Contents/content.hpf').read()
    hpf=re.sub(r'<opf:item id="(masterpage0|image\d|section1)"[^>]*/>','',hpf).replace('<opf:itemref idref="section1" linear="yes"/>','')
    hpf=re.sub(r'<opf:title>.*?</opf:title>',f'<opf:title>고1 미래엔(김) {k}과 요약문 완성</opf:title>',hpf)
    hpf=re.sub(r'<opf:meta name="creator" content="text">.*?</opf:meta>','<opf:meta name="creator" content="text">비타민 영어클리닉</opf:meta>',hpf)
    d=f'{OUT}/{k}'; os.makedirs(d,exist_ok=True)
    fn=f'{d}/261018_고1 미래엔(김) {k}과 요약문 완성.hwpx'
    with zipfile.ZipFile(fn,'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'),open(T+'/mimetype').read(),compress_type=zipfile.ZIP_STORED)
        for name,data in [('version.xml',open(T+'/version.xml').read()),('Contents/header.xml',hd),('Contents/section0.xml',s),('Contents/content.hpf',hpf),('settings.xml',open(T+'/settings.xml').read()),('META-INF/container.xml',open(T+'/META-INF/container.xml').read().replace('<ocf:rootfile full-path="Preview/PrvText.txt" media-type="text/plain"/>','')),('META-INF/container.rdf',re.sub(r'<rdf:Description rdf:about=""><ns0:hasPart[^>]*section1.xml"/></rdf:Description>|<rdf:Description rdf:about="Contents/section1.xml">.*?</rdf:Description>','',open(T+'/META-INF/container.rdf').read(),flags=re.S)),('META-INF/manifest.xml',open(T+'/META-INF/manifest.xml').read())]:
            z.writestr(name,data,compress_type=zipfile.ZIP_DEFLATED)
    return fn
if __name__=='__main__':
    for k in '34':
        build_html(k); print(build_hwpx(k))
