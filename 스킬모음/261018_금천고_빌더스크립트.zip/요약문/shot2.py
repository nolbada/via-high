from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':900})
    pg.goto('file:///tmp/claude-0/w/agentA/yoyak4.html')
    pg.locator('.qc').nth(2).screenshot(path='/tmp/lo/c3.png')
    pg.emulate_media(color_scheme='dark'); pg.locator('.qc').nth(0).screenshot(path='/tmp/lo/d1.png')
