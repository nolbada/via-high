import zipfile,re,json,html
from xml.dom import minidom
from html.parser import HTMLParser
S=json.load(open('/tmp/claude-0/w/sentences.json'))
O='/tmp/claude-0/w/agentA'
for k in '34':
    z=zipfile.ZipFile(f'{O}/{k}/261018_고1 미래엔(김) {k}과 요약문 완성.hwpx')
    for n in z.namelist():
        if n!='mimetype': minidom.parseString(z.read(n))
    hd=z.read('Contents/header.xml').decode()
    assert hd.count('<hh:charPr ')==34 and hd.count('<hh:paraPr ')==16
    sec=z.read('Contents/section0.xml').decode()
    ids=re.findall(r'<hp:p id="(\d+)"',sec); assert len(ids)==len(set(ids))
    # passages in hwpx are exact sentences
    txt=html.unescape(' '.join(re.findall(r'<hp:t>(.*?)</hp:t>',sec)))
    for e in S[k]['en']:
        pass
    # html: every ev sentence verbatim
    page=open(f'{O}/yoyak{k}.html').read()
    ens=[e.replace("'","&#x27;") for e in S[k]['en']]
    # extract <p class="eng"> inside .ev
    found=re.findall(r'<div class="ev"><b>[^<]*</b><p class="eng">(.*?)</p><p class="ko2" style="margin-bottom:0">(.*?)</p>',page)
    assert len(found)==8
    for e,kk in found:
        plain=html.unescape(re.sub(r'</?mark>','',e)); kor=html.unescape(kk)
        i=S[k]['en'].index(plain); assert S[k]['ko'][i]==kor,(plain)
        print(k,'OK',i,plain[:40])
    # no stray English w/o hangul gloss: report lines with latin words in 해설 outside ev? (manual)
