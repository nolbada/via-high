from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':420,'height':900})
    for k in '34':
        pg.goto(f'file:///tmp/claude-0/w/agentA/yoyak{k}.html')
        print(k,pg.evaluate('[document.documentElement.scrollWidth,innerWidth,document.documentElement.scrollHeight]'))
        pg.screenshot(path=f'/tmp/lo/s{k}a.png')
        pg.evaluate('window.scrollTo(0,1100)'); pg.screenshot(path=f'/tmp/lo/s{k}b.png')
    pg.emulate_media(color_scheme='dark'); pg.goto('file:///tmp/claude-0/w/agentA/yoyak4.html'); pg.evaluate('window.scrollTo(0,1100)'); pg.screenshot(path='/tmp/lo/dark.png')
