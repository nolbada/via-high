# -*- coding: utf-8 -*-
import re, json, random, html, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from content import *

OUT = '/tmp/claude-0/w/agentB'
BASE_CSS = open(os.path.join(os.path.dirname(__file__), 'base.css')).read()
CIRC = '①②③④⑤'
LAB = 'ABC'
CH_NAME = {'3': '3과', '4': '4과'}
CH_TITLE = {'3': 'The True Art Lovers', '4': 'AI Neural Implants'}

EXTRA_CSS = """
.flow{margin:8px 0 2px}
.flow .fn{display:flex;align-items:center;gap:8px;background:var(--priL);border:1.5px solid var(--pri);border-radius:11px;padding:8px 11px;font-size:16.5px;line-height:1.5;font-weight:700}
.flow .fn.g{background:var(--bg);border-color:var(--line);font-weight:600}
.flow .ch{flex:none;font-size:12.5px;font-weight:800;color:var(--card);background:var(--pri);border-radius:999px;padding:1px 9px;line-height:1.6}
.flow .ar{text-align:center;color:var(--pri);font-size:15px;line-height:1.1;margin:1px 0}

.en{color:var(--blue);font-weight:700}
.ex .en{font-weight:700}
.pg{font-size:15px;color:var(--sub);margin:2px 0 8px}
.gv,.sd,.pb{border-radius:11px}
.gv{background:var(--priL);border:1.5px solid var(--pri);padding:8px 12px;margin:6px 0;font-size:16.5px;line-height:1.6}
.gv small,.sd small,.sub{display:block;color:var(--sub);font-size:14.5px;margin-top:2px;font-weight:400}
.gv .tg2,.sd .tg2{display:inline-block;font-size:12px;font-weight:800;color:var(--pri);border:1px solid var(--pri);border-radius:999px;padding:0 7px;margin-right:6px;vertical-align:1px}
.sd{display:none;background:var(--okBg);border:1.5px solid var(--pri);padding:8px 12px;margin:6px 0;font-size:16.5px;line-height:1.6}
.sd.on{display:block}
.sd .why{display:block;border-left:3px solid var(--pri);padding:2px 0 2px 9px;margin-top:6px;font-size:15px;color:var(--sub);font-weight:400}
.sd .no{display:inline-block;min-width:22px;text-align:center;background:var(--navy);color:var(--card);border-radius:999px;font-size:12.5px;font-weight:800;margin-right:6px;padding:0 6px}
.pool{margin-top:10px}
.pool .lbl{font-size:14px;color:var(--sub);margin:4px 0}
.pb{display:block;width:100%;text-align:left;font:inherit;font-size:16.5px;line-height:1.55;color:var(--ink);background:var(--bg);border:1.5px solid var(--line);padding:8px 12px;margin:6px 0}
.pb.gone{display:none}
.pb.ng{border-color:var(--ans);background:var(--ngBg)}
.msg{min-height:20px;font-size:15px;color:var(--ans);font-weight:700;margin:4px 0 0}
.fin{display:none;margin-top:8px;border-top:1px dashed var(--line);padding-top:8px;font-size:16px}
.done .fin{display:block}
.fin ol{margin:4px 0 2px;padding-left:20px;color:var(--ink);font-size:15.5px}
.fin li{margin:5px 0}
.fin li small{display:block;color:var(--sub);font-size:14.5px}
.pbox{border:1.5px solid var(--line);border-radius:12px;background:var(--bg);padding:10px 12px;margin:6px 0;font-size:16.5px;line-height:1.9}
.pbox.given{background:var(--priL);border-color:var(--pri)}
.pbox .lab{display:inline-block;font-weight:800;color:var(--pri);margin-right:4px}
.ct{margin:8px 0}
.ct .lab{font-weight:800;color:var(--navy);margin-right:4px}
.mk{display:inline-block;vertical-align:baseline;font:inherit;font-weight:800;font-size:16.5px;line-height:1.2;color:var(--navy);background:var(--card);border:1.5px solid var(--line);border-radius:999px;padding:2px 8px;margin:0 3px}
.mk.ok{border-color:var(--pri);background:var(--okBg);color:var(--pri)}
.mk.ng{border-color:var(--ans);background:var(--ngBg);color:var(--ans)}
.done .mk{pointer-events:none}
.ins{background:var(--pi);color:var(--piInk);border-radius:6px;padding:0 3px}
.fin li.insli,.ex li.insli{background:var(--pi);color:var(--piInk);border-radius:8px;padding:3px 6px}
.ex ol.full{color:var(--ink);font-size:15.5px}
.ex ol.full li{margin:5px 0}
.ex ol.full small{display:block;color:var(--sub);font-size:14.5px}
.ex ol.steps{color:var(--ink)}
.ex ol.steps li{margin:5px 0}
.ex .oth{color:var(--sub);font-size:15px;margin:6px 0}
.cnt b{color:var(--pri)}
"""

def ED(ch, n):
    e = EN[ch][n]
    return e if re.search(r'[.?!]$', e) else e + '.'

def esc(s):
    return html.escape(s, quote=False)

def mk(s):
    """{{En|뜻}} -> html"""
    out = []; pos = 0
    for m in re.finditer(r'\{\{(.+?)\|(.+?)\}\}', s):
        out.append(esc(s[pos:m.start()]))
        out.append('<span class="en">%s</span>(%s)' % (esc(m.group(1)), esc(m.group(2))))
        pos = m.end()
    out.append(esc(s[pos:]))
    return ''.join(out)

def koe_html(text):
    """English(뜻) pieces -> highlight English word before the parenthesis"""
    t = esc(text)
    t = re.sub(r"([A-Za-z][A-Za-z' ]*[A-Za-z])\(([^)]*[가-힣~][^)]*)\)", lambda m: '<span class="en">%s</span>(%s)' % (m.group(1), m.group(2)), t)
    return t

def shuffled(items, seed, first_correct):
    r = random.Random(seed)
    for _ in range(1000):
        p = items[:]
        r.shuffle(p)
        if p != items and p[0] != first_correct:
            return p
    raise RuntimeError('shuffle')

def page(ch, kind, title, lede, body, script):
    h = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f766e"><title>{esc(title)}</title>
<style>
{BASE_CSS}{EXTRA_CSS}
</style><link rel="icon" type="image/svg+xml" href="../icon.svg"><link rel="apple-touch-icon" href="../icon-180.png"><meta name="apple-mobile-web-app-title" content="금천고정답"></head><body><div class="wrap"><div class="top"><a class="back" href="../index.html">← 금천고 정답 목록</a></div><h1>{esc(title)}</h1><p class="lede">{lede}</p><div class="bar"><span id="cnt" class="cnt"></span><button id="rs">처음부터 다시</button></div>
{body}
<div class="foot">비타민 영어클리닉 · 금천고1 공통영어2 {CH_NAME[ch]} {esc(CH_TITLE[ch])}</div></div>
<script>
{script}
</script></body></html>"""
    return h

# ---------- sequence engine (ko, mun 가)
SEQ_JS = """
(function(){
var qs=[].slice.call(document.querySelectorAll('.q.seq')),bar=document.getElementById('cnt');
var secs=[].slice.call(document.querySelectorAll('.q.pick'));
var TOT=qs.length+secs.length,done=0,perfect=0,pdone=0,pc=0;
function up(){bar.innerHTML=(done+pdone)+' / '+TOT+' 풀었어요 · 한 번에 맞힌 문제 <b>'+(perfect+pc)+'</b>개'}
qs.forEach(function(q){
 var tot=+q.dataset.t;q._k=0;q._w=0;
 q.addEventListener('click',function(e){
  var b=e.target.closest('.pb');if(!b||q.classList.contains('done'))return;
  var n=+b.dataset.n,msg=q.querySelector('.msg');
  if(n===q._k+1){
   b.classList.add('gone');q.querySelectorAll('.sd')[q._k].classList.add('on');q._k++;msg.textContent='';
   if(q._k===tot){q.classList.add('done');done++;if(q._w===0)perfect++;
     var r=q.querySelector('.res');r.className='res o';r.textContent=q._w===0?'모두 한 번에 맞혔어요':'순서를 모두 맞혔어요 (틀린 횟수 '+q._w+'번)';
     q.querySelector('.lbl').style.display='none';}
   else{q.querySelector('.lbl').textContent='다음에 올 문장을 누르세요 ('+(q._k+1)+'번째)';}
   up();
  }else{
   q._w++;b.classList.add('ng');msg.textContent='아직 이 문장이 올 차례가 아니에요. 앞 문장과 이어 주는 말(접속부사·지시어·시간 표현)을 찾아보세요.';
   setTimeout(function(){b.classList.remove('ng')},900);
  }
 });
});
secs.forEach(function(q){
 q.addEventListener('click',function(e){var b=e.target.closest('.ob,.mk');if(!b||q.classList.contains('done'))return;
  var a=+q.dataset.a,i=+b.dataset.i,os=q.querySelectorAll('.ob,.mk');q.classList.add('done');pdone++;
  os[a].classList.add('ok');var r=q.querySelector('.res');
  if(i===a){pc++;r.className='res o';r.textContent='정답이에요'}else{b.classList.add('ng');r.className='res x';r.textContent='아쉬워요. 정답은 '+'①②③④⑤'[a]+'번'}
  up()});
});
document.getElementById('rs').onclick=function(){
 qs.forEach(function(q){q.classList.remove('done');q._k=0;q._w=0;q.querySelectorAll('.pb').forEach(function(x){x.classList.remove('gone','ng')});q.querySelectorAll('.sd').forEach(function(x){x.classList.remove('on')});q.querySelector('.msg').textContent='';var l=q.querySelector('.lbl');l.style.display='';l.textContent='다음에 올 문장을 누르세요 (1번째)';var r=q.querySelector('.res');r.className='res';r.textContent=''});
 secs.forEach(function(q){q.classList.remove('done');q.querySelectorAll('.ob,.mk').forEach(function(o){o.classList.remove('ok','ng')});var r=q.querySelector('.res');r.className='res';r.textContent=''});
 done=0;perfect=0;pdone=0;pc=0;up();window.scrollTo(0,0)};
up();
})();
"""

def full_list(ch, ns, ins=None):
    li = []
    for n in ns:
        cls = ' class="insli"' if ins == n else ''
        li.append('<li%s><span class="en">%s</span><small>%s</small></li>' % (cls, esc(ED(ch,n)), esc(KO[ch][n])))
    return '<ol>' + ''.join(li) + '</ol>'

def flow(ch, given, ns):
    h = ['<div class="flow">']
    for k, n in enumerate(ns):
        chip, key = KEY[ch][n]
        c = '<span class="ch">%s</span>' % esc(chip) if chip else ''
        h.append('<div class="fn%s">%s<span>%s</span></div>' % (' g' if n in given else '', c, esc(key)))
        if k < len(ns) - 1:
            h.append('<div class="ar">▼</div>')
    h.append('</div>')
    return ''.join(h)

def seq_question(ch, qi, gi, title, given, shuf, mode, page_tag):
    """mode 'ko' or 'en'"""
    seq = shuf
    allns = given + seq
    assert allns == list(range(allns[0], allns[0] + len(allns))), (ch, title)
    pool = shuffled(seq, f'{ch}-{page_tag}-{gi}', seq[0])
    h = [f'<div class="q seq" data-t="{len(seq)}"><div class="qh"><span class="qn">{qi}</span><span class="tg">{esc(title)}</span></div>']
    if mode == 'ko':
        h.append('<div class="ask">맨 위 문장 다음에 이어질 순서대로 <b>한글 문장</b>을 눌러 쌓아 보세요.</div>')
    else:
        h.append('<div class="ask">맨 위 문장 다음에 이어질 순서대로 <b>영어 문장</b>을 눌러 쌓아 보세요.</div>')
    for n in given:
        if mode == 'ko':
            h.append('<div class="gv"><span class="tg2">주어진 문장</span>%s</div>' % koe_html(KOE[ch].get(n, KO[ch][n])))
        else:
            h.append('<div class="gv"><span class="tg2">주어진 문장</span>%s<small>%s</small></div>' % (esc(ED(ch,n)), esc(KO[ch][n])))
    for k, n in enumerate(seq):
        why = '<span class="why">%s</span>' % mk(WHY[ch][n])
        if mode == 'ko':
            h.append('<div class="sd"><span class="no">%d</span>%s%s</div>' % (k + 1, koe_html(KOE[ch].get(n, KO[ch][n])), why))
        else:
            h.append('<div class="sd"><span class="no">%d</span>%s<small>%s</small>%s</div>' % (k + 1, esc(ED(ch,n)), esc(KO[ch][n]), why))
    h.append('<div class="pool"><div class="lbl">다음에 올 문장을 누르세요 (1번째)</div>')
    for n in pool:
        txt = koe_html(KOE[ch].get(n, KO[ch][n])) if mode == 'ko' else esc(ED(ch,n))
        h.append('<button class="pb" data-n="%d">%s</button>' % (seq.index(n) + 1, txt))
    h.append('<div class="msg"></div></div>')
    h.append('<div class="res"></div><div class="fin"><div class="wd">한눈에 정리 · 이 순서로 기억해요</div>%s</div></div>' % (flow(ch, given, allns) if mode == 'ko' else full_list(ch, allns)))
    return '\n'.join(h)

def build_ko(ch):
    body = ['<h2 class="sechd">한글 순서배열</h2><div class="how">맨 위에 주어진 문장 다음에 올 문장을 <b>본문 순서대로</b> 눌러요. 맞으면 쌓이고 해설이 나와요. <b>영어(뜻)</b>로 적힌 연결어는 문장을 이어 주는 열쇠예요.</div>']
    for gi, (title, given, shuf) in enumerate(KO_G[ch]):
        body.append(seq_question(ch, gi + 1, gi, title, given, shuf, 'ko', 'ko'))
    lede = '%s %s 본문 · 한글 문장 %d묶음. 영어 연결어는 우리말 뜻과 함께 적혀 있어요.' % (CH_NAME[ch], esc(CH_TITLE[ch]), len(KO_G[ch]))
    return page(ch, 'ko', f'{CH_NAME[ch]} 순서배열 · 한글', lede, '\n'.join(body), SEQ_JS), len(KO_G[ch])

def chunk_text(ch, ns):
    return ' '.join(esc(ED(ch,n)) for n in ns)

def build_abc(ch):
    CHO = [('A', 'C', 'B'), ('B', 'A', 'C'), ('B', 'C', 'A'), ('C', 'A', 'B'), ('C', 'B', 'A')]
    body = ['<h2 class="sechd">ABC 순서 고르기</h2><div class="how">주어진 글 다음에 이어질 <b>(A) (B) (C)</b>의 순서를 골라요. 보기를 누르면 바로 정답과 해설이 나와요.</div>']
    for qi, (title, given, chunks) in enumerate(ABC_Q[ch]):
        a = ABC_ANS[ch][qi]
        labels = CHO[a]            # labels of X1,X2,X3 in book order
        # sanity: ranges contiguous
        flat = given + [n for c in chunks for n in c]
        assert flat == list(range(flat[0], flat[0] + len(flat))), (ch, title)
        by_label = {labels[i]: chunks[i] for i in range(3)}
        h = [f'<div class="q pick" data-a="{a}"><div class="qh"><span class="qn">{qi+1}</span><span class="tg">{esc(title)}</span></div>']
        h.append('<div class="ask">주어진 글 다음에 이어질 글의 순서로 가장 적절한 것은?</div>')
        h.append('<div class="pbox given"><span class="lab">주어진 글</span>%s</div>' % chunk_text(ch, given))
        for L in LAB:
            h.append('<div class="pbox"><span class="lab">(%s)</span>%s</div>' % (L, chunk_text(ch, by_label[L])))
        for i, c in enumerate(CHO):
            h.append('<button class="ob" data-i="%d"><b>%s</b> %s</button>' % (i, CIRC[i], '-'.join('(%s)' % x for x in c)))
        # explanation
        steps = []
        prev = 'g'
        names = {0: '주어진 글', 1: '(%s)' % labels[0], 2: '(%s)' % labels[1], 3: '(%s)' % labels[2]}
        for k in range(3):
            first = chunks[k][0]
            frm = '주어진 글' if k == 0 else '(%s)' % labels[k - 1]
            steps.append('<li><b>%s → (%s)</b> · %s</li>' % (frm, labels[k], mk(WHY[ch][first])))
            for n in chunks[k][1:]:
                steps.append('<li><b>(%s) 안에서</b> · %s</li>' % (labels[k], mk(WHY[ch][n])))
        order = '-'.join('(%s)' % x for x in labels)
        h.append('<div class="ex"><div class="res"></div><div class="kk">정답은 <b>%s %s</b> 이에요. 본문 순서 그대로입니다.</div><ol class="steps">%s</ol><div class="wd">본문 순서대로 다시 읽기 (영어 + 해석)</div><ol class="full">%s</ol></div></div>' % (
            CIRC[a], order, ''.join(steps),
            ''.join('<li><span class="en">%s</span><small>%s</small></li>' % (esc(ED(ch,n)), esc(KO[ch][n])) for n in flat)))
        body.append('\n'.join(h))
    lede = '%s %s 본문 · 모의고사 유형 %d문제. 주어진 글 다음에 (A)(B)(C)의 순서를 골라요.' % (CH_NAME[ch], esc(CH_TITLE[ch]), len(ABC_Q[ch]))
    return page(ch, 'abc', f'{CH_NAME[ch]} 순서배열 · ABC', lede, '\n'.join(body), SEQ_JS), len(ABC_Q[ch])

def build_mun(ch):
    body = ['<h2 class="sechd">(가) 문장 순서배열</h2><div class="how">맨 위 문장 다음에 올 <b>영어 문장</b>을 본문 순서대로 눌러 쌓아요. 맞으면 쌓이면서 우리말 해석과 해설이 나와요.</div>']
    for gi, (title, given, shuf) in enumerate(MUN_G[ch]):
        body.append(seq_question(ch, gi + 1, gi, title, given, shuf, 'en', 'mun'))
    nga = len(MUN_G[ch])
    body.append('<h2 class="sechd">(나) 문장 삽입</h2><div class="how">주어진 문장이 들어갈 곳을 <b>①~⑤</b> 중에서 골라요. 번호를 누르면 바로 정답과 해설이 나와요.</div>')
    for qi, (title, ins, passage, marks, why, others) in enumerate(INS_Q[ch]):
        assert len(marks) == 5 and ins not in passage
        assert sorted(passage + [ins]) == list(range(min(passage + [ins]), max(passage + [ins]) + 1)), (ch, title)
        before = max([p for p in passage if p < ins], default=0)
        assert before in marks, (ch, title, before, marks)
        a = marks.index(before)
        # marks sorted by position
        assert marks == sorted(marks)
        for m in marks:
            assert m == 0 or m in passage
        h = [f'<div class="q pick" data-a="{a}"><div class="qh"><span class="qn">{nga+qi+1}</span><span class="tg">{esc(title)}</span></div>']
        h.append('<div class="ask">주어진 문장이 들어갈 곳으로 가장 적절한 곳은?</div>')
        h.append('<div class="pbox given"><span class="lab">주어진 문장</span>%s</div>' % esc(ED(ch,ins)))
        parts = []
        for idx in range(0, 1):
            pass
        p_html = []
        if 0 in marks:
            p_html.append('<button class="mk" data-i="%d">%s</button>' % (marks.index(0), CIRC[marks.index(0)]))
        for n in passage:
            p_html.append(esc(ED(ch,n)))
            if n in marks:
                p_html.append('<button class="mk" data-i="%d">%s</button>' % (marks.index(n), CIRC[marks.index(n)]))
        h.append('<div class="pbox">%s</div>' % ' '.join(p_html))
        flat = sorted(passage + [ins])
        h.append('<div class="ex"><div class="res"></div><div class="kk">정답은 <b>%s</b> 이에요.</div>' % CIRC[a])
        h.append('<div class="wd">주어진 문장</div><ol class="full"><li class="insli"><span class="en">%s</span><small>%s</small></li></ol>' % (esc(ED(ch,ins)), esc(KO[ch][ins])))
        h.append('<div class="kk">%s</div>' % mk(why))
        h.append('<div class="oth">%s</div>' % mk(others))
        h.append('<div class="wd">완성된 글 (노란 칸이 주어진 문장)</div><ol class="full">%s</ol></div></div>' % ''.join(
            '<li%s><span class="en">%s</span><small>%s</small></li>' % (' class="insli"' if n == ins else '', esc(ED(ch,n)), esc(KO[ch][n])) for n in flat))
        body.append('\n'.join(h))
    lede = '%s %s 본문 · (가) 문장 순서배열 %d문제, (나) 문장 삽입 %d문제.' % (CH_NAME[ch], esc(CH_TITLE[ch]), nga, len(INS_Q[ch]))
    return page(ch, 'mun', f'{CH_NAME[ch]} 순서배열 · 문장', lede, '\n'.join(body), SEQ_JS), (nga, len(INS_Q[ch]))

if __name__ == '__main__':
    for ch in '34':
        for name, fn in (('sunseo-ko', build_ko), ('sunseo-abc', build_abc), ('sunseo-mun', build_mun)):
            h, cnt = fn(ch)
            open(f'{OUT}/{ch}/{name}.html', 'w').write(h)
            print(ch, name, cnt, len(h))
