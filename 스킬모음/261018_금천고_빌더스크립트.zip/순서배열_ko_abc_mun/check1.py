# -*- coding: utf-8 -*-
import re,sys
sys.path.insert(0,'.')
from content import *
bad=0
# 0. correspondence of json lengths
for c in '34':
    assert len(D[c]['en'])==len(D[c]['ko'])==len(D[c]['sec']),c
print('len', {c:len(D[c]['en']) for c in '34'})
# 1. quoted English fragments in WHY / INS must be substrings of a nearby original sentence
def frags(s): return re.findall(r'\{\{(.+?)\|(.+?)\}\}',s)
for c in '34':
    for n,t in WHY[c].items():
        for f,k in frags(t):
            if not (f in EN[c][n] or f in EN[c][n-1]):
                print('WHY MISS',c,n,f); bad+=1
    for (title,ins,passage,marks,why,oth) in INS_Q[c]:
        pool=[EN[c][i] for i in passage+[ins]]
        for f,k in frags(why)+frags(oth):
            if not any(f in e for e in pool):
                print('INS MISS',c,title,f); bad+=1
    # every sentence used as non-first has WHY
    used=set()
    for g in KO_G[c]+MUN_G[c]: used|=set(g[2])
    for g in ABC_Q[c]:
        for ch in g[2]: used|=set(ch)
    for g in INS_Q[c]: pass
    for n in used:
        assert n in WHY[c],(c,n)
# 2. KOE: print comparison for manual review
for c in '34':
    for n,t in sorted(KOE[c].items()):
        base=re.sub(r'[A-Za-z][A-Za-z\' :]*\([^)]*\)','',t)
        print(c,n,'\n  KO :',KO[c][n],'\n  KOE:',t)
print('bad',bad)
