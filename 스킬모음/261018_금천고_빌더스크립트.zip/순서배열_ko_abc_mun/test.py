# -*- coding: utf-8 -*-
import re, json, difflib, sys, os
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
D=json.load(open('/tmp/claude-0/w/sentences.json'))
EN={c:D[c]['en'] for c in '34'}; KO={c:D[c]['ko'] for c in '34'}
EN['3'][5]=EN['3'][5]+' Bill Traylor'
def find_n(c,txt):
    for i,e in enumerate(EN[c]):
        if e==txt.strip() or e+'.'==txt.strip(): return i+1
    return None
def ko_n(c,txt):
    t=re.sub(r"[A-Za-z][A-Za-z' :]*\([^)]*\)",'',txt)
    best=max(range(len(KO[c])),key=lambda i:difflib.SequenceMatcher(None,t,re.sub(r"^(Yumi Lee: |Eric Davis: )",'',KO[c][i])).ratio())
    r=difflib.SequenceMatcher(None,t,KO[c][best]).ratio()
    return best+1,r
errs=[]
def check(cond,msg):
    if not cond: errs.append(msg); print('FAIL',msg)
with sync_playwright() as p:
    b=p.chromium.launch()
    for ch in '34':
        for name in ('sunseo-ko','sunseo-abc','sunseo-mun'):
            for scen in ('right','wrong'):
                ctx=b.new_context(viewport={'width':420,'height':900})
                pg=ctx.new_page(); logs=[]
                pg.on('pageerror',lambda e:logs.append(str(e))); pg.on('console',lambda m:logs.append(m.text) if m.type=='error' else None)
                pg.goto(f'file:///tmp/claude-0/w/agentB/{ch}/{name}.html')
                tag=f'{ch}/{name}/{scen}'
                check(pg.evaluate('document.documentElement.scrollWidth')<=420,tag+' hscroll %s'%pg.evaluate('document.documentElement.scrollWidth'))
                check(pg.locator('a.back').get_attribute('href')=='../index.html',tag+' backlink')
                tot=pg.locator('.q').count(); perfect=0
                # seq
                for qi in range(pg.locator('.q.seq').count()):
                    q=pg.locator('.q.seq').nth(qi)
                    t=int(q.get_attribute('data-t'))
                    btns=q.locator('.pb'); ns=[int(btns.nth(i).get_attribute('data-n')) for i in range(btns.count())]
                    check(sorted(ns)==list(range(1,t+1)),tag+f' q{qi} ns')
                    check(ns!=sorted(ns),tag+' pool not sorted')
                    # independent: map to sentence numbers
                    texts=[btns.nth(i).inner_text() for i in range(btns.count())]
                    sn=[]
                    for tx in texts:
                        if name=='sunseo-mun': sn.append(find_n(ch,tx))
                        else:
                            n,r=ko_n(ch,tx); check(r>0.6,tag+f' komatch {r:.2f} {tx[:20]}'); sn.append(n)
                    check(None not in sn,tag+' nomatch')
                    rank=[sorted(sn).index(x)+1 for x in sn]
                    check(rank==ns,tag+f' q{qi} data-n vs book rank {rank} {ns}')
                    check(sorted(sn)==list(range(min(sn),min(sn)+t)),tag+' contiguous')
                    if scen=='wrong':
                        # tap a wrong one first
                        wi=[i for i,n in enumerate(ns) if n!=1][0]
                        btns.nth(wi).click()
                        check('ng' in btns.nth(wi).get_attribute('class'),tag+' wrong not flagged')
                        check(len(q.locator('.msg').inner_text())>5,tag+' no msg')
                        check(q.locator('.sd.on').count()==0,tag+' wrong placed')
                        pg.wait_for_timeout(1000)
                    for k in range(1,t+1):
                        q.locator(f'.pb[data-n="{k}"]').click()
                        check(q.locator('.sd.on').count()==k,tag+f' stack {k}')
                    check('done' in q.get_attribute('class'),tag+' not done')
                    # fin list order matches book
                    fl=q.locator('.fin li .en'); fn=[find_n(ch,fl.nth(i).inner_text()) for i in range(fl.count())]
                    check(None not in fn and fn==list(range(fn[0],fn[0]+len(fn))),tag+f' fin order {fn}')
                    check(fn[-len(sn):]==sorted(sn),tag+' fin tail')
                    if scen=='right': perfect+=1
                # pick
                for qi in range(pg.locator('.q.pick').count()):
                    q=pg.locator('.q.pick').nth(qi)
                    a=int(q.get_attribute('data-a'))
                    if name=='sunseo-abc':
                        boxes=q.locator('.pbox'); lab={}
                        txt=[boxes.nth(i).inner_text() for i in range(boxes.count())]
                        def nums(t):
                            out=[]
                            for i,e in enumerate(EN[ch]):
                                pos=t.find(e)
                                if pos>=0: out.append((pos,i+1))
                            return [n for _,n in sorted(out)]
                        given=nums(txt[0]); ch3=[nums(t) for t in txt[1:4]]
                        check(all(len(c)>=2 for c in ch3),tag+' chunk size')
                        order=sorted(range(3),key=lambda i:min(ch3[i]))
                        labels=tuple('ABC'[i] for i in order)
                        # contiguity
                        allv=given+sum([ch3[i] for i in order],[])
                        check(allv==list(range(allv[0],allv[0]+len(allv))),tag+f' abc contiguous {allv}')
                        opt=q.locator('.ob').nth(a).inner_text()
                        exp=' '.join('-'.join('(%s)'%x for x in labels).split())
                        check(exp in opt.replace(' ',''),tag+f' abc ans {opt!r} vs {labels}') if False else check(''.join(labels)==''.join(re.findall(r'\(([ABC])\)',opt)),tag+f' abc ans {opt!r} vs {labels}')
                        check(''.join(labels)!='ABC',tag+' ABC')
                    else:
                        box=q.locator('.pbox').nth(1); full=box.inner_text()
                        gv=q.locator('.pbox.given').inner_text().replace('주어진 문장','').strip()
                        ins=find_n(ch,gv)
                        check(ins is not None,tag+' ins match')
                        # tokens
                        inner=box.inner_html()
                        parts=re.split(r'(<button class="mk"[^>]*>[①②③④⑤]</button>)',inner)
                        seen=[];mk=[]
                        for part in parts:
                            m=re.match(r'<button class="mk" data-i="(\d)"',part)
                            if m: mk.append((int(m.group(1)),max(seen) if seen else 0))
                            else:
                                txt=re.sub('<[^>]+>','',part).replace('&amp;','&').replace('&lt;','<').replace('&gt;','>')
                                for i,e in enumerate(EN[ch]):
                                    if e.replace('&','&') in txt: seen.append(i+1)
                        # correct marker: preceded by max passage n < ins, and next passage > ins
                        ps=[]
                        for part in parts:
                            txt=re.sub('<[^>]+>','',part)
                            for i,e in enumerate(EN[ch]):
                                if e in txt: ps.append(i+1)
                        cand=[i for (i,prev) in mk if prev==max([x for x in ps if x<ins],default=0)]
                        check(cand==[a],tag+f' ins ans {cand} vs {a}')
                    if scen=='right': sel=a
                    else: sel=[i for i in range(5) if i!=a][0]
                    q.locator('.ob,.mk').nth(sel).click()
                    cl=q.locator('.ob,.mk')
                    check('ok' in cl.nth(a).get_attribute('class'),tag+' ok mark')
                    if scen=='wrong': check('ng' in cl.nth(sel).get_attribute('class'),tag+' ng mark')
                    res=q.locator('.res').last.inner_text()
                    check(('정답이에요' in res)==(scen=='right'),tag+' res '+res)
                    if scen=='right': perfect+=1
                    check(q.locator('.ex').is_visible(),tag+' ex hidden')
                cnt=pg.locator('#cnt').inner_text()
                exp=f'{tot} / {tot} 풀었어요 · 한 번에 맞힌 문제 {perfect}개'
                check(cnt==exp,tag+f' count {cnt!r} vs {exp!r}')
                pg.locator('#rs').click()
                check(pg.locator('#cnt').inner_text().startswith('0 / %d'%tot),tag+' reset')
                check(pg.locator('.q.done').count()==0,tag+' reset done')
                check(not logs,tag+' js errors '+str(logs))
                if scen=='right' and ch=='3': pg.screenshot(path=f'/tmp/claude-0/-home-claude/669b4c4b-f62a-5708-a784-9b7cc42934b2/scratchpad/b/shot-{ch}-{name}.png',full_page=False)
                ctx.close()
    b.close()
print('ERRORS',len(errs))
