import json,re,html
from p1 import D1b
from d2 import D2
from d3 import D3
S=json.load(open('/tmp/claude-0/w/sentences.json'))['3']
EN=list(S['en']); KO=S['ko']
EN[5]=EN[5]+' Bill Traylor'
SECS=[("T1",5,12,"Bill Traylor ① 삶과 그림의 시작"),("T2",10,15,"Bill Traylor ② 작품과 평가"),
("M1",16,22,"Maud Lewis ① 삶"),("M2",23,28,"Maud Lewis ② 작품과 평가"),
("A1",29,34,"Anna Ancher ① 배움과 결혼"),("A2",35,40,"Anna Ancher ② 작품과 평가")]
items=[]
def norm(x): return re.sub(r'[^a-z0-9 ]','',x.lower().replace("'",'')).strip()
for k,(sec,i,a,ak,clue,ds) in enumerate(D1b+D2+D3):
    en=EN[i]
    assert a in en,(sec,i,a)
    assert en.count(a)==1,(sec,i,'dup')
    assert len(ds)==4 and len({norm(d[0]) for d in ds}|{norm(a)})==5
    rng=[s for s in SECS if s[0]==sec][0]; assert rng[1]<=i<=rng[2]
    items.append(dict(id=k,sec=sec,i=i,a=a,ak=ak,clue=clue,ds=[dict(t=d[0],k=d[1],w=d[2]) for d in ds]))
secs=[dict(id=s[0],title=s[3],sents=[dict(n=j,en=EN[j]+'.',ko=KO[j]) for j in range(s[1],s[2]+1)]) for s in SECS]
data=dict(secs=secs,items=items)
tpl=open('tpl.html').read()
head=open('/home/claude/via-high/h/geumcheon-gimal/3/vocab1.html').read()
style=head[head.index('<style>'):head.index('</style>')]
out=tpl.replace('/*STYLE*/',style[7:]).replace('/*DATA*/',json.dumps(data,ensure_ascii=False))
open('blank.html','w').write(out)
print(len(items),'items')
import collections;print(collections.Counter(x['sec'] for x in items))
