from d1 import D1
N={
("T1",7):[
 ("he had to face racial discrimination only in the city","그는 인종차별에 도시에서만 직면해야 했다","'only(~에서만)'로 범위를 좁힌 말이에요. 뒤에서 농장(the farm)에서 낮은 임금을 받고 일했다고 하니 도시에만 한정할 수 없어요."),
 ("he turned to drawing to express his life experiences","그는 자신의 인생 경험을 표현하기 위해 그림으로 눈을 돌렸다","두 문장 뒤(85세 이후)의 내용을 가져온 거예요. Although 뒤에서 '여전히 힘들었다'고 말해야 하는 자리와 맞지 않아요."),
 ("he had faced racial discrimination before the war ended","그는 전쟁이 끝나기 전에 인종차별에 직면했었다","차별 이야기이긴 하지만, 'Although(자유의 몸이 되었지만)' 뒤에는 자유가 된 '후에도' 여전히 겪었다는 내용이 와야 해요. 시점이 어긋나요."),
 ("he no longer had to work on the farm","그는 더 이상 농장에서 일하지 않아도 되었다","뒤의 working ... on the farm(농장에서 일하며)과 정면으로 부딪쳐요.")],
("T1",8):[
 ("found a job on a farm in the city","도시의 농장에서 일자리를 얻었다","'job(일자리)'은 맞지만 장소가 달라요. 농장은 앞에서 어린 시절을 보낸 곳이고, 이 문장은 도시로 옮겨 공장에서 일하는 이야기예요."),
 ("turned to drawing to express his life experiences","자신의 인생 경험을 표현하기 위해 그림으로 눈을 돌렸다","다음 문장에서 85세가 되어서야 그림을 시작했다고 해요. 시점이 어긋나요."),
 ("worked on a cotton farm for very low wages","매우 낮은 임금을 받고 목화 농장에서 일했다","앞 문장들의 내용을 가져온 거예요. 도시로 옮겨 간 뒤의 이야기에는 맞지 않아요."),
 ("lived with his aunt","이모와 함께 살았다","이모와 함께 산 건 Maud Lewis의 이야기예요.")],
("T1",9):[
 ("became too ill to draw","너무 아파서 그림을 그릴 수 없게 되었다","'too ill to ~' 모양은 같지만 draw(그리다)로 바꾸면, 그림으로 눈을 돌렸다는 뒤 내용과 정반대가 돼요."),
 ("moved to the city of Montgomery","몽고메리시로 이주했다","앞 문장(70세 무렵)의 내용을 가져온 거예요. 85세와 and로 이어질 일이 아니에요."),
 ("became free after the American Civil War","남북전쟁 이후 자유의 몸이 되었다","앞 문장에서 이미 지나간 일이에요. 그림으로 눈을 돌린 계기와는 거리가 멀어요."),
 ("found a better job in the city","도시에서 더 좋은 일자리를 구했다","좋은 일자리를 구한 일이 '그림으로 인생 경험을 표현하게 된' 계기가 되기는 어려워요.")],
("T1",6):[
 ("spent his early life working on a cotton farm in Montgomery","몽고메리의 목화 농장에서 일하며 어린 시절을 보냈다","농장 일은 맞지만 장소가 달라요. 몽고메리는 70세 무렵 옮겨 간 도시예요."),
 ("spent his early life working in a factory in Alabama","앨라배마의 공장에서 일하며 어린 시절을 보냈다","공장은 나중에 도시로 가서 얻은 일자리예요. 다음 문장의 the farm(그 농장)과도 이어지지 않아요."),
 ("spent his early life working on a cotton farm in Canada","캐나다의 목화 농장에서 일하며 어린 시절을 보냈다","농장 일은 맞지만 U.S.(미국)에서 태어났다는 앞 내용과 어긋나요. 캐나다는 Maud Lewis의 이야기예요."),
 ("spent his early life studying at a school in Alabama","앨라배마의 학교에서 공부하며 어린 시절을 보냈다","노예로 태어난 사람이 학교에 다녔다는 말은 어색하고, 다음 문장 the farm과 이어지지 않아요.")],
("T1",11):[
 ("because they had often been used on farms to watch and hunt animals","개가 농장에서 동물을 감시하고 사냥하는 데 자주 사용되었기 때문에","slaves(노예)를 animals(동물)로 바꾼 거예요. 그러면 노예였던 그가 개를 무서워할 이유가 없어져요."),
 ("although they had often been used on farms to watch and hunt slaves","개가 농장에서 노예를 감시하고 사냥하는 데 자주 사용되었는데도","내용은 같지만 although(~인데도)는 연결이 어긋나요. 이유를 말하는 because가 와야 두려움이 설명돼요."),
 ("because they had often been kept in factories to guard workers","개가 공장에서 노동자를 지키는 데 자주 쓰였기 때문에","공장은 나중 이야기예요. 두려움은 노예 시절 농장에서의 경험에서 와요."),
 ("because they had often been used on farms to protect slaves","개가 농장에서 노예를 보호하는 데 자주 사용되었기 때문에","보호해 주는 개를 무서워할 이유가 없어요.")],
("T2",11):[
 ("had a strong fear of all animals","모든 동물에 대한 큰 두려움이 있었다","범위를 넓힌 말이에요. 다음 문장에서 His fear of dogs(개에 대한 그의 두려움)라고 해서 개로 한정돼요."),
 ("had a strong fear of losing his job in the factory","공장에서 일자리를 잃을까 봐 큰 두려움이 있었다","공장 이야기를 가져온 거예요. because 뒤의 '개가 노예를 사냥했다'와 이어지지 않아요."),
 ("had a strong love for dogs","개를 매우 좋아했다","노예를 사냥하는 데 쓰인 개를 좋아할 수는 없어요."),
 ("preferred dogs to people","사람보다 개를 더 좋아했다","다음 문장 His fear of dogs와 정반대예요.")],
("T2",12):[
 ("is expressed strongly in all of his paintings","그의 모든 그림에 강하게 표현되어 있다","all(모든)로 범위를 넓힌 말이에요. 다음 문장 In contrast에서 자유로운 삶을 그린 작품도 있다고 하니 모든 그림은 아니에요."),
 ("is shown by the free lives of African Americans","아프리카계 미국인의 자유로운 삶으로 나타난다","다음 문장의 내용을 가져온 거예요. 그 작품은 두려움이 아니라 '자유'를 그린 것이라 이 자리에 맞지 않아요."),
 ("is hidden carefully in these pieces","이 작품들에 조심스럽게 숨겨져 있다","In contrast로 '자유로운 삶'과 대조되려면 이 작품들에는 두려움이 드러나야 해요."),
 ("is rarely seen in these pieces","이 작품들에서 좀처럼 보이지 않는다","이 작품들이 바로 개를 그린 〈Mean Dog〉 등인데 두려움이 안 보일 수는 없어요.")],
("T2",13):[
 ("portrays the free lives of all Americans","모든 미국인의 자유로운 삶을 묘사한다","all Americans(모든 미국인)로 범위를 넓힌 말이에요. 〈Woman with Purse...〉는 African Americans(아프리카계 미국인)의 삶을 그려요."),
 ("portrays the fearful lives of slaves on farms","농장 노예들의 두려운 삶을 묘사한다","앞 문장(두려움)의 내용을 가져온 거예요. In contrast니까 또 두려움이면 안 돼요."),
 ("portrays the fearful lives of African Americans","아프리카계 미국인의 두려운 삶을 묘사한다","대상은 맞지만 In contrast(이와 대조적으로)와 어긋나요. 앞의 두려움과 대조되는 '자유'가 와야 해요."),
 ("portrays the hard lives of workers in factories","공장 노동자들의 힘든 삶을 묘사한다","'몽고메리 거리에서 관찰한' 모습과 맞지 않고 대조의 방향도 어긋나요.")],
("T2",14):[
 ("captured every moment in American history","미국 역사의 모든 순간을 포착했다","every(모든)로 과장한 말이에요. 작은 형태와 색채로 모든 순간을 담는다는 건 본문과 맞지 않아요."),
 ("captured simple moments in American history","미국 역사의 단순한 순간을 포착했다","앞의 simple(단순한)을 가져와 complex(복잡한)를 바꾼 거예요. 단순한 도구로 '복잡한' 순간을 담았다는 대비가 본문의 맛이에요."),
 ("captured the beautiful landscapes of Digby","딕비의 아름다운 풍경을 포착했다","Maud Lewis의 이야기예요. 이 자리는 from slavery to freedom(노예 제도에서 자유로)과 이어져야 해요."),
 ("captured complex moments in African history","아프리카 역사의 복잡한 순간을 포착했다","'미국'을 '아프리카'로 바꾼 거예요. 노예에서 자유로 가는 것은 미국에서의 일이고, 다음 문장도 American folk art(미국 민속 예술)로 이어져요.")],
("T2",15):[
 ("he's now considered the greatest figure in American art","그는 현재 미국 미술의 가장 위대한 인물로 여겨진다","greatest(가장 위대한)로 과장한 말이에요. 본문은 '민속 예술의 중요한 인물'이라고만 해요."),
 ("he's now considered an important figure in Canadian folk art","그는 현재 캐나다 민속 예술의 중요한 인물로 여겨진다","캐나다는 Maud Lewis의 이야기예요. Traylor는 미국 역사를 그렸어요."),
 ("he's now forgotten by most art lovers","그는 현재 대부분의 미술 애호가에게 잊혀졌다","좋은 업적의 '결과(As a result)'로는 어색해요."),
 ("he's now known only as a factory worker","그는 현재 공장 노동자로만 알려져 있다","그림 업적의 결과로는 맞지 않아요.")],
}
D1b=[]
for (s,i,a,ak,c,ds) in D1:
    D1b.append((s,i,a,ak,c,N[(s,i)]))

# ---- 수정본 ----
_rep={
("T1",8):("T1",12,"His fear of dogs","개에 대한 그의 두려움",
 "바로 앞 문장에서 'Traylor는 개에 대한 큰 두려움이 있었다'고 했어요. 이 문장은 그 이야기를 이어받아 these pieces(이 작품들) 속에 그것이 어떻게 나타나는지를 말해요.",
 [("His fear of all animals","모든 동물에 대한 그의 두려움","all(모든)로 범위를 넓힌 말이에요. 앞 문장은 개(dogs)에 대한 두려움만 말해요."),
  ("His fear of losing his job","일자리를 잃는 것에 대한 그의 두려움","앞부분(70세 무렵 공장 일자리 이야기)을 가져온 거예요. 이 문장은 개 이야기를 이어받아요."),
  ("His love for dogs","개에 대한 그의 사랑","앞 문장에서 개 때문에 두려움이 컸다고 했으니 반대예요."),
  ("His fear of illness","병에 대한 그의 두려움","앞의 too ill to work(아파서 일할 수 없는)에서 가져온 말이에요. 두려움의 대상은 개예요.")]),
("T1",6):("T1",6,"spent his early life working on a cotton farm","목화 농장에서 일하며 어린 시절을 보냈다",
 "'노예로 태어났다'는 말에 이어지고, 바로 다음 문장에서 the farm(그 농장)이라고 해서 농장 이야기가 앞에 나와야 해요.",
 [("spent his whole life working on a cotton farm","평생을 목화 농장에서 일하며 보냈다","early(어린 시절)를 whole(평생)로 바꿨어요. 본문에서 그는 나중에 도시로 옮겨 가요."),
  ("spent his early life working in a factory","공장에서 일하며 어린 시절을 보냈다","공장은 70세 무렵 도시로 옮긴 뒤에 얻은 일자리예요. 다음 문장의 the farm과도 이어지지 않아요."),
  ("spent his early life drawing pictures of dogs","개 그림을 그리며 어린 시절을 보냈다","그림은 85세가 되어서야 시작했어요."),
  ("spent his early life studying at a school","학교에서 공부하며 어린 시절을 보냈다","노예로 태어난 사람이 학교에 다녔다는 말은 어색하고, 다음 문장 the farm과 이어지지 않아요.")]),
("T2",13):("T2",13,"portrays the free lives","자유로운 삶을 묘사한다",
 "In contrast(이와 대조적으로)가 핵심이에요. 앞은 개에 대한 '두려움'이었으니, 뒤는 그와 반대인 '자유로운 삶'이 와요. 문장 끝의 African Americans(아프리카계 미국인)와 몽고메리 '거리'에서 본 모습이라는 점도 맞아요.",
 [("portrays the fearful lives","두려운 삶을 묘사한다","앞 문장(두려움)의 내용을 가져온 거예요. In contrast니까 또 두려움이면 안 돼요."),
  ("portrays the enslaved lives","노예로 사는 삶을 묘사한다","Traylor의 어린 시절(노예 생활)을 가져온 거예요. '거리에서 관찰한' 자유로운 삶과 맞지 않아요."),
  ("portrays the dangerous lives","위험한 삶을 묘사한다","두려움 쪽의 내용이라 In contrast와 어긋나요."),
  ("portrays the hard lives","힘든 삶을 묘사한다","힘든 삶은 앞 작품들의 분위기예요. In contrast 뒤에는 반대가 와요.")]),
}
D1b=[_rep.get((s,i),(s,i,a,ak,c,ds)) for (s,i,a,ak,c,ds) in D1b]
