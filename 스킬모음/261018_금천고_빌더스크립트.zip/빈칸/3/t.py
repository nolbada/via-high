import os,json,collections
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
errs=[];ids=[];secs=[];anspos=[];res=[]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':420,'height':900})
    pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:m.type=='error' and errs.append(m.text))
    pg.on('dialog',lambda d:d.accept())
    pg.goto('file:///tmp/claude-0/w/agentE/3/blank.html')
    rounds=[]
    for lap in range(2):
        seen=[]
        while True:
            c=pg.query_selector('#card')
            if not c:
                txt=pg.inner_text('#app');rounds.append(txt.replace('\n',' | '))
                assert pg.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth'),'hscroll'
                pg.click('#go');
                if 'ㅡ' in txt: pass
                if '한 바퀴를 모두' in txt: break
                continue
            i=int(c.get_attribute('data-id'));seen.append((i,c.get_attribute('data-sec')));anspos.append(int(c.get_attribute('data-ans')))
            assert pg.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth'),'hscroll q'
            ans=int(c.get_attribute('data-ans'))
            wrong=(len(seen)%3==0)
            k=(ans%5)+1 if wrong else ans
            pg.click(f'.ob[data-i="{k-1}"]')
            assert pg.query_selector('.ob.ok'),'no ok mark'
            if wrong: assert pg.query_selector('.ob.ng')
            pg.screenshot(path='/tmp/claude-0/w/agentE/3/s.png') if len(seen)==1 and lap==0 else None
            res.append(pg.inner_text('#cnt'))
            pg.click('#nx')
        ids.append([s[0] for s in seen]);secs.append([s[1] for s in seen])
        print('lap',lap,'n',len(seen),'unique',len(set(s[0] for s in seen)))
    # restart
    pg.click('#rs');print('after reset:',pg.inner_text('#cnt'))
    pg.reload();print('reload:',pg.inner_text('#cnt'))
    b.close()
print('errors',errs)
print('adjacent same sec:',sum(1 for l in secs for a,b_ in zip(l,l[1:]) if a==b_))
print(collections.Counter(anspos))
print(res[0],'||',res[7],'||',res[29])
for r in rounds:print(r)
