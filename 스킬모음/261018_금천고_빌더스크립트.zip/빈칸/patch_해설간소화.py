import re,json,sys
g=sys.argv[1]
src=f'/tmp/claude-0/w/agentE/{g}/blank.html'
s=open(src,encoding='utf8').read()
sh=json.load(open(f'/tmp/claude-0/w/agentE/{g}/short.json',encoding='utf8'))
m=re.search(r'var DATA=(\{.*?\});\n',s,re.S)
d=json.loads(m.group(1))
for sec in d['secs']:
    assert sec['id'] in sh['themes'],sec['id']; sec['theme']=sh['themes'][sec['id']]
for it in d['items']:
    assert str(it['id']) in sh['traps'],it['id']; it['trap']=sh['traps'][str(it['id'])]
s=s[:m.start(1)]+json.dumps(d,ensure_ascii=False)+s[m.end(1):]
# explanation block
a=s.index("  var h='<div class=\"res '")
b=s.index("  var last=R.n>=R.total;")
new='''  var sc=SECS[it.sec];
  var h='<div class="res '+(ok?'o':'x')+'">'+(ok?'정답이에요.':'아쉬워요. 정답은 '+nums[ci]+'번이에요.')+'</div>';
  h+='<div class="th"><b>이 글의 주제의식</b><br>'+esc(sc.theme)+'</div>';
  h+='<div class="wd"><b>정답 문장</b><br>'+esc(s.en).replace(esc(it.a),'<span class="fill">'+esc(it.a)+'</span>')+'<br><span style="color:var(--sub)">'+esc(s.ko)+'</span></div>';
  h+='<div class="tp"><b>함정 주의</b><br>'+esc(it.trap)+'</div>';
  h+='<details class="more"><summary>보기별로 자세히 보기</summary><div class="kk"><b>정답 근거</b> · '+esc(it.clue)+'</div><ul>';
  o.forEach(function(x,j){
    if(x.c)h+='<li class="c">'+nums[j]+' '+esc(x.t)+' <span class="ko">('+esc(it.ak)+')</span><span class="w">정답: 이 말을 넣으면 앞뒤 흐름이 자연스럽게 이어져요.</span></li>';
    else h+='<li>'+nums[j]+' '+esc(x.t)+' <span class="ko">('+esc(x.k)+')</span><span class="w">'+esc(x.w)+'</span></li>';
  });
  h+='</ul></details>';
'''
s=s[:a]+new+s[b:]
css='.ex .th{background:var(--priL);border-radius:10px;padding:8px 12px;margin:6px 0;font-size:16px}.ex .tp{border-left:4px solid var(--warn);background:var(--pi);color:var(--piInk);border-radius:0 10px 10px 0;padding:8px 12px;margin:8px 0;font-size:16px}.ex .tp b{color:var(--warn)}.ex .more{margin:8px 0;font-size:14.5px;color:var(--sub)}.ex .more summary{cursor:pointer;padding:4px 0}\n</style>'
s=s.replace('</style>',css,1)
open(f'/tmp/claude-0/w/agentE/p/blank{g}.html','w',encoding='utf8').write(s)
print('ok',g)
