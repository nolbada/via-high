import json
themes={
"A":"AI 신경 임플란트는 오랜 신경계 치료 연구의 놀라운 진전이지만, 윤리 문제도 함께 따진다는 도입이에요.",
"B":"AI 임플란트는 파킨슨병, 마비, 의수 같은 의료 현장에서 이미 실제로 쓰이고 있다는 얘기예요.",
"C":"임플란트의 성공은 의료를 넘어 일상으로 번져 생각만으로 기기를 쓰는 시대가 온다는 얘기예요.",
"D":"기억을 올리고 내려받으면 뇌의 역할이 외우기에서 활용하기로 바뀔 거라는 얘기예요.",
"E":"좋은 기술이어도 인간다움, 의존, 개인 정보 문제를 먼저 해결해야 한다는 얘기예요.",
"F":"해킹과 불평등 위험이 크니 연구 전에 윤리 검토를 거쳐 기술을 발전시키자는 얘기예요.",
"G":"댓글은 기술의 장점에 감탄하면서도 프라이버시 걱정과 대책을 이야기해요."}
traps={
0:"정답은 nervous system(신경계)인데, brain only(뇌에만) / all diseases(모든 질병)처럼 범위를 줄이거나 부풀려 바꿔 내요.",
1:"정답은 implanted in the nervous system(신경계에 이식된)인데, every part of the body(몸의 모든 부위) / worn outside(몸 밖에 착용된)로 바꿔 낚아요.",
2:"정답은 begun to integrate(통합하기 시작했다)인데, already integrated into every(이미 모든 곳에 통합했다) / failed(실패했다)로 시점과 범위를 비틀어요.",
3:"정답은 incredible benefits(놀라운 장점)인데, 뒤에 나오는 ethical concerns(윤리적 우려)를 끌어와 fail 하게 만들거나 limited(제한적인)로 뒤집어요.",
4:"정답은 a range of problems(다양한 문제)인데, every problem(모든 문제) / a single minor problem(사소한 문제 하나)처럼 개수를 과장하거나 줄여요.",
5:"정답은 treat(치료하다)인데, cause(일으키다)로 뒤집거나 cure permanently(영구적으로 완치하다)처럼 과장해서 내요.",
6:"정답은 restore normal(정상으로 회복시키다)인데, enhance beyond normal(정상 이상으로 높이다) / destroy(파괴하다)처럼 방향을 바꿔 내요.",
7:"정답은 walk again(다시 걷다)인데, 다음 문장의 arms(팔)나 Parkinson's(파킨슨병)를 끌어와 같은 문단 안에서 낚아요.",
8:"정답은 to their legs(다리로)인데, to their arms(팔로) / back to the brain(뇌로 되돌려)처럼 도착지만 바꿔 내요.",
9:"정답은 the same mechanism(같은 원리)인데, completely different(완전히 다른)처럼 반대로 쓰거나 without any implants(임플란트 없이)를 덧붙여요.",
10:"정답은 spread to other industries(다른 산업으로 확산)인데, limited to health care only(의료에만 한정) 같은 반대말로 뒤집어 내요.",
11:"정답은 commercially available(상용화되다)인데, banned(금지되다) / free to everyone(모두에게 무료)처럼 본문에 없는 사실을 붙여 내요.",
12:"정답은 read our minds(우리 마음을 읽다)인데, read everyone's minds without permission(허락 없이 모두의 마음을 읽다)처럼 부풀리거나 앞 문장의 restore(회복하다)를 끌어와요.",
13:"정답은 simply by thinking(그저 생각만으로)인데, only with our hands(오직 손으로만) / by pressing buttons(버튼을 눌러서)처럼 반대 방법으로 바꿔요.",
14:"정답은 memory-enhancing(기억력을 높이는)인데, mind-reading(마음을 읽는) / memory-erasing(기억을 지우는)처럼 앞 문장 단어나 반대말로 낚아요.",
15:"정답은 upload and download(올리고 내려받다)인데, 앞의 capture and enhance(캡처하고 향상시키다)를 그대로 반복하거나 erase(지우다)로 뒤집어 내요.",
16:"정답은 back up(백업하다)인데, lose(잃다) / sell to hackers(해커에게 팔다)처럼 반대 뜻이나 윤리 파트 단어를 섞어 내요. 앞에 나온 share(공유하다)도 조심해요.",
17:"정답은 revolutionize(혁명을 일으키다)인데, make no difference(아무 차이도 없다)로 뒤집거나 hospitals(병원)처럼 대상만 바꿔 내요.",
18:"정답은 processing(처리하는 것)인데, 앞의 storing(저장하는 것)을 그대로 쓰거나 ignoring(무시하는 것)처럼 반대로 바꿔요. shift(바뀌다)가 힌트예요.",
19:"정답은 generate new ideas(새 아이디어를 만들다)인데, memorize(외우다)는 Instead of(~ 대신에)와 어긋나고 copy others' ideas(남의 생각을 베끼다)는 new와 어긋나요.",
20:"정답은 be addressed(해결되다)인데, ignored(무시되다) / postponed(미뤄지다)처럼 Before(~ 전에)와 어긋나는 쪽으로 낚아요.",
21:"정답은 what it means to be human(인간이라는 존재의 의미)인데, 뒤에서 나오는 personal data(개인 정보)나 machine(기계)으로 바꿔 내요.",
22:"정답은 central to(~의 중심인)인데, the only part(유일한 부위) / unrelated to(무관한)처럼 극단으로 바꾸거나 less important(덜 중요한)로 뒤집어요.",
23:"정답은 delay(지연시키다)인데, speed up(가속하다) / support(돕다)처럼 반대 방향으로 쓰거나 대상을 AI technology(AI 기술)로 바꿔 내요. However(그러나)가 단서예요.",
24:"정답은 without permission(허락 없이)인데, only with permission(허락이 있을 때만)처럼 긍정으로 바꿔 내요. risk(위험)와 방향이 어긋나는 보기를 지워요.",
25:"정답은 controlled by hackers(해커에게 통제되는)인데, protected from(~로부터 보호받는) / fully controlled by ourselves(우리 스스로 통제되는)처럼 위험이 아닌 방향으로 바꿔요.",
26:"정답은 even greater social inequality(사회적 불평등의 심화)인데, privacy problems(프라이버시 문제)는 앞 문장 내용이고 more equal(더 평등한)은 반대말이에요.",
27:"정답은 those who cannot(그럴 수 없는 사람들)인데, afford(감당하다)의 반대 짝을 찾는 자리예요. those who hack(해킹하는 사람들) 식으로 엉뚱한 집단을 넣어 내요.",
28:"정답은 overcome(극복하다)인데, avoid completely(완전히 피하다) / ignore(무시하다) / increase(늘리다)처럼 hope(바라다)와 어긋나는 쪽으로 바꿔 내요.",
29:"정답은 before(~하기 전에)인데, while(~하는 동안) / after(~한 뒤에)처럼 시점을 바꿔 내요. prior review(사전 검토)가 힌트예요.",
30:"정답은 in accordance with ethical principles(윤리적 원칙에 따라)인데, without any(어떠한 ~도 없이) / in spite of(~에도 불구하고)처럼 반대로 쓰거나 commercial demand(상업적 수요)로 바꿔요.",
31:"정답은 according to their thoughts(생각에 따라)인데, regardless of(~와 상관없이) / without any thoughts(생각 없이)처럼 반대로 쓰고 hackers(해커)나 doctors(의사)로 대상을 바꿔요.",
32:"정답은 the privacy issues it might cause(그것이 일으킬 수 있는 프라이버시 문제)인데, solve(해결하다)나 benefits(장점)로 바꿔요. worried(걱정되는)와 맞는지 보세요.",
33:"정답은 individuals(개인)를 보호하는 것인데, companies(회사)로 대상을 바꾸거나 share / sell(공유하다 / 팔다)처럼 enforce privacy laws(개인 정보 보호법 시행)와 어긋나게 내요.",
34:"정답은 address the concerns(우려를 해결하다)인데, every concern perfectly(모든 우려를 완벽히)로 과장하거나 ignore / multiply(무시하다 / 늘리다)로 뒤집어요.",
}
traps[3]="정답은 incredible benefits(놀라운 장점)인데, 뒤에 나오는 ethical concerns(윤리적 우려)를 끌어오거나 limited benefits(제한적인 장점)로 뒤집어 내요."
traps[16]="정답은 back up(백업하다)인데, lose(잃다) / sell to hackers(해커에게 팔다)처럼 반대 뜻이나 윤리 파트 단어를 섞어 내요."
traps[24]="정답은 without permission(허락 없이)인데, only with permission(허락이 있을 때만)처럼 긍정으로 바꿔 내요. risk(위험)와 어긋나는 보기를 지워요."
traps[23]="정답은 delay(지연시키다)인데, speed up(가속하다) / support(돕다)처럼 반대로 쓰거나 대상을 AI technology(AI 기술)로 바꿔 내요."
traps[12]="정답은 read our minds(우리 마음을 읽다)인데, read everyone's minds without permission(허락 없이 모두의 마음을 읽다)처럼 부풀리거나 restore(회복하다)를 끌어와요."
json.dump({"themes":themes,"traps":{str(k):v for k,v in traps.items()}},open('short.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
