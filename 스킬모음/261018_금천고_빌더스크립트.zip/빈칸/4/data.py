# -*- coding: utf-8 -*-
SEGS = [
 ("A","신경 임플란트와 AI (도입)",0,5),
 ("B","의료 분야 활용",6,10),
 ("C","미래 전망 ①",11,15),
 ("D","미래 전망 ②",16,20),
 ("E","윤리적 문제 ①",21,26),
 ("F","윤리적 문제 ②와 신경 윤리",27,35),
 ("G","댓글",36,41),
]
# (seg, sentIdx, answer, answerKo, clue, [(wrong, wrongKo, why)*4])
I = []
def add(seg, idx, ans, ako, clue, ds): I.append((seg, idx, ans, ako, clue, ds))

# ---------- A ----------
add("A",0,"disorders of the nervous system","신경계 질환",
 "빈칸 바로 뒤에 {including the brain and spinal cord|뇌와 척수를 포함한}이 붙어 있어요. 뇌와 척수가 들어가는 '계통'은 신경계뿐이에요.",
 [("diseases of the digestive system","소화계 질환","뇌와 척수는 소화계가 아니라 신경계에 속해요."),
  ("disorders of the immune system","면역계 질환","뇌와 척수를 '포함한다'는 말과 맞지 않아요."),
  ("diseases of the heart and blood vessels","심장과 혈관의 질환","뇌와 척수는 심장·혈관 계통이 아니에요."),
  ("disorders of the respiratory system","호흡계 질환","호흡계에는 뇌와 척수가 들어가지 않아요.")])
add("A",1,"that can be implanted in the nervous system","신경계에 이식될 수 있는",
 "{neural implants|신경 임플란트}를 풀어 설명하는 자리예요. {implant|임플란트}는 몸 안에 '심는' 장치라서 몸 안에 넣는다는 말이 와야 해요.",
 [("that can be removed from the nervous system","신경계에서 제거될 수 있는","임플란트는 '심는' 기기인데 '제거'라고 하면 정의가 거꾸로 돼요."),
  ("that can be worn outside the human body","몸 밖에 착용할 수 있는","몸 밖에 차는 기기는 임플란트가 아니에요."),
  ("that can replace the whole nervous system","신경계 전체를 대체할 수 있는","'전체를 대체'는 지나친 과장이고 앞의 '의료 기기'라는 설명과도 안 맞아요."),
  ("that can be controlled by the nervous system","신경계에 의해 조종될 수 있는","'신경계에 이식된다'는 정의가 아니라서 설명이 되지 않아요.")])
add("A",2,"have begun to integrate AI into neural implants","신경 임플란트에 AI를 통합하기 시작했다",
 "{here's the exciting part|흥미로운 점은 여기 있다}라고 했으니 좋은 소식이 와야 해요. 거기에 {rapid advancement of AI|AI의 급속한 발전}이 이유로 붙어 있어요.",
 [("have stopped studying neural implants because of AI","AI 때문에 신경 임플란트 연구를 그만두었다","'흥미로운 점'이라고 해 놓고 연구를 그만두었다는 건 흐름이 안 맞아요."),
  ("have failed to apply AI to neural implants","신경 임플란트에 AI를 적용하는 데 실패했다","'실패'는 흥미로운 소식이 아니에요."),
  ("have decided to replace neural implants with AI","신경 임플란트를 AI로 대체하기로 했다","글 전체는 임플란트에 AI를 '더하는' 이야기지, 임플란트를 없애는 이야기가 아니에요."),
  ("have begun to worry about AI in neural implants","신경 임플란트 속 AI를 걱정하기 시작했다","걱정은 '흥미로운 점'이 아니고, 걱정거리는 뒤에서 따로 다뤄요.")])
add("A",3,"incredible benefits","놀라운 장점",
 "'{the ___ of AI-powered neural implants|AI 기반 신경 임플란트의 ___}'에 이어 {their amazing potential|그것들의 놀라운 잠재력}이 나와요. 앞 문장도 {exciting|흥미로운}이라서 긍정적인 말이 먼저 와요. 위험은 맨 끝의 {ethical concerns|윤리적 우려}가 따로 맡아요.",
 [("serious dangers","심각한 위험","위험은 맨 끝의 '윤리적 우려'와 겹치고, 긍정적인 흐름과도 어긋나요."),
  ("long history","오랜 역사","AI를 넣기 시작한 건 최근이라고 바로 앞 문장에서 말했어요."),
  ("high costs","높은 비용","앞뒤가 모두 긍정적인 말인데 비용은 맞지 않아요."),
  ("total failure","완전한 실패","'놀라운 잠재력', '흥미로운 점'과 정반대예요.")])
add("A",5,"offering solutions to a range of problems","다양한 문제에 해결책을 제시하며",
 "{has shown great promise|큰 가능성을 보여 주었다}가 앞에 있어요. 가능성이 크다고 한 이유가 뒤에 와야 하니 '문제를 해결해 준다'는 말이 자연스러워요.",
 [("causing a range of unexpected problems","예상치 못한 다양한 문제를 일으키며","문제를 일으킨다면 '큰 가능성'의 이유가 될 수 없어요."),
  ("ignoring a range of serious problems","심각한 여러 문제를 무시하며","문제를 무시하는 것은 가능성을 보여 준 게 아니에요."),
  ("solving only a single minor problem","사소한 문제 하나만 해결하며","'큰 가능성'과 '다양한(a range of)'이라는 흐름에 비해 너무 작아요."),
  ("hiding a range of problems from doctors","여러 문제를 의사들에게서 숨기며","문제를 숨기는 것은 가능성이 아니라 위험이에요.")])

# ---------- B ----------
add("B",6,"treat brain disorders like Parkinson's disease","파킨슨병 같은 뇌 질환을 치료하다",
 "{For instance|예를 들어}로 시작해요. 앞 문장에서 '의료 분야에서 문제를 해결해 준다'고 했으니, 그 예로 병을 {treat|치료하다}하는 말이 와야 해요. 신경(neural) 임플란트이니 뇌 질환이 어울려요.",
 [("cause brain disorders like Parkinson's disease","파킨슨병 같은 뇌 질환을 일으키다","의료 분야의 '해결책' 예시인데 병을 '일으킨다'고 하면 반대예요."),
  ("treat stomach problems like food poisoning","식중독 같은 위장 문제를 치료하다","신경(neural) 임플란트는 신경계·뇌 질환에 쓰이지 위장 문제와는 거리가 멀어요."),
  ("cure every disease in the human body","인체의 모든 질병을 치료하다","'모든 병'은 지나친 단정이고, 예시(For instance)는 구체적인 병 하나를 들어야 해요."),
  ("treat heart disorders like a heart attack","심장마비 같은 심장 질환을 치료하다","신경 임플란트의 대상은 심장이 아니라 뇌 같은 신경계예요.")])
add("B",7,"restore normal brain activity","정상적인 뇌 활동을 회복시키다",
 "{electrically stimulate targeted regions of the brain|뇌의 표적 부위를 전기로 자극한다}는 것이 치료 방법이에요. 앞 문장에서 파킨슨병 같은 병을 치료한다고 했으니 목적은 정상 상태를 되찾는 것이에요.",
 [("destroy normal brain activity","정상적인 뇌 활동을 파괴하다","치료 이야기인데 정상 활동을 파괴한다면 앞 문장과 정반대예요."),
  ("stop all brain activity completely","모든 뇌 활동을 완전히 멈추다","뇌 활동을 완전히 멈추면 치료가 아니에요."),
  ("replace the brain with a computer","뇌를 컴퓨터로 대체하다","'표적 부위를 자극'하는 방식과 달리 뇌 자체를 바꾸는 것은 과장이에요."),
  ("damage targeted regions of the brain","뇌의 표적 부위를 손상시키다","표적 부위를 자극하는 이유는 치료이지 손상이 아니에요.")])
add("B",8,"have the ability to walk again","다시 걸을 수 있는 능력을 갖다",
 "마비 환자(paralyzed people)에게 {with the help of a digital bridge|디지털 브릿지의 도움으로} 일어나는 일이에요. 도움을 받아 이루어지는 좋은 결과가 와야 하고, 바로 다음 문장이 다리를 움직이는 이야기예요.",
 [("lose the ability to walk again","다시 걷는 능력을 잃다","'도움(help)'으로 얻는 효과인데 능력을 잃는다면 어긋나요."),
  ("learn to walk without any help","아무 도움 없이 걷는 법을 배우다","바로 뒤에 '디지털 브릿지의 도움으로'가 있어서 '도움 없이'와 충돌해요."),
  ("have the ability to see again","다시 볼 수 있는 능력을 갖다","다음 문장이 다리를 움직이는 이야기라서 시력이 아니에요."),
  ("run faster than ordinary people","보통 사람보다 빨리 달리다","마비 환자가 '다시 걷는다'는 이야기에서 '더 빨리 달린다'는 지나친 과장이에요.")])
add("B",9,"sends them to their legs through the implants","임플란트를 통해 그 신호를 다리로 보낸다",
 "{When they think about moving their legs|다리를 움직이려고 생각하면}이라는 조건이 있어요. AI가 뇌 신호를 분석한 뒤에는 다리를 움직이게 하려고 신호를 {legs|다리}로 보내야 해요.",
 [("sends them to the doctor through the Internet","인터넷을 통해 그 신호를 의사에게 보낸다","환자가 걷게 하려면 신호가 다리로 가야지 의사에게 갈 필요가 없어요."),
  ("blocks them from reaching their legs","그 신호가 다리에 닿지 못하게 막는다","신호를 막으면 걷게 도와준다는 앞 문장과 반대예요."),
  ("keeps them in the implants without sending anything","아무것도 보내지 않고 임플란트에 보관한다","'보내지 않으면' 다리가 움직일 수 없어요."),
  ("sends them to the other patients' brains","그 신호를 다른 환자들의 뇌로 보낸다","내 다리를 움직이게 하는 신호가 다른 사람의 뇌로 가면 말이 안 돼요.")])
add("B",10,"operated by the same mechanism","같은 원리로 작동하는",
 "{Similarly|마찬가지로}가 앞에 있어요. 다리 이야기와 '비슷한' 방식이라는 뜻이니 같은 원리로 작동한다는 말이 와야 해요.",
 [("operated by a different mechanism","다른 원리로 작동하는","'마찬가지로(Similarly)'와 반대로 '다른' 방식이라고 하면 어긋나요."),
  ("operated by their own hands","자기 손으로 작동하는","팔을 잃은 사람들 이야기이므로 손으로 움직일 수 없어요."),
  ("operated without any signals from the brain","뇌 신호 없이 작동하는","앞 문장의 핵심이 뇌 신호를 보내는 원리이므로 '뇌 신호 없이'는 맞지 않아요."),
  ("controlled only by the doctors nearby","주변 의사들만 조종할 수 있는","'생각으로 움직인다'는 흐름과 달리 의사가 조종한다는 말이 되어 버려요.")])

# ---------- C ----------
add("C",11,"spread to other industries","다른 산업으로 확산되다",
 "{also|또한}이 있어서 의료 분야 말고 '다른 곳에도' 퍼진다는 뜻이 와야 해요. 문장 앞부분이 '의료 분야에서의 성공'이에요.",
 [("be limited to health care only","의료 분야에만 한정되다","'또한(also)'과 어긋나요. 다른 분야로 넓어진다는 말이 필요해요."),
  ("fall behind in other industries","다른 산업에서 뒤처지다","성공이 '번져 간다'는 흐름과 맞지 않아요."),
  ("stop at the hospital door","병원 문턱에서 멈추다","'또한'이 있어 의료 밖으로 나가야 하는데 병원 안에 머문다는 말이 돼요."),
  ("replace health care in other industries","다른 산업에서 의료를 대체하다","산업 안에서 '의료를 대체'한다는 말은 뜻이 안 통해요.")])
add("C",12,"become commercially available in the next 20 to 30 years","향후 20~30년 이내에 상용화되다",
 "뒤에 {significantly change our daily lives|우리의 일상을 크게 바꾼다}가 이어져요. 일상을 바꾸려면 병원 밖에서 일반 사람이 살 수 있어야 하니 '상용화'가 와야 해요.",
 [("stay only in hospitals for the next 20 to 30 years","향후 20~30년 동안 병원에만 머물다","병원에만 있으면 일상을 크게 바꿀 수 없어요."),
  ("be banned in most countries within the next 20 to 30 years","향후 20~30년 안에 대부분의 나라에서 금지되다","금지되면 일상을 바꾼다는 뒤 내용과 안 맞아요."),
  ("be forgotten by researchers in the next 20 to 30 years","향후 20~30년 안에 연구자들에게 잊히다","미래학자들의 '예측'인데 잊힌다면 일상을 바꿀 수 없어요."),
  ("be given free to everyone in the next 20 to 30 years","향후 20~30년 안에 모두에게 무료로 주어지다","'무료로 준다'는 근거가 없고, 시판(commercial)이라는 흐름과도 달라요.")])
add("C",13,"can read our minds","우리의 마음을 읽을 수 있는",
 "다음 문장이 {play games, type messages, and stream music simply by thinking|생각만으로 게임을 하고 메시지를 입력하고 음악을 듣는다}예요. 생각을 기계가 알아채야 가능한 일이니 마음을 '읽는' 소프트웨어예요.",
 [("can translate every language for us","모든 언어를 우리 대신 번역해 줄 수 있는","다음 문장의 '생각만으로 한다'와 이어지지 않아요."),
  ("can delete our bad dreams","우리의 나쁜 꿈을 지울 수 있는","다음 문장에서 말하는 게임·메시지·음악과 상관이 없어요."),
  ("can control other people's minds","다른 사람들의 마음을 조종할 수 있는","'우리가 생각만으로 하는 것'이 아니라 남을 조종하는 이야기가 되어 버려요."),
  ("can make us sleep faster","우리를 더 빨리 잠들게 할 수 있는","다음 문장의 활동(게임·메시지·음악)과 연결되지 않아요.")])
add("C",14,"simply by thinking","그저 생각하는 것만으로",
 "'게임을 하고, 메시지를 입력하고, 음악을 듣는' 것은 평소엔 손으로 하는 일이에요. 앞 문장의 {software that can read our minds|우리의 마음을 읽는 소프트웨어} 덕분에 '생각만으로'가 가능해져요.",
 [("only with our hands","오직 손으로만","마음을 읽는 소프트웨어를 설치했는데 손으로만 한다면 의미가 없어요."),
  ("by pressing many buttons","많은 버튼을 눌러서","앞 문장에서 말한 기술의 장점이 사라져요."),
  ("only after a long surgery","오랜 수술을 한 뒤에만","수술은 설치 과정일 뿐, 이 문장은 그 뒤에 할 수 있는 일을 말해요."),
  ("without using any software","어떤 소프트웨어도 쓰지 않고","바로 앞 문장이 소프트웨어를 설치한다는 이야기예요.")])
add("C",15,"memory-enhancing brain implants","기억력을 향상시키는 뇌 임플란트",
 "뒤에 {similar to computer memory chips|컴퓨터 메모리 칩과 유사한}이 있고 앞에 {great potential|큰 잠재력}이 있어요. 기억을 담는 메모리 칩과 비슷한 뇌 임플란트는 기억력을 높이는 임플란트예요.",
 [("memory-erasing brain implants","기억을 지우는 뇌 임플란트","'큰 잠재력'이 있다고 할 만한 내용이 아니고, 메모리 칩의 역할(기억 보관)과도 달라요."),
  ("speed-enhancing leg implants","속도를 높이는 다리 임플란트","메모리 칩과 닮았다는 설명과 관계가 없어요."),
  ("voice-recording ear implants","목소리를 녹음하는 귀 임플란트","'뇌 임플란트'가 아니고, 메모리 칩과도 비슷하지 않아요."),
  ("muscle-building body implants","근육을 키우는 몸 임플란트","근육은 메모리 칩과 닮은 점이 없어요.")])

# ---------- D ----------
add("D",16,"upload and download","업로드하고 다운로드하다",
 "{using the digital cloud|디지털 클라우드를 사용하여}가 뒤에 있어요. 클라우드를 쓸 때 하는 일은 올리고 내려받는 것이에요. 또 {even|심지어}가 있어서 앞 내용(기억을 담고 키우기)보다 한 걸음 더 나가요.",
 [("delete and forget","삭제하고 잊어버리다","클라우드를 쓰는 이유가 아니고, 앞의 '기억을 향상'과도 반대예요."),
  ("hide and destroy","숨기고 파괴하다","디지털 클라우드의 쓰임새와 맞지 않아요."),
  ("weaken and erase","약하게 만들고 지우다","앞에서 기억을 '향상'한다고 했어요."),
  ("burn and throw away","태워서 버리다","기억을 소중하게 다루는 이 문장의 흐름에 맞지 않아요.")])
add("D",17,"back up our most valuable memories","가장 소중한 기억을 백업하다",
 "'소셜 미디어 피드처럼 보기, 좋았던 순간 회상하기, 공유하기'처럼 기억으로 할 수 있는 좋은 일을 나열하는 문장이에요. {and|그리고}로 이어지는 마지막 항목도 같은 방향이어야 해요.",
 [("lose our most valuable memories","가장 소중한 기억을 잃어버리다","좋은 일을 나열하는 중인데 '잃는다'는 나쁜 일이라 흐름이 깨져요."),
  ("hide our most valuable memories from others","가장 소중한 기억을 다른 사람에게서 숨기다","바로 앞 항목이 '다른 사람들과 공유하기'라서 서로 부딪쳐요."),
  ("sell our most valuable memories to hackers","가장 소중한 기억을 해커에게 팔다","장점을 나열하는 흐름에 맞지 않아요. 해커 이야기는 뒤에서 위험으로 나와요."),
  ("replace our most valuable memories with new ones","가장 소중한 기억을 새 기억으로 바꾸다","'소중한 기억을 지킨다'는 흐름과 반대로 사라지게 만들어요.")])
add("D",18,"revolutionize the way our brains work","우리 뇌가 작동하는 방식에 혁명을 일으키다",
 "{Finally|마지막으로}로 큰 변화를 마무리해요. 다음 문장이 {The role of the brain would shift|뇌의 역할이 바뀐다}여서 뇌의 작동 방식이 '완전히 달라진다'는 말이 와요.",
 [("make no difference to the way our brains work","뇌가 작동하는 방식에 아무 차이도 만들지 않다","다음 문장에서 뇌의 역할이 바뀐다고 하니 모순돼요."),
  ("preserve the way our brains work","뇌가 작동하는 방식을 그대로 보존하다","'그대로'라면 역할이 바뀐다는 다음 문장과 안 맞아요."),
  ("slow down the way our brains work","뇌가 작동하는 속도를 늦추다","장점을 말하는 흐름에서 '느려진다'는 맞지 않고, 역할이 '바뀐다'는 내용과도 달라요."),
  ("protect the way our brains work from AI","뇌가 작동하는 방식을 AI로부터 지키다","AI를 활용해 뇌를 바꾸는 이야기인데 AI에서 '지킨다'면 반대예요.")])
add("D",19,"processing the vast amounts of data provided by the implants","임플란트가 제공하는 방대한 양의 데이터를 처리하는 것",
 "{shift from A to B|A에서 B로 바뀐다}에서 A가 {learning and storing information|정보를 학습하고 저장하는 것}이에요. B는 A와 달라야 하고, 이어지는 문장이 {Instead of simply memorizing|단순히 암기하는 대신}으로 시작해요.",
 [("memorizing the vast amounts of data by heart","방대한 양의 데이터를 외우는 것","암기는 A(학습·저장)와 같은 일이라 '바뀐다'가 안 돼요."),
  ("storing the vast amounts of data in the brain forever","방대한 양의 데이터를 뇌에 영원히 저장하는 것","A의 '저장'과 같아서 바뀌는 게 아니에요."),
  ("ignoring the vast amounts of data provided by the implants","임플란트가 제공하는 방대한 양의 데이터를 무시하는 것","임플란트를 쓰는 이유가 없어져 버려요."),
  ("deleting the vast amounts of data provided by the implants","임플란트가 제공하는 방대한 양의 데이터를 삭제하는 것","뇌의 새 역할이 '지우기'라는 건 이어지는 문장(지식을 활용한다)과 안 맞아요.")])
add("D",20,"generate new ideas","새로운 아이디어를 창출하다",
 "{Instead of simply memorizing|단순히 암기하는 대신}의 뒤이므로 외우는 일이 아니라 머리를 쓰는 일이 와야 해요. {use our creativity|창의력을 발휘하고}가 바로 앞에 있어서 '새 아이디어를 만든다'가 이어져요.",
 [("memorize every fact by heart","모든 사실을 외우다","'암기하는 대신'이라고 했으니 암기가 다시 나오면 모순이에요."),
  ("copy other people's ideas","다른 사람들의 아이디어를 베끼다","'창의력'을 발휘한다는 바로 앞 말과 반대예요."),
  ("repeat the same old ideas","똑같은 옛 아이디어를 반복하다","창의력을 쓴다면서 반복한다고 하면 모순이에요."),
  ("depend on others for every idea","모든 아이디어를 남에게 의존하다","'우리의 창의력을 쓴다'는 말과 부딪쳐요.")])

# ---------- E ----------
add("E",21,"be addressed","해결되다",
 "{Before we can fully embrace|우리가 완전히 받아들이기 전에}라는 조건이 있어요. 받아들이기 전에 {tricky ethical issues|까다로운 윤리적 문제들}이 어떻게 되어야 하는지 생각해 보면 '해결되어야' 해요.",
 [("be ignored","무시되다","문제를 무시한 채로는 '완전히 받아들이기' 어려워요."),
  ("be celebrated","축하받다","'까다로운 문제'는 축하할 대상이 아니에요."),
  ("be hidden","숨겨지다","숨기면 해결되지 않아서 받아들일 준비가 안 돼요."),
  ("be copied","복사되다","문제는 복사하는 것이 아니라 풀어야 하는 것이에요.")])
add("E",22,"what it means to be human","인간이라는 존재가 무엇을 의미하는가",
 "{integration of AI technology with the human brain|AI 기술과 인간의 뇌의 통합}이 일으키는 우려예요. 다음 문장이 {identity, existence, and value as human beings|인간으로서의 정체성, 존재, 가치}를 말해서 '인간다움'에 관한 걱정임을 알 수 있어요.",
 [("how much it costs to be human","인간이 되는 데 비용이 얼마나 드는가","다음 문장은 비용이 아니라 정체성·존재 이야기예요."),
  ("what it means to be a machine","기계라는 존재가 무엇을 의미하는가","걱정거리는 '인간'의 정체성이에요. 기계가 아니에요."),
  ("how long humans can live with AI","인간이 AI와 함께 얼마나 오래 살 수 있는가","수명 이야기는 나오지 않고, 다음 문장은 정체성 이야기예요."),
  ("when AI will learn to feel emotions","AI가 언제 감정을 느끼게 될 것인가","AI의 변화가 아니라 인간의 정체성이 걱정의 중심이에요.")])
add("E",23,"central to our identity, existence, and value as human beings","인간으로서 우리의 정체성, 존재, 가치의 중심",
 "바로 다음 문장이 {However|그러나}로 시작해서 기술에 대한 지나친 의존이 문제라고 해요. 그 문제가 심각해지려면 앞 문장에서는 '뇌가 인간의 중요한 중심'이라는 말이 먼저 나와야 해요.",
 [("unrelated to our identity, existence, and value as human beings","인간으로서 우리의 정체성, 존재, 가치와 무관한","뇌가 무관하다면 AI와의 통합이 '인간이 무엇인지에 대한 우려'가 될 수 없어요."),
  ("less important than machines in human societies","인간 사회에서 기계보다 덜 중요한","앞 문장의 '인간다움에 대한 우려'와 맞지 않아요."),
  ("a simple tool for storing information","정보를 저장하는 단순한 도구","뇌를 단순 도구로 보면 정체성 혼란이라는 걱정이 생기지 않아요."),
  ("only a tool for physical movement","신체 움직임을 위한 도구일 뿐인","정체성·존재·가치 이야기와 관계가 없어요.")])
add("E",24,"delay our natural development","우리의 자연스러운 발달을 지연시키다",
 "{However|그러나}가 있어서 앞 문장의 뇌에 대한 좋은 이야기와 달리 걱정을 말해요. 뒤에 {create confusion|혼란을 일으킨다}가 이어지는 걸 보면 나쁜 영향이 와야 해요.",
 [("speed up our natural development","우리의 자연스러운 발달을 가속하다","뒤의 '혼란을 일으킨다'와 같은 부정적 흐름이 아니에요."),
  ("support our natural development","우리의 자연스러운 발달을 돕다","'지나친 의존(over-reliance)'이 도움이 된다는 말은 모순이에요."),
  ("protect our natural development","우리의 자연스러운 발달을 보호하다","'그러나(However)' 뒤에는 걱정이 와야 해서 '보호'는 맞지 않아요."),
  ("complete our natural development","우리의 자연스러운 발달을 완성하다","문제점을 말하는 문장이라서 좋은 결과는 안 어울려요.")])
add("E",26,"access personal data without permission","허락 없이 개인 정보에 접근하다",
 "{There's a risk that|~할 위험이 있다}라고 하고 앞 문장이 {Another critical issue is privacy|또 다른 중요한 문제는 프라이버시이다}예요. 프라이버시 위험이란 남이 허락 없이 개인 정보를 들여다보는 것이에요.",
 [("protect personal data with permission","허락을 받고 개인 정보를 보호하다","'위험'이라고 했는데 보호하는 일은 위험이 아니에요."),
  ("ask for personal data with permission","허락을 받고 개인 정보를 요청하다","허락을 받는다면 프라이버시 위험이 아니에요."),
  ("buy personal data from users with permission","허락을 받고 사용자에게서 개인 정보를 사다","'허락'이 있으면 위험이 되지 않아요."),
  ("return personal data after permission","허락 후 개인 정보를 돌려주다","돌려주는 것은 위험이 아니에요.")])

# ---------- F ----------
add("F",27,"controlled by hackers","해커에 의해 통제되는",
 "{This means|이는 ~라는 뜻이다}로 앞 문장(해커가 허락 없이 정보에 접근)이 더 나아간 결과를 말해요. 생각·감정·행동까지 해커 손에 들어갈 수 있다는 가장 큰 위험이 와요.",
 [("protected from hackers","해커로부터 보호받는","앞에서 말한 '위험'을 설명하는 문장인데 보호받는다면 위험이 아니에요."),
  ("ignored by hackers","해커에게 무시당하는","무시당하는 것은 위험이 아니에요."),
  ("freed from the implants","임플란트에서 벗어나는","해커가 나오는 위험 이야기와 이어지지 않아요."),
  ("replaced by the doctors' decisions","의사들의 결정으로 대체되는","해커 이야기 다음에 의사가 나올 근거가 없어요.")])
add("F",28,"lead to even greater social inequality","사회적 불평등을 더욱 심화시키다",
 "{additional risk|추가적인 위험}이라고 했으니 나쁜 결과가 와야 해요. {not available to all due to its high cost|높은 비용 때문에 모두에게 제공되지 않을 수 있다}는 이유가 뒤에 있어서 '불평등이 커진다'가 연결돼요.",
 [("lead to a more equal society","더 평등한 사회로 이어지다","위험을 말하는 문장이고, 비용 때문에 모두 못 쓴다는 이유와 반대예요."),
  ("reduce the gap between the rich and the poor","부자와 가난한 사람의 격차를 줄이다","높은 비용으로 못 쓰는 사람이 생기면 격차가 커져요."),
  ("solve social inequality completely","사회적 불평등을 완전히 해결하다","'위험(risk)' 문장이라 해결하는 말은 안 어울리고, 과장이기도 해요."),
  ("make all people equally wealthy","모든 사람을 똑같이 부유하게 만들다","비용 때문에 모두에게 제공되지 못한다는 뒤 내용과 맞지 않아요.")])
add("F",29,"those who cannot","그럴 수 없는 사람들",
 "{Such unequal access|이러한 불평등한 접근}이 주어예요. 임플란트 비용을 {can afford|감당할 수 있다} 사람과 짝이 되려면 감당하지 '못하는' 사람이 와야 해요.",
 [("those who invented them","그것을 발명한 사람들","'접근(access)'의 불평등을 말하는데, 발명자 이야기는 아니에요."),
  ("those who sell them","그것을 파는 사람들","살 수 있는 사람과 팔 수 있는 사람의 격차가 아니에요."),
  ("those who study them","그것을 연구하는 사람들","비용 때문에 생기는 격차와 상관이 없어요."),
  ("those who are afraid of them","그것을 두려워하는 사람들","접근하지 못해서 생기는 격차가 주제인데, 두려움은 별개 문제예요.")])
add("F",30,"overcome these challenges","이러한 난제를 극복하다",
 "앞에서 많은 윤리적 위험을 이야기했어요. {I hope that|나는 ~하기를 바란다}에 이어 그 위험들을 {careful consideration|신중한 고찰}으로 이겨 내길 바란다는 말이에요.",
 [("ignore these challenges","이러한 난제를 무시하다","신중히 생각하자는 흐름에서 무시한다는 말은 모순이에요."),
  ("increase these challenges","이러한 난제를 늘리다","바란다(hope)는 좋은 결과여야 해서 난제를 늘리는 것은 어긋나요."),
  ("celebrate these challenges","이러한 난제를 기념하다","난제는 기념하는 대상이 아니에요."),
  ("create these challenges","이러한 난제를 만들어 내다","이미 있는 문제를 푸는 이야기라서 만들어 낸다는 말은 맞지 않아요.")])
add("F",32,"before any kind of brain research is conducted","어떤 종류의 뇌 연구를 수행하기 전에",
 "{prior review process|사전 검토 절차}가 핵심 단서예요. '사전(prior)'이란 미리 한다는 뜻이니 연구를 하기 '전에'가 와야 해요.",
 [("after any kind of brain research is finished","어떤 종류의 뇌 연구가 끝난 뒤에","'사전 검토'는 일이 일어나기 전에 하는 것이라서 '끝난 뒤'와 모순이에요."),
  ("if any kind of brain research succeeds","어떤 종류의 뇌 연구가 성공한다면","성공 여부와 상관없이 미리 검토하자는 뜻이에요."),
  ("while the results are being sold","결과물이 팔리고 있는 동안","이미 팔리고 있다면 사전 검토가 될 수 없어요."),
  ("as soon as the research becomes famous","연구가 유명해지자마자","'사전'과 달리 연구가 진행된 뒤의 시점이에요.")])
add("F",33,"in accordance with ethical principles","윤리적 원칙에 따라",
 "앞 문장에서 윤리적 측면을 미리 철저히 평가하자고 했고, {ensure that|~하도록 보장하다}는 그 효과를 말해요. 윤리를 평가하는 목적은 발전이 윤리 원칙을 '따르게' 하는 거예요.",
 [("in spite of ethical principles","윤리적 원칙에도 불구하고","윤리를 평가하는 목적이 '윤리를 무시하는 발전'일 수는 없어요."),
  ("without any ethical principles","어떠한 윤리적 원칙도 없이","윤리적 측면을 평가하자는 앞 문장과 정반대예요."),
  ("at the expense of ethical principles","윤리적 원칙을 희생하면서","윤리 평가의 효과로는 모순이에요."),
  ("regardless of ethical principles","윤리적 원칙과 상관없이","윤리를 평가하는 이유가 사라져요.")])

# ---------- G (댓글) ----------
add("G",37,"according to their thoughts","그들의 생각에 따라",
 "{Wow, ... sound incredible!|와, ... 정말 놀랍다!}에 이어지는 감탄이에요. 팔을 잃은 사람의 의수가 '생각대로' 움직이는 것이 놀라운 이유예요.",
 [("against their thoughts","그들의 생각에 반해서","생각과 반대로 움직이는 의수는 놀라운 기술이 아니라 고장이에요."),
  ("regardless of their thoughts","그들의 생각과 상관없이","생각과 무관하게 움직이면 앞에서 감탄한 이유가 사라져요."),
  ("without any thoughts at all","아무 생각 없이도","'생각으로 움직인다'는 기술의 핵심과 반대예요."),
  ("only after doctors check their thoughts","의사들이 생각을 확인한 뒤에야","본문의 기술은 의사의 확인 없이 AI가 바로 신호를 전달하는 방식이에요.")])
add("G",38,"the privacy issues it might cause","그것이 일으킬 수 있는 프라이버시 문제",
 "{amazing, but|대단해 보이지만}에서 {but|그러나} 뒤에는 걱정이 와요. 다음 문장이 {privacy laws|개인 정보 보호법}이라서 걱정하는 내용은 프라이버시예요.",
 [("the benefits it might bring","그것이 가져올 수 있는 장점","'그러나(but)' 뒤에서 '걱정된다'고 했으니 장점은 안 맞아요."),
  ("the social inequality it might cause","그것이 일으킬 수 있는 사회적 불평등","다음 문장이 개인 정보 보호법 이야기라서 걱정의 내용이 프라이버시예요."),
  ("the jobs it might create","그것이 만들어 낼 수 있는 일자리","일자리 창출은 걱정거리가 아니에요."),
  ("the doctors it might replace","그것이 대체할 수 있는 의사들","다음 문장의 주제(개인 정보 보호)와 이어지지 않아요.")])
add("G",39,"to protect the personal information of individuals","개인의 개인 정보를 보호하기 위해",
 "앞 문장에서 프라이버시 문제가 걱정이라고 했어요. 그러니 {strictly enforce privacy laws|개인 정보 보호법을 엄격하게 시행하다}하는 목적은 정보를 '지키는' 것이에요.",
 [("to share the personal information of individuals","개인의 개인 정보를 공유하기 위해","프라이버시가 걱정이라면서 보호법을 시행해 정보를 공유한다는 건 모순이에요."),
  ("to sell the personal information of individuals","개인의 개인 정보를 팔기 위해","개인 정보 보호법의 목적과 정반대예요."),
  ("to collect the personal information of companies","회사의 개인 정보를 모으기 위해","걱정하는 건 개인의 정보 유출이고, 모으자는 말이 아니에요."),
  ("to open the personal information of individuals","개인의 개인 정보를 공개하기 위해","프라이버시를 걱정하는 사람의 주장과 맞지 않아요.")])
add("G",41,"address the concerns","그 우려들을 해결하다",
 "{Thank you all for sharing your thoughts|의견을 공유해 준 모든 분께 감사한다}에 이어 {my next post|나의 다음 글}에서 말하겠다는 내용이에요. 앞서 나온 걱정(프라이버시 등)을 '해결하는' 방법을 이야기하겠다는 뜻이에요.",
 [("ignore the concerns","우려를 무시하다","방법을 '더 이야기하겠다'고 했으니 무시하겠다는 말은 모순이에요."),
  ("avoid the comments","댓글을 피하다","감사 인사를 하며 다음 글에서 다루겠다는 흐름에 맞지 않아요."),
  ("multiply the concerns","우려를 늘리다","글쓴이가 걱정을 키우려는 것이 아니라 풀어 가려는 거예요."),
  ("hide the concerns","우려를 숨기다","의견을 공유해 준 데 감사하며 그 문제를 다루겠다는 내용과 반대예요.")])
