import os,json,re
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':900})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
    pg.goto('file:///tmp/claude-0/w/agentE/4/blank.html')
    # (e) simulation
    sim=pg.evaluate('''()=>{const T=window.__t;let res={};
      function run(){let q=[...Array(T.POOL).keys()],last=-1,seq=[],seen=new Set(),dup=0,cons=0;
        while(q.length){const k=T.pickPos(q,last);const id=q.splice(k,1)[0];if(seen.has(id))dup++;seen.add(id);if(T.ITEMS[id].seg===last)cons++;last=T.ITEMS[id].seg;seq.push(id)}return {n:seq.length,dup,cons,uniq:seen.size}}
      res.rounds=[];for(let i=0;i<300;i++)res.rounds.push(run());
      res.maxCons=Math.max(...res.rounds.map(r=>r.cons));res.avgCons=res.rounds.reduce((a,r)=>a+r.cons,0)/300;res.dup=res.rounds.reduce((a,r)=>a+r.dup,0);res.allN=res.rounds.every(r=>r.n===T.POOL&&r.uniq===T.POOL);delete res.rounds;return res}''')
    print('SIM',sim)
    dist=[0]*5;seen=[];rounds=0;wrong=0;right=0;ids=[]
    def cur_ids(): return None
    for step in range(200):
        if pg.locator('#go').count():
            txt=pg.locator('.sum').inner_text()
            print('SUM',txt.replace('\n',' | '))
            if '한 바퀴를 모두' in txt: rounds+=1
            if rounds==1: break
            pg.click('#go'); continue
        if pg.locator('#nx').count():
            pg.click('#nx'); continue
        btns=pg.locator('.ob')
        n=btns.count()
        assert n==5
        ptxt=pg.locator('#psg').inner_text()
        ids.append(ptxt)
        import random
        i=random.randrange(5)
        # check no sh scroll
        sw=pg.evaluate('document.documentElement.scrollWidth')
        assert sw<=420,sw
        btns.nth(i).click()
        ok=pg.locator('.ob.ok').count()==1 and pg.locator('.ex .res').count()==1
        assert ok
        pos=pg.evaluate("[...document.querySelectorAll('.ob')].findIndex(b=>b.classList.contains('ok'))")
        dist[pos]+=1
        if pg.locator('.ob.ng').count(): wrong+=1
        else: right+=1
        if step<2: print(pg.locator('#prog').inner_text()); 
    print('prog',pg.locator('#prog').inner_text() if pg.locator('#prog').count() else '')
    print('dist',dist,'right',right,'wrong',wrong,'questions',len(ids),'unique passages-blank?')
    print('errs',errs)
    # reload persist
    pg.screenshot(path='shot.png',full_page=True)
    b.close()
