import os
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':420,'height':900});e=[]
    pg.on('pageerror',lambda x:e.append(str(x)))
    pg.goto('file:///tmp/claude-0/w/agentE/4/blank.html')
    for i in range(8):
        pg.locator('.ob').nth(i%5).click();assert pg.evaluate('document.documentElement.scrollWidth')<=420
        pg.click('#nx')
    print(pg.inner_text('.sum').replace('\n',' '),e);b.close()
