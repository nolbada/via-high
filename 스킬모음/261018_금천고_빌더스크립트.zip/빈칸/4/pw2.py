import os
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':420,'height':900}); pg=ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///tmp/claude-0/w/agentE/4/blank.html')
    pg.locator('.ob').nth(0).click()
    pg.screenshot(path='shot1.png',full_page=True)
    pg.click('#nx'); print(pg.inner_text('#prog'))
    pg.reload(); print('after reload',pg.inner_text('#prog'))
    pg.click('#rs'); pg.click('#rs'); print('reset',pg.inner_text('#prog'))
    # no storage
    pg2=ctx.new_page(); pg2.add_init_script("Object.defineProperty(window,'localStorage',{get(){throw new Error('x')}})")
    pg2.on('pageerror',lambda e:errs.append(str(e)))
    pg2.goto('file:///tmp/claude-0/w/agentE/4/blank.html'); pg2.locator('.ob').nth(1).click(); pg2.click('#nx'); print('nostore',pg2.inner_text('#prog'))
    pg.emulate_media(color_scheme='dark'); pg.locator('.ob').nth(2).click(); pg.screenshot(path='shot2.png')
    print(errs); b.close()
