# -*- coding: utf-8 -*-
import json, re, html
import data, patch
S = json.load(open('/tmp/claude-0/w/sentences.json'))['4']
EN, KO, SEC = S['en'], S['ko'], S['sec']
src = open('/home/claude/via-high/h/geumcheon-gimal/4/vocab1.html', encoding='utf-8').read()
style = src[src.index('<style>')+7: src.index('</style>')]

def macro(t):
    return re.sub(r'\{([^{}|]+)\|([^{}]+)\}', lambda m: '<b class="en">%s</b>(%s)' % (html.escape(m.group(1)), html.escape(m.group(2))), t)

segs = []
for sid, title, a, b in data.SEGS:
    segs.append({'id': sid, 'title': title, 'sents': [EN[i] for i in range(a, b+1)], 'a': a})
segidx = {s['id']: n for n, s in enumerate(segs)}
items = []
for seg, idx, ans, ako, clue, ds in data.I:
    ds = patch.N[idx]
    s = segs[segidx[seg]]
    items.append({'seg': segidx[seg], 'si': idx - s['a'], 'ans': ans, 'ako': ako,
                  'clue': macro(clue), 'ds': [list(d) for d in ds],
                  'ko': KO[idx].replace('불 평등', '불평등')})
extra = """
.wrap{max-width:420px}
.bar{font-size:14px;line-height:1.5}
.bar .prog{flex:1 1 100%}
.bar button{margin-left:0}
.psg{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin:10px 0;font-size:16.5px;line-height:1.85;color:var(--ink)}
.psg .bl{display:inline-block;min-width:96px;border-bottom:2.5px solid var(--ans);color:transparent;user-select:none;line-height:1.2}
.psg mark{font-weight:800}
.segt{font-size:13px;font-weight:800;color:var(--pri)}
.opt .ob{display:block}
.ex .ol{list-style:none;margin:6px 0;padding:0}
.ex .ol li{margin:5px 0;font-size:15px;color:var(--sub)}
.ex .ol li.m{color:var(--pri);font-weight:700}
.ex b.en{color:var(--ink)}
.nx,.pb{display:block;width:100%;margin:14px 0 4px;padding:11px;border-radius:12px;border:1.5px solid var(--pri);background:var(--pri);color:var(--card);font:inherit;font-size:16.5px;font-weight:800}
.pb.sub{background:var(--card);color:var(--pri)}
.sum{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin:14px 0;text-align:center}
.sum h3{margin:0 0 6px;font-size:19px}
.sum p{margin:6px 0;color:var(--sub);font-size:16px}
img,svg{max-width:100%}
"""
tpl = open('/tmp/claude-0/w/agentE/4/tpl.html', encoding='utf-8').read()
out = tpl.replace('/*STYLE*/', style + extra).replace('/*DATA*/', json.dumps({'segs': segs, 'items': items}, ensure_ascii=False).replace('</', '<\\/'))
open('/tmp/claude-0/w/agentE/4/blank.html', 'w', encoding='utf-8').write(out)
print(len(items), len(out))
