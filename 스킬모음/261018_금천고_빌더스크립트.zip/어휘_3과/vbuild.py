# -*- coding: utf-8 -*-
import json,re,random,html,sys
sys.path.insert(0,'/tmp/claude-0/w')
from vdata import *
C=json.load(open('/tmp/claude-0/w/work/cards_final.json'))['3']
def clean(t):
    t=re.sub(r'[①-⑩]','',t); t=t.replace(' / ',' ').replace('/ ',' ')
    t=t.replace('heart- warming','heart-warming'); return re.sub(r'\s+',' ',t).strip()
EN=[clean(c[1]) for c in C]; KO=[clean(c[2]) for c in C]
E_=html.escape
rnd=random.Random(20261018)
def find(sent,form):
    m=re.search(re.escape(form),sent,re.I); return m
# ---- 유의어/반의어 items
items=[]   # dict(type,sent,...)
DROP_SYN={'conventional','unusual','limitless'}
for w,pos,mn,si,form,opts,why in SYN:
    if w in DROP_SYN: continue
    assert find(EN[si],form),(w,si,form,EN[si])
    items.append(dict(t='syn',w=w,pos=pos,mn=mn,si=si,form=form,opts=opts,why=why))
for w,pos,mn,si,form,opts,why in ANT:
    assert find(EN[si],form),(w,si,form,EN[si])
    items.append(dict(t='ant',w=w,pos=pos,mn=mn,si=si,form=form,opts=opts,why=why))
flips=[]
for si,o,n,why in FLIP:
    assert o in EN[si],(si,o,EN[si])
    flips.append(dict(t='flip',si=si,o=o,n=n,why=why))
allitems=sorted(items+flips,key=lambda d:(d['si'],d['t']))
N=len(allitems); bins=[[] for _ in range(4)]

SECR=[(0,4),(5,15),(16,28),(29,42)]
bins=[[d for d in allitems if a<=d['si']<=b2] for a,b2 in SECR]
for bi,B in enumerate(bins): print('구간',bi+1,len(B))
# ---- 다의어
P={p['w']:p for p in json.load(open('/tmp/claude-0/w/poly3.json'))}
def pq(w):
    p=P[w]; ms=[re.sub(r'\s+',' ',m).strip() for m in p['mean']]
    out=[]
    for k,(e,ko) in enumerate(p['ex']):
        out.append(dict(t='poly',w=w,mean=ms,ans=k if len(ms)==len(p['ex']) else None,e=e,ko=ko))
    return out
TWIST={0:[('value',3,'valued',0),('figure',15,'figure',0)],1:[('physical',17,'physical',0),('feature',26,'features',0)],2:[('subject',35,'subjects',0),('movement',37,'movement',0)],3:[('appreciate',41,'appreciating',0),('display',39,'displayed',0)]}
def spread(pl,seed):
    import random as _r
    r=_r.Random(seed)
    for gap in (3,2,1):
        for _ in range(5000):
            r.shuffle(pl); ok=True
            for i,q in enumerate(pl):
                for j in range(max(0,i-gap+1),i):
                    if pl[j]['w']==q['w']: ok=False;break
                if not ok: break
            if ok: return pl
    return pl
# ---- build questions per bin
def hl(sent,form):
    m=find(sent,form); return E_(sent[:m.start()])+'<u>'+E_(sent[m.start():m.end()])+'</u>'+E_(sent[m.end():])
def opt_html(label,gl): return E_(label)+(' <small>'+E_(gl)+'</small>' if gl else '')
def fix_ans_index(p,ex_idx):
    return ex_idx
out=[]
for bi in range(4):
    B=bins[bi]; qs=[]
    fl=[d for d in B if d['t']=='flip']; rnd.shuffle(fl)
    ftargets={d['si'] for d in fl}
    pool=[i for i in range(len(EN)) if i not in ftargets and len(EN[i].split())>=7]
    for d in fl:
        cand=[i for i in pool if SECR[bi][0]<=i<=SECR[bi][1]]
        ds=rnd.sample(cand if len(cand)>=3 else pool,3)
        flipped=EN[d['si']].replace(d['o'],d['n'],1)
        sl=[(flipped,d['si'],True)]+[(EN[i],i,False) for i in ds]; rnd.shuffle(sl)
        ans=[k for k,x in enumerate(sl) if x[2]][0]
        opts=[]
        for k,(s,i,f) in enumerate(sl):
            if f: s_h=E_(s).replace(E_(d['n']),'<mark>'+E_(d['n'])+'</mark>',1)
            else: s_h=E_(s)
            opts.append(dict(s=E_(s),sh=s_h,ko=E_(KO[i]),f=f))
        qs.append(dict(sec='trap',tag='단어 함정',stem='',ask='네 문장 중 <b>본문과 다르게 단어가 바뀐</b> 문장은?',opts=opts,ans=ans,
          why=E_(d['why']),orig=E_(d['o']),new=E_(d['n']),ko=E_(KO[d['si']])))
    sa=[d for d in B if d['t'] in('syn','ant')]; rnd.shuffle(sa)
    for d in sa:
        opts=[o.split('|') for o in d['opts']]; order=list(range(4)); rnd.shuffle(order)
        o2=[opts[i] for i in order]; ans=order.index(0)
        ask='뜻이 가장 가까운 것은?' if d['t']=='syn' else '뜻이 반대인 것은?'
        qs.append(dict(sec='syn',tag='유의어' if d['t']=='syn' else '반의어',stem=hl(EN[d['si']],d['form']),ask='밑줄 친 부분과 '+ask,
          opts=[opt_html(a,b) for a,b in o2],ans=ans,
          why=E_(d['why']),ko=E_(KO[d['si']]),word='<b>%s</b> %s %s'%(E_(d['w']),E_(d['pos']),E_(d['mn']))))
    ws=POLY_BINS[bi]; pl=[]
    for w in ws: pl+=pq(w)
    for (tw_,si_,form_,k_) in TWIST[bi]:
        ms_=[re.sub(r'\s+',' ',m).strip() for m in P[tw_]['mean']]
        pl.append(dict(t='poly',w=tw_,mean=ms_,ans=k_,e=EN[si_],ko=KO[si_],form=form_))
    pl=spread(pl,7700+bi)
    for q in pl:
        ms=q['mean']; 
        qs.append(dict(sec='poly',tag='다의어',stem=hl(q['e'],q['form']) if q.get('form') else (hl(q['e'],q['w']) if find(q['e'],q['w']) else E_(q['e'])),
          ask='밑줄 친 <b>%s</b>의 뜻으로 알맞은 것은?'%E_(q['w']),opts=[E_(m) for m in ms],ans=q['ans'],
          why='',ko=E_(q['ko']),word=q['w'],all=[E_(m) for m in ms]))
    out.append(qs)
json.dump(out,open('/tmp/claude-0/w/out/q.json','w'),ensure_ascii=False)
for bi,q in enumerate(out):
    print(bi+1,len(q),{s:sum(1 for x in q if x['sec']==s) for s in('syn','trap','poly')})
