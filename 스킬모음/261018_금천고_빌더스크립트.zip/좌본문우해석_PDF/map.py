MAP=[
["Shadows","exhibit","docent"],["challenges","gave up on"],["unique","highly"],["examine"],["slavery","cotton"],
["Civil War","wages","racial discrimination"],["moved","factory"],["experiences","drawing"],["Mean"],["slaves","hunt"],
["pieces"],["In contrast","observed","African Americans","portrays"],["freedom","complex","captured"],["folk","figure"],
["heart-warming","known for","renowned"],["distorted","suffered from"],["mobility","drop out of school"],["living"],["passed away"],["marrying"],
["landscapes","depicted"],["vivid","oil paints","original","generating"],["limitations","confined","limitless"],["maple leaves","decorated"],
["features","fairy tale","quality"],["gradually","popularity","inspired"],["iconic"],["exhibition","take a look at"],
["common","notice","female"],["private","attend"],["unusual"],["encouragement","take advantage of"],["household duties","objecting to"],
["differed from","still life","subjects"],["In contrast","Sewing","active","participants","showcased"],
["skillfully","rich","Impressionist movement","contributing to"],["reflection","stunningly"],["conventional","exceptional","displayed"],
["explanations","appreciating","aided"],["exhibition","further"],["curators","encountered"],["roles","responsibilities"],
["featured","artworks","provide"],["have a passion for","knowledge"],["carry out","carry out","presentation","specialized"],
["organize","professionals"],["theme","determine","audience","captivates","engaging","arrange"],
["employed","related field","advanced degrees","possess"],["distinct","enriching"]]
KO9="Traylor는 개가 농장에서 ______________를 감시하고 ______________는 데 자주 사용되었기 때문에 개에 대한 두려움이 컸습니다."
