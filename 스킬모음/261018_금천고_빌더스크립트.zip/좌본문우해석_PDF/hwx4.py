import re,json,shutil,os,zipfile,sys
SRC='/tmp/claude-0/work/h4u'
ws=json.load(open('ws4.json'));cards=json.load(open('cards_final.json'))['4']
al={str(i):[i] for i in range(11)}
for i in range(14,45): al[str(i)]=[i-3]
def cen(c): return re.sub(r'\s*[①-⑩].*$','',c[1])
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
KO9=''
OV={18:['과 유사하','잠재력'],17:['입력하','가능하'],22:['방대한','처리하는 것','바뀔'],36:['원칙에 따라','발전하','보장할']}
EXTRA={
45:(["Artificial limbs, designed to replace natural arms or legs,","have a rich history","dating back to ancient times"],"인공 수족은 자연적인 팔이나 다리를 대체하기 위해 고안된 / 유구한 역사를 지니고 있다 / 고대로 거슬러 올라가는",['대체하','인공','수족','고대로 거슬러 올라가']),
46:(["An interesting example","is the discovery of a wooden toe","on an Egyptian mummy","from around 950 B.C."],"흥미로운 예시는 / 나무로 된 발가락의 발견이다 / 이집트 미라에서 / 기원전 950년경의",['미라','발가락']),
47:(["In the 16th century,","a German knight","known as Götz of the Iron Hand","made himself an iron arm","with spring-operated fingers","so that he could hold his weapon more tightly"],"16세기에 / 독일 기사는 / '철의 손 괴츠'로 알려진 / 철제 팔을 직접 만들었다 / 스프링으로 작동하는 손가락이 달린 / 무기를 더 단단히 잡을 수 있도록",['기사','단단히','스프링으로 작동하는']),
48:(["During the World Wars of the 20th century,","the demand for artificial limbs increased significantly","as injured soldiers sought replacements,","resulting in remarkable advances in artificial limb technology"],"20세기 세계 대전 중 / 인공 수족에 대한 수요가 크게 증가했다 / 부상당한 군인들이 대체품을 찾으면서 / 그 결과 인공 수족 기술이 눈부시게 발전했다",['부상당한','대체품','그 결과','눈부시','발전했다']),
49:(["Bert Shepard,","a soldier who had lost his leg during World War II,","made an impressive return to Major League Baseball in 1945","with an artificial leg,","showing the potential of artificial limb technology"],"Bert Shepard는 / 제2차 세계 대전 중 다리를 잃은 군인으로서 / 1945년에 메이저리그로 인상적으로 복귀했다 / 의족을 착용하고 / 인공 수족 기술의 잠재력을 보여 주며",['인상적']),
50:(["Today, artificial limbs are advancing even further","thanks to the integration of cutting-edge technologies","such as robotics and artificial intelligence (AI)"],"오늘날 인공 수족은 훨씬 더 발전하고 있다 / 첨단 기술의 통합 덕분에 / 로봇 공학 및 인공지능(AI)과 같은",['첨단','통합','발전하고 있']),
51:(["This integration enables users","to make complex movements","and control their artificial limbs with their thoughts"],"이 통합은 사용자들이 할 수 있게 한다 / 복잡한 동작을 하고 / 생각으로 인공 수족을 제어하는 것을",['복잡한','제어하']),
52:(["These advancements empower people with limb loss,","giving them the freedom and opportunity","to lead better lives"],"이러한 발전은 사지를 잃은 사람들에게 힘을 실어주며 / 그들에게 자유와 기회를 제공한다 / 더 나은 삶을 살 수 있는",['힘을 실어주','자유','기회']),
}
def an(s): return re.sub(r'[^A-Za-z0-9]','',s).lower()
def chunks_for(i):
    if i in EXTRA: return EXTRA[i][0],EXTRA[i][1]
    en=[];ko=[]
    for j in al[str(i)]:
        en+= [x.strip() for x in cen(cards[j]).split(' / ')]
        ko+= [x.strip() for x in cards[j][2].split(' / ')]
    return en,' / '.join(ko)
FALL=[]
def blank_ko(ko,answers):
    spans=[]
    for a in answers:
        ctx,ans=(a.split('|')+[None])[:2] if '|' in a else (None,a)
        if ctx: 
            k=ko.find(ctx+ans); st=k+len(ctx) if k>=0 else -1
        else:
            st=ko.find(ans)
            k2=ans
            while st<0 and len(k2)>2:
                k2=k2[:-1]; st=ko.find(k2)
            if st>=0: ans=k2; FALL.append((a,ans))
        assert st>=0,(a,ko)
        # avoid overlap: if overlaps, find next
        while any(st<e and st+len(ans)>s for s,e,_ in spans):
            st=ko.find(ans,st+1); assert st>=0,(a,ko)
        spans.append((st,st+len(ans),ans))
    spans.sort()
    out=ko;
    for s,e,a in reversed(spans): out=out[:s]+'______________'+out[e:]
    return out,[a for _,_,a in spans]
def process(xml,i,parts_old,kor_raw):
    en,ko=chunks_for(i)
    answers=OV.get(i, EXTRA[i][2] if i in EXTRA else parts_old)
    newko,order=blank_ko(ko,answers)
    # locate endnote text
    old_note=' / '.join(parts_old)
    mm=re.search(r'<hp:t>\s*'+re.escape(old_note)+r'\s*</hp:t>',xml); assert mm,('note',i,old_note); k=mm.start()
    pstyle='<hp:p id="2147483648" paraPrIDRef="%s" styleIDRef="2"'
    e0=xml.rfind('<hp:ctrl><hp:endNote',0,k)
    c1=[m.start() for m in re.finditer(r'<hp:p id="\d+" paraPrIDRef="(?:15|13|14)" styleIDRef="2"',xml[:k])]
    if not c1: c1=[m.start() for m in re.finditer(r'<hp:p id="\d+" paraPrIDRef="2" styleIDRef="3"',xml[:e0])]
    ps=max(c1)
    ee=xml.find('</hp:endNote></hp:ctrl>',k)+len('</hp:endNote></hp:ctrl>')
    depth=0;pe=None
    for m in re.finditer(r'<hp:p |</hp:p>',xml[ps:]):
        depth+= 1 if m.group(0)=='<hp:p ' else -1
        if depth==0: pe=ps+m.end();break
    para=xml[ps:pe]
    HB=[]
    def hmask(m):
        HB.append(m.group(0)); return '\x02%d\x03'%(len(HB)-1)
    para=re.sub(r'<hp:(header|footer)\b.*?</hp:\1>',hmask,para,flags=re.S)
    ec=para.find('<hp:ctrl><hp:endNote'); eng=para[:ec]
    pos=[];n=0;L=len(eng)
    while n<L:
        c=eng[n]
        if c=='<': n=eng.find('>',n)+1; continue
        if c=='&': n=eng.find(';',n)+1; continue
        if c.isascii() and c.isalnum(): pos.append(n)
        n+=1
    A=''.join(eng[p].lower() for p in pos)
    cum=[];tot=0
    for c in en: tot+=len(an(c)); cum.append(tot)
    c0=an(en[0]); st=A.find(c0[:14]); assert st>=0,('start',i)
    assert A[st:st+tot]==''.join(an(c) for c in en),('eng mismatch',i,A[st:st+tot][:60])
    ins=[]
    for ci in range(len(en)-1):
        idx=st+cum[ci]
        if idx>=len(pos): break
        q=pos[idx]
        if en[ci+1][:1] in '—–-':
            d=eng.rfind('—',0,q+1)
            if d>=0: q=d
        ins.append(q)
    for q in sorted(ins,reverse=True):
        while eng[:q].endswith('<hp:t>'):
            e=eng.rfind('</hp:t>',0,q)
            if e<0: break
            q=e
        j=q
        while j>0 and eng[j-1]==' ': j-=1
        eng=eng[:j]+' / '+eng[q:]
    eng=re.sub(r' +((?:<[^>]+>)*) / ',lambda m:m.group(1)+' / ',eng)
    rest=para[ec:]
    # korean: nodes after the endnote
    rs=rest.find('</hp:endNote></hp:ctrl>')+len('</hp:endNote></hp:ctrl>')
    head_r,tail_r=rest[:rs],rest[rs:]
    first=[True]
    def kn(m):
        inner=m.group(1)
        if not re.search(r'[가-힣_]',inner): return m.group(0)
        if first[0]:
            first[0]=False
            segs=inner.split('<hp:lineBreak/>')
            segs[-1]=esc(newko)
            return '<hp:t>'+'<hp:lineBreak/>'.join(segs)+'</hp:t>'
        return '<hp:t/>'
    tail_r=re.sub(r'<hp:t>(.*?)</hp:t>',kn,tail_r,flags=re.S)
    assert not first[0],('nokor',i)
    rest=head_r+tail_r
    pat=re.compile(r'<hp:t>\s*'+re.escape(old_note)+r'\s*</hp:t>')
    assert pat.search(rest),('oldnote',i,old_note)
    rest=pat.sub(lambda m:'<hp:t> '+esc(' / '.join(order))+'</hp:t>',rest,count=1)
    newp=eng+rest
    # drop stale outer line layout caches (keep those inside the endnote)
    head=newp[:newp.find('<hp:ctrl><hp:endNote')]
    head=re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>','',head,flags=re.S)
    tail_start=newp.rfind('</hp:endNote></hp:ctrl>')
    tail=newp[tail_start:]
    tail=re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>','',tail,flags=re.S)
    newp=head+newp[len(head):tail_start]+tail
    newp=re.sub(r'\x02(\d+)\x03',lambda m:HB[int(m.group(1))],newp)
    return xml[:ps]+newp+xml[pe:], ko, newko

SKIP={11,12,13}
SECS=['section0.xml','section1.xml','section2.xml']
X={s:open(f'{SRC}/Contents/{s}',encoding='utf8').read() for s in SECS}
for i in range(len(ws)):
    if i in SKIP: continue
    t=ws[i]; m=re.search(r'\x00(.*?)\x01',t,flags=re.S)
    parts=[x.strip() for x in m.group(1).split('(한글)')[-1].split('/')]
    kor_raw=t[m.end():]
    old_note=' / '.join(parts)
    sec=next(s for s in SECS if re.search(r'<hp:t>\s*'+re.escape(old_note)+r'\s*</hp:t>',X[s]))
    X[sec],ko,newko=process(X[sec],i,parts,kor_raw)
    print(i,sec,newko)
DST='/tmp/claude-0/hwpx4_new'
if os.path.exists(DST): shutil.rmtree(DST)
shutil.copytree(SRC,DST)
for s,x in X.items(): open(f'{DST}/Contents/{s}','w',encoding='utf8').write(x)

print('FALLBACKS',FALL)
