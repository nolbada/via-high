import pickle,subprocess,pdfplumber,sys
CSS,PG=pickle.load(open('pages.pkl','rb'))
def render(h,p,out):
    open('t.html','w').write('<!doctype html><html><head><meta charset="utf-8"><style>:root{--p:%spx}%s</style></head><body>%s</body></html>'%(p,CSS,h))
    subprocess.run(['wkhtmltopdf','-q','--page-size','A4','-T','16mm','-B','7mm','-L','19.5mm','-R','19.5mm','t.html',out],check=False)
def bottom(out):
    with pdfplumber.open(out) as pdf:
        if len(pdf.pages)!=1: return None
        w=pdf.pages[0].extract_words()
        return max(x['bottom'] for x in w)/72*25.4
for k in ('3','4'):
    files=[]
    for i,h in enumerate(PG[k]):
        f=f'pp_{k}_{i}.pdf'
        if k=='4' and i==4:
            render(h,18,f)
        else:
            lo,hi=4,40
            while lo<hi:
                m=(lo+hi+1)//2; render(h,m,f); b=bottom(f)
                if b is not None and b<=281: lo=m
                else: hi=m-1
            render(h,lo,f)
        print(k,i,bottom(f),flush=True); files.append(f)
    subprocess.run(['pdfunite']+files+[f'n{k}.pdf'],check=True)
