import re,json,shutil,os,sys,html
sys.path.insert(0,'/tmp/claude-0/work')
src=open('hwx4.py',encoding='utf8').read()
# reuse data/helpers from hwx.py (everything before the main loop)
exec(src[:src.index('def process(')])
SRC2='/tmp/claude-0/work/h4e'
def esc2(s): return esc(s)
def build_ko_runs(ko,answers):
    # highlight spans (same substrings as the blanks in the 우리말 sheet)
    _,order=blank_ko(ko,answers)
    spans=[]
    for a in answers:
        ctx,ans=(a.split('|')+[None])[:2] if '|' in a else (None,a)
        if ctx:
            k=ko.find(ctx+ans); st=k+len(ctx)
        else: st=ko.find(ans)
        while any(st<e and st+len(ans)>s0 for s0,e in spans): st=ko.find(ans,st+1)
        spans.append((st,st+len(ans)))
    spans.sort()
    runs=[];p=0
    for s0,e in spans:
        if s0>p: runs.append((6,ko[p:s0]))
        runs.append((27,ko[s0:e])); p=e
    if p<len(ko): runs.append((6,ko[p:]))
    return ''.join(f'<hp:run charPrIDRef="{c}"><hp:t>{esc2(t)}</hp:t></hp:run>' for c,t in runs)
def an2(s): return re.sub(r'[^A-Za-z0-9]','',s).lower()
def insert_slashes(after,full,en_chunks,i):
    # visible chars map
    vis=[];n=0;L=len(after);lb=-1
    while n<L:
        c=after[n]
        if c=='<':
            e=after.find('>',n)+1
            if after.startswith('<hp:lineBreak/>',n): lb=len(vis)
            n=e; continue
        if c=='&': e=after.find(';',n)+1; vis.append((n,after[n:e])); n=e; continue
        vis.append((n,c)); n+=1
    V=''.join(ch for _,ch in vis)
    Ven=V[lb:]; off=lb
    toks=[(m.start()+off,m.end()+off) for m in re.finditer(r'\S+',Ven)]
    F=full.split()
    assert len(toks)==len(F),('tok',i,len(toks),len(F),Ven[:80])
    cum=[];tot=0
    for c in en_chunks: tot+=len(an2(c)); cum.append(tot)
    ins=[];acc=0;ci=0
    for (ts,te),ft in zip(toks,F):
        nn=len(an2(ft))
        if ci<len(cum)-1 and acc<cum[ci]<acc+nn:
            d=V.find('—',ts,te); assert d>=0,('mid',i,ft)
            ins.append(vis[d][0]); acc+=nn; ci+=1; continue
        acc+=nn
        if ci<len(cum)-1 and acc==cum[ci]:
            if te<len(V) and V[te]==' ': ins.append(vis[te][0]+1)   # after the space
            else: assert False,('nospace',i,ft)
            ci+=1
    assert ci==len(cum)-1,('bnd',i,ci,len(cum))
    for p in sorted(ins,reverse=True):
        # dash case inserts before char: add " / " ; space case inserts "/ "
        if after[p-1:p]==' ' : after=after[:p]+'/ '+after[p:]
        else: after=after[:p]+' / '+after[p:]
    return after
def wsfull(i):
    t=ws[i]; m=re.search(r'\x00(.*?)\x01',t,flags=re.S)
    en=re.sub(r'\*\*','',t[:m.start()])
    en=en.split('\n')[-1] if '\n' in en.strip() else en
    return en.strip()
def run(secname,idx_range):
    xml=open(f'{SRC2}/Contents/{secname}',encoding='utf8').read()
    paras=[m for m in re.finditer(r'<hp:p id="\d+" paraPrIDRef="(?:14|16)" styleIDRef="2"',xml)]
    IDX=list(range(0,11))+[None]*4+list(range(14,45))+list(range(45,53))
    assert len(paras)==len(IDX),(len(paras),len(IDX))
    res=xml;
    # process from last to first to keep offsets
    items=[(m,i) for m,i in zip(paras,IDX) if i is not None]
    for m,i in reversed(items):
        ps=m.start()
        depth=0;pe=None
        for mm in re.finditer(r'<hp:p |</hp:p>',res[ps:]):
            depth+=1 if mm.group(0)=='<hp:p ' else -1
            if depth==0: pe=ps+mm.end();break
        para=res[ps:pe]
        HB=[]
        def hm(mm): HB.append(mm.group(0)); return '\x02%d\x03'%(len(HB)-1)
        para_m=re.sub(r'<hp:(header|footer)\b.*?</hp:\1>',hm,para,flags=re.S)
        ec=para_m.find('<hp:ctrl><hp:endNote'); assert ec>0,i
        # end of endNote ctrl
        ee=para_m.find('</hp:endNote></hp:ctrl>')+len('</hp:endNote></hp:ctrl>')
        # final run start before ec
        lr=para_m.rfind('<hp:run ',0,ec)
        final_run_head=para_m[lr:ec]
        mt=re.fullmatch(r'<hp:run charPrIDRef="\d+">(<hp:t>[^<]*</hp:t>)?',final_run_head); assert mt,(i,final_run_head[:80])
        openp=para_m[:para_m.index('>')+1]
        pre=para_m[len(openp):lr]
        # keep leading no-Hangul runs; preserve ctrl blocks inside the replaced part
        runs=re.findall(r'<hp:run [^>]*?(?:/>|>.*?</hp:run>)',pre,flags=re.S)
        assert ''.join(runs)==pre,(i,'runs')
        keep=[];ctrls=[];hit=False
        for r in runs:
            vis=re.sub(r'<[^>]+>','',r)
            if not hit and not re.search(r'[가-힣]',vis) and not re.search(r'\x02',r):
                keep.append(r); continue
            hit=True
            ctrls+=re.findall(r'<hp:ctrl>(?:(?!<hp:ctrl>).)*?</hp:ctrl>|<hp:ctrl>\x02\d+\x03</hp:ctrl>',r,flags=re.S)
        # korean text
        en,ko=chunks_for(i)
        answers=OV.get(i, EXTRA[i][2] if i in EXTRA else None)
        if answers is None:
            mm_=re.search(r'\x00(.*?)\x01',ws[i],flags=re.S)
            answers=[x.strip() for x in mm_.group(1).split('(한글)')[-1].split('/')]
        kruns=build_ko_runs(ko,answers)
        ctrl_run=('<hp:run charPrIDRef="6">'+''.join(ctrls)+'</hp:run>') if ctrls else ''
        # english part (after endnote ctrl): single hp:t
        after=para_m[ee:]
        full=wsfull(i) if i not in EXTRA else ' '.join(EXTRA[i][0])
        newafter=insert_slashes(after,html.unescape(full),en,i)
        endnote=para_m[ec:ee]
        newpara=openp+''.join(keep)+ctrl_run+kruns+'<hp:run charPrIDRef="6"><hp:t/>'+endnote+newafter
        newpara=re.sub(r'\x02(\d+)\x03',lambda x:HB[int(x.group(1))],newpara)
        # drop stale layout cache of the outer paragraph (not inside endnote/header)
        mask2=[]
        def m2(x): mask2.append(x.group(0)); return '\x04%d\x05'%(len(mask2)-1)
        tmp=re.sub(r'<hp:(?:endNote|header|footer)\b.*?</hp:(?:endNote|header|footer)>',m2,newpara,flags=re.S)
        tmp=re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>','',tmp,flags=re.S)
        newpara=re.sub(r'\x04(\d+)\x05',lambda x:mask2[int(x.group(1))],tmp)
        res=res[:ps]+newpara+res[pe:]
        print(i,re.sub(r'<[^>]+>','|',newpara.split('<hp:ctrl><hp:endNote')[0]).replace('||','')[:120],'##',re.sub(r'<[^>]+>','',newafter)[:110])
    return res
out0=run('section0.xml',None)
DST='/tmp/claude-0/hwpx4E_new'
if os.path.exists(DST): shutil.rmtree(DST)
shutil.copytree(SRC2,DST,ignore=shutil.ignore_patterns('a.zip'))
open(DST+'/Contents/section0.xml','w',encoding='utf8').write(out0)
