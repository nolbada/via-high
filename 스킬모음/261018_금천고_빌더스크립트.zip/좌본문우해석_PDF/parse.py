import re,json
res=[]
for f in ['section0.xml','section1.xml']:
    s=open(f,encoding='utf8').read()
    s=s.replace('<hp:lineBreak/>','\n')
    # mark endnotes inline
    def en(m):
        t=''.join(re.findall(r'<hp:t>(.*?)</hp:t>',m.group(0),flags=re.S)).strip()
        return '<hp:t>\x00'+t+'\x01</hp:t>'
    s=re.sub(r'<hp:ctrl><hp:endNote.*?</hp:endNote></hp:ctrl>',en,s,flags=re.S)
    for p in re.findall(r'<hp:p [^>]*>(.*?)</hp:p>',s,flags=re.S):
        if 'charPrIDRef="29"' not in p and '______' not in p: continue
        txt=''
        for c,r in re.findall(r'<hp:run charPrIDRef="(\d+)">(.*?)</hp:run>',p,flags=re.S):
            t=''.join(re.findall(r'<hp:t>(.*?)</hp:t>',r,flags=re.S))
            t=re.sub(r'<[^>]+>','',t)
            if c=='29' and t.strip(): t='**'+t+'**'
            txt+=t
        res.append(txt)
json.dump(res,open('/tmp/claude-0/work/ws.json','w'),ensure_ascii=False,indent=0)
for i,t in enumerate(res): print(i,t.replace('\x00','⟦').replace('\x01','⟧'))
