import json,re,html,subprocess,sys,os
H=html.escape
cards=json.load(open('cards_final.json'));lay=json.load(open('layout.json'));nat=json.load(open('nat.json'))
META={'3':("미래엔(김) 공통영어2 · 3과 본문","3과 The True Art Lovers · From Shadows to Spotlights","Welcome to the Dream Art Gallery"),
      '4':("미래엔(김) 공통영어2 · 4과 본문","4과 Will AI-Powered Neural Implants Make Us Super-Humans?","AI Meets Neural Implants")}
CSS='''
@page{size:A4}
*{box-sizing:border-box}
body{margin:0;font-family:'Noto Sans CJK KR','Noto Sans KR',sans-serif;color:#222;font-size:13px}
.hdr{display:flex;justify-content:flex-end;min-height:34px;border-bottom:2px solid #1e4b9c;padding-bottom:6px;font-size:14px;font-weight:700;color:#1e4b9c}
.ttl{display:flex;margin:14px 0 14px 0;align-items:stretch}
.badge{width:30px;height:30px;background:#1e4b9c;color:#fff;font-weight:700;text-align:center;line-height:30px;margin:6px 22px 0 0;font-size:15px}
.tbox{flex:1;border-left:3px solid #1e4b9c;background:#eef3fb;padding:5px 10px}
.tbox .a{font-size:13px;font-weight:700}.tbox .b{font-size:11px;color:#444}
.sec{font-size:12.5px;font-weight:700;color:#1e4b9c;border-bottom:1px solid #1e4b9c;margin:12px 0 4px;padding-bottom:2px}
table{width:100%;border-collapse:collapse}
td{vertical-align:top;padding:0}
td.e{width:73%;font-size:17px;line-height:1.55;padding:7px 14px 7px 0}
td.k{width:27%;font-size:12.5px;line-height:1.5;padding:9px 0 7px 0}
.n{display:inline-block;width:26px;font-weight:700;color:#1e4b9c}
.hang{padding-left:26px;text-indent:-26px}
.k .n{width:20px}.k .hang{padding-left:20px;text-indent:-20px}
.boxes{display:flex;gap:7px;margin:14px 0 8px}
.boxes div{flex:1;border:1px solid #999;height:20px;font-size:10px;color:#555;padding:2px 3px}
.nh{font-size:12.5px;font-weight:700;color:#1e4b9c;margin:6px 0 3px}
.nt{font-size:13px;line-height:1.6;text-align:justify}
.nt b{color:#1e4b9c}
.memo{border-top:1px dashed #999;margin-top:8px;font-size:9px;color:#888;padding-top:2px;height:90px}
.pg{page-break-after:always}
'''
def fixen(s): return s.replace('heart- warming','heart-warming')
def page_html(k,pi,items,sents,natural):
    meta=META[k]
    rows='';cur=None;idx=0
    out=[f'<div class="hdr">{H(meta[0])}</div>',
         f'<div class="ttl"><div class="badge">{pi+1}</div><div class="tbox"><div class="a">{H(meta[1])}</div><div class="b">{H(meta[2])}</div></div></div>']
    tbl=None
    for kind,v in items:
        if kind=='s':
            if tbl is not None: out.append('</table>')
            tbl=None
            # find section label from next sentence
            sec,en,ko,num=sents[idx]
            out.append(f'<div class="sec">{H(sec)}</div>')
        else:
            sec,en,ko,num=sents[idx]
            assert num==v,(k,pi,num,v)
            if tbl is None:
                out.append('<table>'); tbl=True
            out.append(f'<tr><td class="e"><div class="hang"><span class="n">{num}.</span>{H(fixen(en))}</div></td><td class="k"><div class="hang"><span class="n">{num}.</span>{H(ko)}</div></td></tr>')
            idx+=1
    if tbl is not None: out.append('</table>')
    nt=H(natural)
    nt=re.sub(r'\[([①-⑩][^\]]*)\]',lambda m:'<b>['+m.group(1)+']</b>',nt)
    nt=re.sub(r'(?<![0-9])(\d{1,2})\. (?=[가-힣A-Z〈])',lambda m:f'<b>{m.group(1)}.</b> ',nt)
    out.append('<div class="boxes">'+''.join(f'<div>{i}회독</div>' for i in range(1,6))+'</div>')
    out.append(f'<div class="nh">자연스러운 해석</div><div class="nt">{nt}</div><div class="memo">memo</div>')
    return '<div class="pg">'+''.join(out)+'</div>'
def build(k):
    # sentences with per-section numbering
    secs={};order=[]
    for sec,en,ko in cards[k]:
        s=re.search(r'([①-⑩])',sec)
    # card[0] is the section label that applies only to first card of section; later cards carry section label of...? derive from layout
    sents=[];i=0
    # layout tells sentence counts per section; assign labels from cards' first-of-section markers
    labels=[]
    for c in cards[k]:
        m=re.search(r'\s*([①-⑩].*)$',c[1])
        # c[0] is section label of this card
    # section label of each card = c[0]
    cnt={}
    for c in cards[k]:
        cnt[c[0]]=cnt.get(c[0],0)+1
        en=re.sub(r'\s*[①-⑩].*$','',c[1])
        sents.append((c[0],en,c[2],cnt[c[0]]))
    pages=[];p=0
    for pi,items in enumerate(lay[k]):
        n=sum(1 for a,b in items if a=='n')
        pages.append(page_html(k,pi,items,sents[p:p+n],nat[k][pi])); p+=n
    assert p==len(sents),(k,p,len(sents))
    return pages
for k in ('3','4'):
    pages=build(k)
    # section header logic: items with 's' use next sentence's section label
    doc='<!doctype html><html><head><meta charset="utf-8"><style>'+CSS+'</style></head><body>'+''.join(pages)+'</body></html>'
    open(f'/tmp/claude-0/work/g{k}.html','w',encoding='utf8').write(doc)
    print(k,len(pages))
