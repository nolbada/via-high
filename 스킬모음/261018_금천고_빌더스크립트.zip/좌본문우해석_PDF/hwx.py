import re,json,shutil,os,zipfile,sys
SRC='/tmp/claude-0/hwpx'
ws=json.load(open('ws.json'));cards=json.load(open('cards_final.json'))['3'];al=json.load(open('align.json'))
def cen(c): return re.sub(r'\s*[①-⑩].*$','',c[1])
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
KO9="Traylor는 개가 농장에서 ______________를 감시하고 ______________는 데 자주 사용되었기 때문에 개에 대한 두려움이 컸습니다."
OV={1:['포기하','역경'],6:['이주했','공장'],11:['이와 대조적으로','관찰한','아프리카계 미국인','묘사한다'],12:['자유','복잡한','포착했다'],
14:['마음이 따뜻해지는','으로 알려진','유명'],15:['기형적인','으로 고통받았다'],20:['풍경','묘사했다'],21:['선명한','유화물감','독창적','만들어 냈다'],
22:['제약','가두었','무한했'],27:['전시','살펴보자'],28:['공통된','알아차릴','여성'],33:['과 달랐다','정물화','소재'],
34:['이와 대조적으로','바느질하는','적극적인','참여자','보여 주었다'],35:['능숙하게','풍부한','인상주의 운동','기여했다'],37:['전통적인','뛰어난','보여 주었다']}
EXTRA={
40:(["If you have ever been to an art museum,","you may have encountered docents and curators."],"미술관에 가 본 적이 있다면 / 여러분은 도슨트와 큐레이터를 마주쳤을지도 모른다",['큐레이터','마주쳤']),
41:(["While these two roles may appear similar,","they actually have quite different responsibilities,","requiring different skills."],"이 두 역할은 비슷해 보일 수도 있지만 / 사실 그들은 상당히 다른 책임을 가지고 있으며 / 서로 다른 기술을 필요로 한다",['역할','책임']),
42:(["With the word docent coming from a Latin word meaning “to teach,”","docents are guides","who lead museum tours","and provide information about the artworks and artists featured in an exhibition."],"docent라는 단어는 ‘가르치다’라는 뜻의 라틴어에서 유래했으며 / 도슨트는 안내자로 / 박물관 투어를 이끌고 / 전시회에 출품된 작품과 예술가에 대한 정보를 제공한다",['출품된','작품','제공한다']),
43:(["They are usually volunteers","who have a passion for art","and enjoy sharing their knowledge."],"그들은 보통 자원봉사자이며 / 예술에 대한 열정이 있고 / 자신의 지식을 공유하는 것을 즐긴다",['에 대한 열정이 있','지식']),
44:(["To carry out their responsibilities effectively,","docents need specialized training","in presentation and communication skills."],"자신의 책임을 효과적으로 수행하기 위해 / 도슨트는 전문 교육이 필요하다 / 발표 및 의사소통 기술에 대한",['책임|을','수행하','전문','발표']),
45:(["On the other hand, curators are professionals","who design and organize exhibitions,","with the word curator coming from a Latin word meaning “to take care of.”"],"반면 큐레이터는 전문가이며 / 전시회를 기획하고 준비하는 / curator라는 단어는 ‘돌보다’라는 뜻의 라틴어에서 유래했다",['준비하','전문가']),
46:(["Curators determine the main theme of each exhibition,","select artworks that fit with the theme,","and arrange them in an engaging way","which captivates the audience."],"큐레이터는 각 전시회의 주제를 정하고 / 그 주제에 맞는 작품을 선정하며 / 매력적인 방식으로 작품을 배치한다 / 관객을 사로잡는",['주제','정하','매력적인','배치한다','관객','사로잡']),
47:(["Curators are typically employed by museums","and are expected to possess advanced degrees","in art history, museum studies, or a related field."],"큐레이터는 보통 박물관에 고용되며 / 고급 학위를 소지해야 한다 / 미술사, 박물관학 또는 관련 분야의",['고용되','고급 학위','소지해','관련 분야']),
48:(["Despite their distinct roles,","both docents and curators share a common goal:","enriching every visitor’s experience."],"뚜렷이 다른 역할에도 불구하고 / 도슨트와 큐레이터는 공통된 목표를 공유한다 / 모든 방문객의 경험을 풍부하게 만드는 것",['뚜렷이 다른','풍부하게 만드는']),
}
def an(s): return re.sub(r'[^A-Za-z0-9]','',s).lower()
def chunks_for(i):
    if i in EXTRA: return EXTRA[i][0],EXTRA[i][1]
    en=[];ko=[]
    for j in al[str(i)]:
        en+= [x.strip() for x in cen(cards[j]).split(' / ')]
        ko+= [x.strip() for x in cards[j][2].split(' / ')]
    return en,' / '.join(ko)
def blank_ko(ko,answers):
    spans=[]
    for a in answers:
        ctx,ans=(a.split('|')+[None])[:2] if '|' in a else (None,a)
        if ctx: 
            k=ko.find(ctx+ans); st=k+len(ctx) if k>=0 else -1
        else: st=ko.find(ans)
        assert st>=0,(a,ko)
        # avoid overlap: if overlaps, find next
        while any(st<e and st+len(ans)>s for s,e,_ in spans):
            st=ko.find(ans,st+1); assert st>=0,(a,ko)
        spans.append((st,st+len(ans),ans))
    spans.sort()
    out=ko;
    for s,e,a in reversed(spans): out=out[:s]+'______________'+out[e:]
    return out,[a for _,_,a in spans]
def process(xml,i,parts_old,kor_raw):
    en,ko=chunks_for(i)
    answers=OV.get(i, EXTRA[i][2] if i in EXTRA else parts_old)
    newko,order=blank_ko(ko,answers)
    # locate endnote text
    old_note=' / '.join(parts_old)
    mm=re.search(r'<hp:t>\s*'+re.escape(old_note)+r'\s*</hp:t>',xml); assert mm,('note',i,old_note); k=mm.start()
    pstyle='<hp:p id="2147483648" paraPrIDRef="%s" styleIDRef="2"'
    ps=max(m.start() for m in re.finditer(r'<hp:p id="\d+" paraPrIDRef="(?:15|13)" styleIDRef="2"',xml[:k])); 
    ee=xml.find('</hp:endNote></hp:ctrl>',k)+len('</hp:endNote></hp:ctrl>')
    depth=0;pe=None
    for m in re.finditer(r'<hp:p |</hp:p>',xml[ps:]):
        depth+= 1 if m.group(0)=='<hp:p ' else -1
        if depth==0: pe=ps+m.end();break
    para=xml[ps:pe]
    HB=[]
    def hmask(m):
        HB.append(m.group(0)); return '\x02%d\x03'%(len(HB)-1)
    para=re.sub(r'<hp:(header|footer)\b.*?</hp:\1>',hmask,para,flags=re.S)
    ec=para.find('<hp:ctrl><hp:endNote'); eng=para[:ec]
    pos=[];n=0;L=len(eng)
    while n<L:
        c=eng[n]
        if c=='<': n=eng.find('>',n)+1; continue
        if c=='&': n=eng.find(';',n)+1; continue
        if c.isascii() and c.isalnum(): pos.append(n)
        n+=1
    A=''.join(eng[p].lower() for p in pos)
    cum=[];tot=0
    for c in en: tot+=len(an(c)); cum.append(tot)
    c0=an(en[0]); st=A.find(c0[:14]); assert st>=0,('start',i)
    assert A[st:st+tot]==''.join(an(c) for c in en),('eng mismatch',i,A[st:st+tot][:60])
    ins=[]
    for ci in range(len(en)-1):
        idx=st+cum[ci]
        if idx>=len(pos): break
        q=pos[idx]
        if en[ci+1][:1] in '—–-':
            d=eng.rfind('—',0,q+1)
            if d>=0: q=d
        ins.append(q)
    for q in sorted(ins,reverse=True):
        while eng[:q].endswith('<hp:t>'):
            e=eng.rfind('</hp:t>',0,q)
            if e<0: break
            q=e
        j=q
        while j>0 and eng[j-1]==' ': j-=1
        eng=eng[:j]+' / '+eng[q:]
    eng=re.sub(r' +((?:<[^>]+>)*) / ',lambda m:m.group(1)+' / ',eng)
    rest=para[ec:]
    # korean: nodes after the endnote
    rs=rest.find('</hp:endNote></hp:ctrl>')+len('</hp:endNote></hp:ctrl>')
    head_r,tail_r=rest[:rs],rest[rs:]
    first=[True]
    def kn(m):
        inner=m.group(1)
        if not re.search(r'[가-힣_]',inner): return m.group(0)
        if first[0]:
            first[0]=False
            segs=inner.split('<hp:lineBreak/>')
            segs[-1]=esc(newko)
            return '<hp:t>'+'<hp:lineBreak/>'.join(segs)+'</hp:t>'
        return '<hp:t/>'
    tail_r=re.sub(r'<hp:t>(.*?)</hp:t>',kn,tail_r,flags=re.S)
    assert not first[0],('nokor',i)
    rest=head_r+tail_r
    pat=re.compile(r'<hp:t>\s*'+re.escape(old_note)+r'\s*</hp:t>')
    assert pat.search(rest),('oldnote',i,old_note)
    rest=pat.sub(lambda m:'<hp:t> '+esc(' / '.join(order))+'</hp:t>',rest,count=1)
    newp=eng+rest
    # drop stale outer line layout caches (keep those inside the endnote)
    head=newp[:newp.find('<hp:ctrl><hp:endNote')]
    head=re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>','',head,flags=re.S)
    tail_start=newp.rfind('</hp:endNote></hp:ctrl>')
    tail=newp[tail_start:]
    tail=re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>','',tail,flags=re.S)
    newp=head+newp[len(head):tail_start]+tail
    newp=re.sub(r'\x02(\d+)\x03',lambda m:HB[int(m.group(1))],newp)
    return xml[:ps]+newp+xml[pe:], ko, newko
out={}
for sec,rng in (('section0.xml',range(0,40)),('section1.xml',range(40,49))):
    xml=open(f'{SRC}/Contents/{sec}',encoding='utf8').read()
    for i in rng:
        t=ws[i]; m=re.search(r'\x00(.*?)\x01',t,flags=re.S)
        parts=[x.strip() for x in m.group(1).split('(한글)')[-1].split('/')]
        kor_raw=t[m.end():] if i!=9 else '\n'+KO9
        # trim trailing whitespace differences
        kr=kor_raw.rstrip(' ')
        if kr not in xml:
            kr=kor_raw
        xml,ko,newko=process(xml,i,parts,kr)
        print(i,newko)
    out[sec]=xml
DST='/tmp/claude-0/hwpx_new'
if os.path.exists(DST): shutil.rmtree(DST)
shutil.copytree(SRC,DST,ignore=shutil.ignore_patterns('a.zip'))
for sec,xml in out.items(): open(f'{DST}/Contents/{sec}','w',encoding='utf8').write(xml)
