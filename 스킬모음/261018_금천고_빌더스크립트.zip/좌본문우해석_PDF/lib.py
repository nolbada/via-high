import pdfplumber,re,json
from kiwipiepy import Kiwi
kw=Kiwi()
base="/mnt/user-data/uploads/7. 시험준비 시즌창고/26-2기말_금천고1/2_만든자료/261017_교과서_좌본문우해석/261017_%s과_좌본문우해석.pdf"
W='\x01'
def stream(n,right):
    s=''
    with pdfplumber.open(base%n) as p:
        for pg in p.pages:
            lim=min([w['top'] for w in pg.extract_words() if w['text']=='1회독'] or [9999])-1
            last=None
            for c in pg.chars:
                if not(90<c['top']<lim): continue
                if (c['x0']>=405)!=right: continue
                t=' ' if c['text'] in '\t\n' else c['text']
                if last is not None and abs(c['top']-last)>3 and t!=' ': s+=W
                last=c['top'];s+=t
            s+=W+'\x02'+W
    return s
def split_items(s,counts=None):
    # returns list of (sec, [items]) ; s uses markers
    parts=re.split(r'([①-⑩])',s)
    out=[]
    for i in range(1,len(parts),2):
        body=parts[i+1]
        idx=[];pos=0
        for k in range(1,80):
            m=re.search(r'(?:^|[\s\x01\x02])%d\.'%k,body[pos:])
            if not m: break
            idx.append(pos+m.start());pos+=m.end()
        title=body[:idx[0]] if idx else body
        its=[]
        for a,b in zip(idx,idx[1:]+[len(body)]):
            its.append(re.sub(r'^[\s\x01\x02]*\d+\.','',body[a:b]))
        out.append((parts[i]+' '+title,its))
    return out
def fix_en(t):
    t=t.replace('\x02','').replace(W,' ');return re.sub(r'\s+',' ',t).strip()
def score(t): 
    return kw.analyze(t)[0][1]
def fix_ko(t):
    t=t.replace('\x02','')
    segs=t.split(W)
    cur=segs[0]
    for nx in segs[1:]:
        a=cur.rstrip();b=nx.lstrip()
        if not a or not b: cur=a+b;continue
        if cur.endswith(' ') or nx.startswith(' ') or a[-1] in '/:' or b[0]=='/' :
            cur=a+' '+b;continue
        if re.match(r'[A-Za-z0-9]',a[-1]) and re.match(r'[A-Za-z0-9]',b[0]): cur=a+' '+b;continue
        ca=a[-14:];cb=b[:14]
        pj=kw.analyze(ca+cb)[0][1];ps=kw.analyze(ca+' '+cb)[0][1]
        cur=a+('' if pj>ps+0.01 else ' ')+b
    return re.sub(r'\s+',' ',cur).strip()
