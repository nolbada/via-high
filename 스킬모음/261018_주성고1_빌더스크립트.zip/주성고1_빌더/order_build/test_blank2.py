import os, json
from playwright.sync_api import sync_playwright
BASE=os.environ.get('BASE','file:///home/claude/work/jusung/out3/order/h/jusung-gimal/3/')
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':420,'height':900}); pg=ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(BASE+'blank.html')
    POOL=pg.evaluate('__t.POOL'); seen=[]; n=0
    while len(seen)<POOL:
        cur=pg.evaluate('__t.state.cur')
        if cur is None:
            if pg.locator('#go').count(): pg.locator('#go').click(); continue
            break
        seen.append(cur)
        pg.locator('#qc .ob').nth(n%5).click(); n+=1
        pg.locator('#nx').click()
    print('seen',len(seen),'unique',len(set(seen)),'POOL',POOL)
    # 300 round simulation
    r=pg.evaluate("""()=>{const T=__t;let dup=0,cons=0,rounds=300;
      for(let r=0;r<rounds;r++){let q=[];for(let i=0;i<T.POOL;i++)q.push(i);let last=-1;const seen=new Set();
        while(q.length){const k=T.pickPos(q,last);const id=q.splice(k,1)[0];if(seen.has(id))dup++;seen.add(id);const s=T.ITEMS[id].seg;if(s===last)cons++;last=s}}
      return [dup,cons,rounds]}""")
    print('300 rounds dup, consecutive-same-seg:',r)
    # answer-position distribution across 200 questions
    # screenshot
    pg.evaluate("localStorage.clear()"); pg.reload()
    pg.screenshot(path='/tmp/claude-0/blank_q.png',full_page=True)
    pg.locator('#qc .ob').nth(0).click()
    pg.screenshot(path='/tmp/claude-0/blank_a.png',full_page=True)
    print(errs)
    b.close()
