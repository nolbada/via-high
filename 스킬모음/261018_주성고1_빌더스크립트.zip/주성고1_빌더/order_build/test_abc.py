import json, random
from playwright.sync_api import sync_playwright
import os
BASE=os.environ.get('BASE','file:///home/claude/work/jusung/out3/order/h/jusung-gimal/3/')
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':420,'height':900}); pg=ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(BASE+'sunseo-abc.html')
    print('sw',pg.evaluate('document.documentElement.scrollWidth'), pg.locator('#cnt').inner_text())
    # play through one run
    for qi in range(6):
        q=pg.locator('#qs .q').nth(qi)
        a=int(q.get_attribute('data-a'))
        # wrong first or right
        q.locator('.ob').nth(a if qi%2==0 else (a+1)%5).click()
        q.locator('.go').click()
        r=q.locator('.res').inner_text(); print(qi+1,r, q.locator('.flow .fn').count(),'nodes')
        q.locator('.nextq').click()
    print(pg.locator('#sum').inner_text()[:80])
    # resume check: reload mid-run
    pg.locator('#again').click()
    q=pg.locator('#qs .q').nth(0); q.locator('.ob').nth(2).click()
    pg.reload(); print('after reload',pg.locator('#cnt').inner_text(), pg.locator('#qs .q:visible .ob.sel').count())
    # sig uniqueness simulation: many fresh contexts, 5 renders each
    bad=0; sizes=[]; ansd={}
    N=60
    for t in range(N):
        pg.evaluate("localStorage.clear()"); pg.reload()
        sigs=[]
        for k in range(5):
            if k>0: pg.evaluate("window.__abc.render()")
            ru=pg.evaluate("window.__abc.run.html")
            import re
            ds=re.findall(r'data-a="(\d)"',ru)
            for d in ds: ansd[d]=ansd.get(d,0)+1
            # sig from used store
        used=json.loads(pg.evaluate("localStorage.getItem('js3-abc-used')"))
        sizes.append(len(used))
        if len(used)!=30: bad+=1
    print('5-play unique count==30 failures:',bad,'of',N, 'sizes',set(sizes))
    print('answer dist',ansd)
    # 8 plays
    pg.evaluate("localStorage.clear()"); pg.reload()
    for k in range(1,8): pg.evaluate("window.__abc.render()")
    print('after 8 plays used:',len(json.loads(pg.evaluate("localStorage.getItem('js3-abc-used')"))))
    # ranges overlap and chunk-size check on a run
    D=pg.evaluate("window.__abc.D")
    print('zones',[(z['n'],len(z['c'])) for z in D['zones']])
    print('errs',errs)
    b.close()
