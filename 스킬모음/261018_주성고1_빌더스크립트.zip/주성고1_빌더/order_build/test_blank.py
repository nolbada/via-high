import os, json
from playwright.sync_api import sync_playwright
BASE=os.environ.get('BASE','file:///home/claude/work/jusung/out3/order/h/jusung-gimal/3/')
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':420,'height':900}); pg=ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(BASE+'blank.html')
    print('sw',pg.evaluate('document.documentElement.scrollWidth'),pg.locator('#prog').inner_text())
    POOL=pg.evaluate('__t.POOL'); print('POOL',POOL)
    seen=[]; segs=[]; correct=0; posd={}
    total=0
    while True:
        cur=pg.evaluate('__t.state.cur')
        if cur is None: break
        seen.append(cur); segs.append(pg.evaluate('__t.ITEMS[%d].seg'%cur))
        btn=pg.locator('#qc .ob').nth(total%5)
        # options text must not show Korean before answer
        vis=pg.evaluate("Array.from(document.querySelectorAll('#qc .ob small')).map(s=>getComputedStyle(s).display)")
        assert all(v=='none' for v in vis), vis
        btn.click()
        ex=pg.locator('#ex').inner_text()
        assert '본문 엑기스' in ex
        total+=1
        pg.locator('#nx').click()
        if total>POOL+10: break
        # after round end summary -> button
        if pg.locator('#go').count():
            pass
        if len(seen)>=POOL: break
    print('seen',len(seen),'unique',len(set(seen)))
    mx=sum(1 for i in range(1,len(segs)) if segs[i]==segs[i-1]); print('consecutive same seg',mx)
    print(pg.locator('#stage').inner_text()[:100].replace('\n',' | '))
    # screenshot a question page
    print('errs',errs)
    # answer positions
    b.close()
