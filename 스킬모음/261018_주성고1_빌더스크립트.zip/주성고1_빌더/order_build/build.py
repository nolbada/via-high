# -*- coding: utf-8 -*-
# 주성고1 3과 순서배열 3종 + 빈칸 추론 빌더. 금천고 4/ 페이지를 틀(견본)로 쓰고 데이터만 바꾼다.
# 실행: INCLUDE6=0 python3 build.py  -> ❻(42~47) 제외 / 기본 1 -> 포함
import os, re, json, html, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data import *
from data_blank import SEGS, ITEMS

INCLUDE6 = os.environ.get('INCLUDE6', '1') != '0'
GOLD = '/home/claude/via-high/h/geumcheon-gimal/4/'
OUT = os.environ.get('OUTDIR', '/home/claude/work/jusung/out3/order/h/jusung-gimal/3/')
os.makedirs(OUT, exist_ok=True)
SCHOOL = '주성고'
FOOT = '비타민 영어클리닉 · 주성고1 공통영어2 3과'
CIRC = '①②③④⑤'

def esc(s): return html.escape(s, quote=True)
def rd(f): return open(GOLD + f, encoding='utf-8').read()
def wr(f, s):
    s = s.replace("L4-", "L3-")
    assert 'L4-' not in s and '금천' not in s and '4과' not in s, f
    open(OUT + f, 'w', encoding='utf-8').write(s)

def keep(sec): return INCLUDE6 or sec != 6

def koe(n):
    """연결어 표시가 있으면 <span class=en>English</span>(한글 뜻)으로, 없으면 공식 해석 그대로."""
    t = KOE.get(n, KO[n])
    t = esc(t)
    t = re.sub(r'\{\{(.+?)\|(.+?)\}\}', lambda m: '<span class="en">%s</span>(%s)' % (m.group(1), m.group(2)), t)
    return t

def flow(ns, given=(), first_plain=False, given_cls=None):
    h = '<div class="flow">'
    for i, n in enumerate(ns):
        ch, line = KEY[n]
        cls = 'fn'
        if n in given and given_cls: cls += ' ' + given_cls
        h += '<div class="%s">%s<span>%s</span></div>' % (cls, ('<span class="ch">%s</span>' % esc(ch)) if ch else '', esc(line))
        if i < len(ns) - 1: h += '<div class="ar">▼</div>'
    return h + '</div>'

PERMS = [[2, 0, 1], [2, 1, 0], [1, 2, 0], [1, 0, 2]]
def shuffled(idx, tot, tag):
    rnd = random.Random(1000 * tag + idx)
    while True:
        p = list(range(tot)); rnd.shuffle(p)
        if p != list(range(tot)): return p

def seq_q(qi, sec, qlbl, given, seq, mode):
    """mode: 'ko' 한글 / 'en' 영어(+한글 해석 토글)"""
    tot = len(seq)
    slots = ''.join('<div class="slot"><span class="no">%d</span><span class="st">비어 있어요</span><span class="x"></span></div>' % (i + 1) for i in range(tot))
    order = shuffled(qi, tot, 7 if mode == 'ko' else 11)
    btns = ''
    for k in order:
        n = seq[k]
        if mode == 'ko':
            btns += '<button class="pb" data-n="%d">%s</button>\n' % (k + 1, koe(n))
        else:
            btns += '<button class="pb" data-n="%d">%s<small class="kr">%s</small></button>\n' % (k + 1, esc(EN[n]), esc(KO[n]))
    if mode == 'ko':
        gv = ' '.join(koe(n) for n in given)
        what = '한글 문장'
    else:
        gv = ' '.join(esc(EN[n]) for n in given) + '<small class="kr">%s</small>' % esc(' '.join(KO[n] for n in given))
        what = '영어 문장'
    allns = list(given) + list(seq)
    fl = flow(allns, given=given, given_cls='g' if mode == 'ko' else None)
    return ('<div class="q seq2" data-t="%d" data-sec="%d"><div class="qh"><span class="qn">%d</span><span class="tg">%s</span></div>\n'
            '<div class="ask">맨 위 문장 다음에 이어질 순서대로 <b>%s</b>을 눌러 쌓은 뒤 제출해요.</div>\n'
            '<div class="gv"><span class="tg2">주어진 문장</span>%s</div>\n'
            '<div class="slots">%s</div>\n'
            '<div class="pool"><div class="lbl">이어질 순서대로 문장을 누르세요 (1번째)</div>\n%s</div><button class="sb go" disabled>제출하기</button>\n'
            '<div class="res"></div>\n'
            '<div class="fin"><div class="wd">한눈에 정리 · 이 순서로 기억해요</div>%s<button class="sb sub2 again" type="button">다시 풀기</button></div></div>\n'
            ) % (tot, sec, qi, esc(qlbl), what, gv, slots, btns, fl)

def head_of(gold_name, title):
    g = rd(gold_name)
    pre = g[:g.find('<div class="wrap">')]
    pre = re.sub(r'<title>.*?</title>', '<title>%s</title>' % title, pre)
    pre = pre.replace('금천고정답', '주성고정답')
    return g, pre

def sec_labels(groups):
    """같은 섹션 안에서 ①②③ 번호 붙이기"""
    cnt = {}
    for sec, g, s in groups: cnt[sec] = cnt.get(sec, 0) + 1
    seen = {}; out = []
    for sec, g, s in groups:
        seen[sec] = seen.get(sec, 0) + 1
        lbl = SEC_SHORT[sec] + ((' ' + CIRC[seen[sec] - 1]) if cnt[sec] > 1 else '')
        out.append(lbl)
    return out

TOPBAR = '<div class="wrap"><div class="top"><a class="back" href="../index.html">← 주성고 정답 목록</a></div>'

# ------------------------------------------------------------ 한글
def build_ko():
    g, pre = head_of('sunseo-ko.html', '3과 순서배열 · 한글')
    tail = g[g.find('<script src="../gate.js">'):]
    groups = [x for x in KO_G if keep(x[0])]
    labels = sec_labels(groups)
    body = TOPBAR + '<h1>3과 순서배열 · 한글</h1><p class="lede">3과 본문 · 한글 문장 %d묶음. 영어 연결어는 우리말 뜻과 함께 적혀 있어요.</p>' % len(groups)
    body += '<div class="bar"><span id="cnt" class="cnt"></span><button id="rs">처음부터 다시</button></div>\n'
    body += '<h2 class="sechd">한글 순서배열</h2><div class="how">맨 위에 주어진 문장 다음에 올 문장을 <b>본문 순서대로</b> 눌러요. 다 쌓고 <b>제출</b>하면 자리마다 ○×가 표시되고 흐름을 한눈에 정리한 순서도가 나와요. <b>영어(뜻)</b>로 적힌 연결어는 문장을 이어 주는 열쇠예요.</div>\n'
    for i, (sec, gv, sq) in enumerate(groups):
        body += seq_q(i + 1, sec, labels[i], gv, sq, 'ko')
    body += '<div class="foot">%s</div></div>\n' % FOOT
    wr('sunseo-ko.html', pre + body + tail)
    return len(groups)

# ------------------------------------------------------------ 문장 단위 + 삽입
def ins_q(qi, sec, qlbl, ins, passage, marks):
    # marks: 0 or n(뒤). 마커 5개. 정답 = 넣을 문장이 원래 있던 자리(ins-1 문장 뒤)
    ans_after = ins - 1
    # 원래 앞 문장이 passage에 없을 수도 있으니 passage 안에서 ins보다 작은 마지막 문장 뒤
    prev = [n for n in passage if n < ins]
    ans_pos = prev[-1] if prev else 0
    assert ans_pos in marks, (ins, ans_pos, marks)
    a = marks.index(ans_pos)
    mk_at = {m: i for i, m in enumerate(marks)}
    h = '<div class="q pick" data-a="%d" data-sec="%d"><div class="qh"><span class="qn">%d</span><span class="tg">%s</span></div>\n' % (a, sec, qi, esc(qlbl))
    h += '<div class="ask">주어진 문장이 들어갈 곳으로 가장 적절한 곳은?</div>\n'
    h += '<div class="pbox given"><span class="lab">주어진 문장</span><span class="s2">%s<small class="kr">%s</small></span></div>\n' % (esc(EN[ins]), esc(KO[ins]))
    box = ''
    def mkbtn(i): return ' <button class="mk" data-i="%d">%s</button> ' % (i, CIRC[i])
    if 0 in mk_at: box += mkbtn(mk_at[0]).lstrip()
    for n in passage:
        box += '<span class="s2">%s<small class="kr">%s</small></span>' % (esc(EN[n]), esc(KO[n]))
        if n in mk_at: box += mkbtn(mk_at[n])
        else: box += ' '
    h += '<div class="pbox">%s</div>\n' % box.strip()
    full = sorted(set(list(passage) + [ins]))
    # 한눈에 정리: 본문 전체 순서(넣을 문장 포함, 노란 칸)
    h += ('<div class="ex"><div class="res"></div><div class="kk">정답은 <b>%s</b> 이에요.</div>\n'
          '<div class="wd">주어진 문장</div><ol class="full"><li class="insli"><span class="en">%s</span><small>%s</small></li></ol>\n'
          '<div class="wd">한눈에 정리 · 노란 칸이 주어진 문장</div>%s</div></div>\n') % (
          CIRC[a], esc(EN[ins]), esc(KO[ins]), flow(full, given=(ins,), given_cls='g'))
    return h, a

def build_mun():
    g, pre = head_of('sunseo-mun.html', '3과 순서배열 · 문장')
    tail = g[g.find('<script src="../gate.js">'):]
    mg = [x for x in MUN_G if keep(x[0])]
    iq = [x for x in INS_Q if keep(x[0])]
    labels = sec_labels(mg)
    body = TOPBAR + '<h1>3과 순서배열 · 문장</h1><p class="lede">3과 본문 · (가) 문장 순서배열 %d문제, (나) 문장 삽입 %d문제.</p>' % (len(mg), len(iq))
    body += '<div class="bar"><span id="cnt" class="cnt"></span><button id="kt" type="button">한글 해석 보기</button><button id="rs">처음부터 다시</button></div>\n'
    body += '<h2 class="sechd">(가) 문장 순서배열</h2><div class="how">맨 위 문장 다음에 올 <b>영어 문장</b>을 본문 순서대로 눌러 쌓고 <b>제출</b>하면, 자리마다 ○×가 표시되고 흐름을 한눈에 정리한 순서도가 나와요. 영어가 어려우면 위쪽의 <b>한글 해석 보기</b>를 눌러요.</div>\n'
    for i, (sec, gv, sq) in enumerate(mg):
        body += seq_q(i + 1, sec, labels[i], gv, sq, 'en')
    body += '<h2 class="sechd">(나) 문장 삽입</h2><div class="how">주어진 문장이 들어갈 곳을 <b>①~⑤</b> 중에서 골라요. 번호를 누르면 정답과 글 전체 흐름 순서도가 나와요.</div>\n'
    cnt = {}
    for sec, *_ in iq: cnt[sec] = cnt.get(sec, 0) + 1
    seen = {}; ans_list = []
    for j, (sec, ins, passage, marks) in enumerate(iq):
        seen[sec] = seen.get(sec, 0) + 1
        lbl = SEC_SHORT[sec] + ((' ' + CIRC[seen[sec] - 1]) if cnt[sec] > 1 else '')
        h, a = ins_q(len(mg) + j + 1, sec, lbl, ins, passage, marks)
        body += h; ans_list.append(a)
    body += '<div class="foot">%s</div></div>\n' % FOOT
    wr('sunseo-mun.html', pre + body + tail)
    return len(mg), len(iq), ans_list

# ------------------------------------------------------------ ABC
import itertools
def plaus(e, s):
    return s == e + 1 or e in STARTS.get(s, ())
def ambig(gb, starts, sizes):
    """덩어리 순서를 바꿔도 모든 이음새가 자연스러운 보기가 하나라도 있으면 True(= 정답이 둘로 읽힘)"""
    ends = [st + sz - 1 for st, sz in zip(starts, sizes)]
    for perm in itertools.permutations(range(3)):
        if perm == (0, 1, 2): continue
        prev = gb; ok = True
        for k in perm:
            if not plaus(prev, starts[k]): ok = False; break
            prev = ends[k]
        if ok: return True
    return False
ZONES = [('❶~❷ 모뉴먼츠 맨의 시작', 2, 1, 9), ('❷ 훔친 보물과 위협', 2, 8, 15),
         ('❸ 알타우제 광산', 3, 16, 22), ('❸ 광부들의 계획', 3, 20, 26),
         ('❹ 두 달 안의 임무', 4, 26, 33), ('❺ 모뉴먼츠 맨의 영향', 5, 33, 41),
         ('❷~❸ 보물을 찾아서', 3, 10, 21), ('❸ 알타우제 광산', 3, 16, 26), ('❹~❺ 임무와 그 뒤', 5, 27, 37),
         ('❻ 언어를 잃지 마라', 6, 42, 47)]
def zone_cuts(lo, hi):
    out = []
    for gs in range(lo, hi + 1):
        for gl in (1, 2):
            gb = gs + gl - 1
            for n1 in (1, 2, 3):
                for n2 in (1, 2, 3):
                    for n3 in (1, 2, 3):
                        if max(n1, n2, n3) - min(n1, n2, n3) > 1: continue
                        if gb + n1 + n2 + n3 > hi: continue
                        tot = n1 + n2 + n3
                        if tot < 4 or tot > 7: continue
                        st = [gb + 1, gb + 1 + n1, gb + 1 + n1 + n2]
                        if not all(x in STARTS for x in st): continue
                        if ambig(gb, st, [n1, n2, n3]): continue
                        out.append([gs, gb, n1, n2, n3])
    return out

def build_abc():
    g, pre = head_of('sunseo-abc.html', '3과 순서배열 · ABC')
    i0 = g.find('<script src="../gate.js">')
    tail = g[i0:]
    zones = [{'n': nm, 'c': zone_cuts(lo, hi)} for nm, sec, lo, hi in ZONES if keep(sec)]
    D = {'en': {str(n): EN[n] for n in range(1, N + 1)},
         'key': {str(n): list(KEY[n]) for n in range(1, N + 1)},
         'why': {}, 'zones': zones}
    # D 블록 교체
    a = tail.index('var D={')
    b = tail.index("var CIRC=")
    newD = 'var D=' + json.dumps(D, ensure_ascii=False) + ';\nD.KO=' + json.dumps({str(n): KO[n] for n in range(1, N + 1)}, ensure_ascii=False) + ';\n'
    tail = tail[:a] + newD + tail[b:]
    # 저장 키를 학교별로 분리(같은 사이트 안에서 금천고와 겹치지 않게)
    for o, nw in [("'gk4-abc-used'", "'js3-abc-used'"), ("'gk4-abc-run'", "'js3-abc-run'")]:
        assert o in tail; tail = tail.replace(o, nw)
    # 쓰지 않는 근거 문구 조립 제거
    sa = tail.index(" var st='';")
    sb = tail.index(" var flow='<div class=\"flow\">'")
    tail = tail[:sa] + tail[sb:]
    body = TOPBAR + '<h1>3과 순서배열 · ABC</h1><p class="lede">3과 본문 · 모의고사 유형 6문제. 주어진 글 다음에 (A)(B)(C)의 순서를 골라요. 다시 풀 때마다 새 문제가 나와요.</p>'
    body += '<div class="bar"><span id="cnt" class="cnt"></span><button id="kt" type="button">한글 해석 보기</button><button id="rs">처음부터 다시</button></div>\n'
    body += '<h2 class="sechd">ABC 순서 고르기</h2><div class="how">주어진 글 다음에 이어질 <b>(A) (B) (C)</b>의 순서를 골라요. 한 문제씩 보기를 골라 <b>제출하기</b>를 누르면 바로 정답과 한눈에 정리 순서도가 나와요. 풀다가 나가도 <b>풀던 곳에서 이어서</b> 풀 수 있어요. 이 문제는 <b>풀 때마다 바뀌어요</b>. <b>처음부터 다시</b>를 누르면 새 문제가 나와요.</div><div id="qs"></div><div id="sum" style="display:none"></div>\n'
    body += '<div class="foot">%s</div></div>\n' % FOOT
    wr('sunseo-abc.html', pre + body + tail)
    return [(z['n'], len(z['c'])) for z in zones]

# ------------------------------------------------------------ 빈칸
def build_blank():
    g = rd('blank.html')
    pre = g[:g.find('<div class="wrap">')]
    pre = re.sub(r'<title>.*?</title>', '<title>3과 빈칸 추론 연습</title>', pre).replace('금천고정답', '주성고정답')
    tail = g[g.find('<script src="../gate.js">'):]
    segs = []; items = []
    segids = [s for s in SEGS if keep(s[4])]
    for sid, title, a, b, sec, theme in segids:
        idx = len(segs)
        its = [it for it in ITEMS if it[0] == sid]
        segs.append({'id': sid, 'title': title, 'sents': [EN[n] for n in range(a, b + 1)], 'a': len(items), 'theme': theme,
                     'kos': [KO[n] for n in range(a, b + 1)]})
        for (_, n, ans, ako, ds) in its:
            raw = S['en'][n - 1]
            assert ans.lower() in raw.lower() and raw.lower().count(ans.lower()) == 1, (n, ans)
            assert len(ds) == 4
            items.append({'seg': idx, 'si': n - a, 'ans': ans, 'ako': ako, 'clue': '', 'ds': [[x[0], x[1], ''] for x in ds], 'ko': KO[n]})
    D = {'segs': segs, 'items': items}
    a0 = tail.index('var D=')
    _, endj = json.JSONDecoder().raw_decode(tail[a0 + 6:])
    a1 = a0 + 6 + endj
    tail = tail[:a0] + 'var D=' + json.dumps(D, ensure_ascii=False) + tail[a1:]
    assert "'gk4-blank-v1'" in tail
    tail = tail.replace("'gk4-blank-v1'", "'js3-blank-v1'")
    body = TOPBAR + '<h1>3과 · 빈칸 추론 연습 (매번 다른 문제)</h1><p class="lede">같은 지문에서 빈칸이 계속 바뀌어요. 한 번 나온 문제는 한 바퀴를 다 돌 때까지 다시 나오지 않아요. 풀 때마다 문제와 보기 순서가 달라져요.</p>'
    body += '<div class="bar"><span class="prog" id="prog"></span><button id="kt" type="button">한글 해석 보기</button><button id="rs" type="button">처음부터 다시</button></div><div id="stage"></div><div class="foot">%s</div></div>\n' % FOOT
    wr('blank.html', pre + body + tail)
    return len(items), [(s['id'], sum(1 for i in items if i['seg'] == k)) for k, s in enumerate(segs)]

if __name__ == '__main__':
    print('INCLUDE6 =', INCLUDE6)
    print('ko', build_ko())
    print('mun', build_mun())
    print('abc', build_abc())
    print('blank', build_blank())
