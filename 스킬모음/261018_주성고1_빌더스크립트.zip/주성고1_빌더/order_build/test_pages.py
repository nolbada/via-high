import sys, json, re
from playwright.sync_api import sync_playwright
import os
BASE=os.environ.get('BASE','file:///home/claude/work/jusung/out3/order/h/jusung-gimal/3/')
errs=[]
def newpage(b, name, w=420):
    ctx=b.new_context(viewport={'width':w,'height':900})
    pg=ctx.new_page()
    pg.on('pageerror', lambda e: errs.append((name,str(e))))
    pg.on('console', lambda m: errs.append((name,m.text)) if m.type=='error' and 'gate.js' not in m.text and 'icon' not in m.text and 'ERR_FILE' not in m.text and 'Failed to load' not in m.text else None)
    pg.goto(BASE+name)
    return ctx,pg
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---------- ko / mun
    for name in ['sunseo-ko.html','sunseo-mun.html']:
        ctx,pg=newpage(b,name)
        sw=pg.evaluate('document.documentElement.scrollWidth'); print(name,'scrollW',sw)
        nq=pg.evaluate("document.querySelectorAll('.q.seq2').length"); npk=pg.evaluate("document.querySelectorAll('.q.pick').length")
        print(' seq2',nq,'pick',npk)
        # solve each seq2 correctly
        for i in range(nq):
            q=pg.locator('.q.seq2').nth(i)
            tot=int(q.get_attribute('data-t'))
            for k in range(1,tot+1):
                q.locator('.pb[data-n="%d"]'%k).click()
            q.locator('.go').click()
            res=q.locator('.res').inner_text()
            assert '모두 맞아요' in res,(name,i,res)
        # wrong submit on re-check: solve 'again' wrong
        q=pg.locator('.q.seq2').nth(0); q.locator('.again').click()
        tot=int(q.get_attribute('data-t'))
        for k in range(tot,0,-1): q.locator('.pb[data-n="%d"]'%k).click()
        q.locator('.go').click(); print(' wrong:',q.locator('.res').inner_text())
        # picks: click answer and wrong
        for j in range(npk):
            q=pg.locator('.q.pick').nth(j); a=int(q.get_attribute('data-a'))
            q.locator('.mk').nth(a).click()
            assert q.locator('.res').inner_text()=='정답이에요',(j,)
        print(' cnt:',pg.locator('#cnt').inner_text())
        # persistence
        pg.reload()
        print(' after reload cnt:',pg.locator('#cnt').inner_text(), 'sw', pg.evaluate('document.documentElement.scrollWidth'))
        pg.locator('#rs').click()
        print(' after reset:',pg.locator('#cnt').inner_text())
        pg.reload(); print(' reload after reset:',pg.locator('#cnt').inner_text())
        # dark mode + 420 scroll with kt open
        if name=='sunseo-mun.html':
            pg.locator('#kt').click(); print(' kon sw',pg.evaluate('document.documentElement.scrollWidth'))
        ctx.close()
    b.close()
print('ERRS',errs)
