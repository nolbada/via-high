주성고1 빌더 묶음 (261018)
- BRIEF.md / BRIEF3.md : 에이전트에게 일을 맡길 때 쓴 설명서 원본(4과용, 3과용). 새 학교 설명서의 견본.
- data3 / data4 : 3과·4과 기준 데이터(sentences.json, cards_final.json). 새 학교도 같은 모양으로 만든다.
- order_build : 순서배열·빈칸 추론 빌더(build.py, data.py, data_blank.py, 시험용 test_*.py).
선생님 코드·개인코드·열기코드는 넣지 않았다.
